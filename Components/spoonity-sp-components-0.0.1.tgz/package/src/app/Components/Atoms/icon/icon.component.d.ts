import { OnInit } from '@angular/core';
export declare class IconComponent implements OnInit {
    toolTipTittle: string;
    name: string;
    color: string;
    svgIconSettings: {
        width: string;
        fill: string;
    };
    constructor();
    ngOnInit(): void;
}
