export declare class SpComponentsModule {
}
