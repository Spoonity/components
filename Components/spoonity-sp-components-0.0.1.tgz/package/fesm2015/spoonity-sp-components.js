import { EventEmitter, Component, Input, Output, Directive, forwardRef, ViewChild, HostListener, Injectable, HostBinding, ContentChildren, TemplateRef, ViewContainerRef, ViewEncapsulation, NgModule } from '@angular/core';
import { NzAffixModule } from 'ng-zorro-antd/affix';
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzAutocompleteModule } from 'ng-zorro-antd/auto-complete';
import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { NzBackTopModule } from 'ng-zorro-antd/back-top';
import { NzBadgeModule } from 'ng-zorro-antd/badge';
import { NzBreadCrumbModule } from 'ng-zorro-antd/breadcrumb';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzCalendarModule } from 'ng-zorro-antd/calendar';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzCarouselModule } from 'ng-zorro-antd/carousel';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzCollapseModule } from 'ng-zorro-antd/collapse';
import { NzCommentModule } from 'ng-zorro-antd/comment';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzDropDownModule, NzContextMenuServiceModule } from 'ng-zorro-antd/dropdown';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzMessageModule, NzMessageService } from 'ng-zorro-antd/message';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { NzNotificationModule, NzNotificationService } from 'ng-zorro-antd/notification';
import { NzPageHeaderModule } from 'ng-zorro-antd/page-header';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzProgressModule } from 'ng-zorro-antd/progress';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzSliderModule } from 'ng-zorro-antd/slider';
import { NzStepsModule } from 'ng-zorro-antd/steps';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzUploadModule } from 'ng-zorro-antd/upload';
import { NG_VALUE_ACCESSOR, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { registerLocaleData, CommonModule } from '@angular/common';
import en from '@angular/common/locales/en';
import { SvgIconRegistryService, AngularSvgIconModule } from 'angular-svg-icon';
import { CdkPortal, PortalModule } from '@angular/cdk/portal';
import { OverlayConfig, Overlay, OverlayModule } from '@angular/cdk/overlay';
import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import { ChartsModule, ThemeService } from 'ng2-charts';
import { RouterModule } from '@angular/router';
import { en_US, NZ_I18N } from 'ng-zorro-antd/i18n';

const NZMODULES = [
    NzAffixModule,
    NzAlertModule,
    NzAutocompleteModule,
    NzAvatarModule,
    NzBackTopModule,
    NzBadgeModule,
    NzBreadCrumbModule,
    NzButtonModule,
    NzCalendarModule,
    NzCardModule,
    NzCarouselModule,
    NzCheckboxModule,
    NzCollapseModule,
    NzCommentModule,
    NzDatePickerModule,
    NzDividerModule,
    NzDropDownModule,
    NzContextMenuServiceModule,
    NzGridModule,
    NzIconModule,
    NzInputModule,
    NzInputNumberModule,
    NzLayoutModule,
    NzMenuModule,
    NzModalModule,
    NzNotificationModule,
    NzPageHeaderModule,
    NzPaginationModule,
    NzProgressModule,
    NzRadioModule,
    NzSelectModule,
    NzSliderModule,
    NzStepsModule,
    NzSwitchModule,
    NzTableModule,
    NzTabsModule,
    NzTagModule,
    NzToolTipModule,
    NzUploadModule,
    NzMessageModule,
];

var ButtonType;
(function (ButtonType) {
    ButtonType["primary"] = "primary";
    ButtonType["secondary"] = "default";
    ButtonType["tertiary"] = "link";
})(ButtonType || (ButtonType = {}));
var ButtonSize;
(function (ButtonSize) {
    ButtonSize["large"] = "large";
    ButtonSize["medium"] = "default";
    ButtonSize["small"] = "small";
})(ButtonSize || (ButtonSize = {}));
var SideNavigationType;
(function (SideNavigationType) {
    SideNavigationType["menu"] = "menu";
    SideNavigationType["subMenu"] = "subMenu";
    SideNavigationType["menuGroup"] = "menuGroup";
    SideNavigationType["menuItem"] = "menuItem";
})(SideNavigationType || (SideNavigationType = {}));
var TagType;
(function (TagType) {
    TagType["closeable"] = "closeable";
    TagType["default"] = "default";
    TagType["checkable"] = "checkable";
})(TagType || (TagType = {}));
var AvatarSize;
(function (AvatarSize) {
    AvatarSize[AvatarSize["large"] = 48] = "large";
    AvatarSize[AvatarSize["medium"] = 40] = "medium";
    AvatarSize[AvatarSize["small"] = 32] = "small";
})(AvatarSize || (AvatarSize = {}));
var DividerType;
(function (DividerType) {
    DividerType["vertical"] = "vertical";
    DividerType["horizontal"] = "horizontal";
})(DividerType || (DividerType = {}));
var ProgressType;
(function (ProgressType) {
    ProgressType["line"] = "line";
    ProgressType["circle"] = "circle";
})(ProgressType || (ProgressType = {}));
var ICardType;
(function (ICardType) {
    ICardType["sms"] = "sms";
    ICardType["customer"] = "customer";
    ICardType["gift"] = "giftManagement";
})(ICardType || (ICardType = {}));

class ChipComponent {
    constructor() {
        this.mode = TagType.default;
        this.onCloseEvent = new EventEmitter();
        this.onCheckEvent = new EventEmitter();
    }
    ngOnInit() {
        this.styles = { 'width.px': 20, 'height.px': 20 };
    }
    onClose() {
        this.onCloseEvent.emit(true);
    }
    checkChange(e) {
        this.checked = e;
        this.onCheckEvent.emit(e);
    }
}
ChipComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-chip',
                template: "<nz-tag\r\n  [nzMode]=\"mode\"\r\n  [nzChecked]=\"checked\"\r\n  (nzOnClose)=\"onClose()\"\r\n  (nzCheckedChange)=\"checkChange($event)\"\r\n  [attr.disabled]=\"disabled\"\r\n>\r\n  <svg-icon\r\n    *ngIf=\"icon || checked\"\r\n    nz-icon\r\n    [name]=\"checked ? 'check' : icon\"\r\n    [svgStyle]=\"styles\"\r\n  ></svg-icon>\r\n  <span class=\"spt-spacing-x--1\">{{ text }}</span>\r\n</nz-tag>\r\n",
                styles: [".ant-tag{height:32px!important;line-height:32px!important;font-size:14px}"]
            },] }
];
ChipComponent.ctorParameters = () => [];
ChipComponent.propDecorators = {
    text: [{ type: Input }],
    icon: [{ type: Input }],
    mode: [{ type: Input }],
    checked: [{ type: Input }],
    disabled: [{ type: Input }],
    onCloseEvent: [{ type: Output }],
    onCheckEvent: [{ type: Output }]
};

class ButtonComponent {
    constructor() {
        this.type = ButtonType.primary;
        this.size = ButtonSize.medium;
    }
    ngOnInit() {
    }
}
ButtonComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-button',
                template: "<button nz-button [nzType]=\"type\" [nzSize]=\"size\" [disabled]=\"disabled\">\r\n  <spt-icon *ngIf=\"leftIcon\" [name]=\"leftIcon\"></spt-icon>\r\n  <span *ngIf=\"text\" [ngClass]=\"{leftIcon: leftIcon,rightIcon: rightIcon}\">{{ text }}</span>\r\n  <spt-icon *ngIf=\"rightIcon\" [name]=\"rightIcon\"></spt-icon>\r\n</button>\r\n",
                styles: [".leftIcon{margin-left:10px}.rightIcon{margin-right:10px}"]
            },] }
];
ButtonComponent.ctorParameters = () => [];
ButtonComponent.propDecorators = {
    type: [{ type: Input }],
    size: [{ type: Input }],
    leftIcon: [{ type: Input }],
    rightIcon: [{ type: Input }],
    text: [{ type: Input }],
    disabled: [{ type: Input }]
};

class FormFieldManager {
    constructor() {
        /* size specification (large or medium) -- default to medium if not provided */
        this.size = 'medium';
        /* value */
        this.value = null;
        /* ControlValueAccessor: onChange function **/
        this.onChange = () => { };
        /* ControlValueAccessor: onTouched function */
        this.onTouched = () => { };
    }
    /**
     * ControlValueAccessor override: registerOnChange
     */
    registerOnChange(fn) {
        this.onChange = fn;
    }
    /**
     * ControlValueAccessor override: registerOnTouched
     */
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    /**
     * ControlValueAccessor override: writeValue
     */
    writeValue(obj) {
        if (obj !== undefined) {
            this.value = obj;
            this.checkDirty();
        }
    }
    /**
     * on change action
     */
    changeAction($event) {
        this.onChange($event);
        this.checkDirty();
    }
    setDisabledState(isDisabled) {
        this.isDisabled = isDisabled;
    }
    /**
     * check dirty
     */
    checkDirty() {
        if (typeof this.value === 'string' || this.value instanceof String) {
            this.isDirty = this.value.trim() !== '';
        }
        else {
            this.isDirty = this.value != null;
        }
    }
}
FormFieldManager.decorators = [
    { type: Directive }
];
FormFieldManager.propDecorators = {
    size: [{ type: Input }],
    label: [{ type: Input }],
    error: [{ type: Input }],
    startIcon: [{ type: Input }],
    endIcon: [{ type: Input }],
    hint: [{ type: Input }],
    placeholder: [{ type: Input }],
    isDisabled: [{ type: Input }]
};

class TextFieldComponent extends FormFieldManager {
    constructor() {
        super();
    }
    ngOnInit() {
    }
    /**
     * get current value length
     */
    getLength() {
        if (!this.value) {
            return 0;
        }
        return this.value.length;
    }
}
TextFieldComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-text-field',
                template: "<div class=\"spt-input-container text-field-container\" [ngClass]=\"{'disabled-container': isDisabled}\">\r\n\r\n    <input nz-input [ngClass]=\"{'dirty': isDirty, 'error': !!error, 'has-left-icon': !!startIcon, 'has-right-icon': !!endIcon, 'has-length': !!max, 'disabled-state': isDisabled}\"\r\n           (click)=\"isDisabled ? $event.stopPropagation() : null\"\r\n           [(ngModel)]=\"value\"\r\n           (ngModelChange)=\"changeAction($event)\"\r\n           [attr.type]=\"type\"\r\n           [attr.maxlength]=\"max\"\r\n           [class]=\"size\" placeholder=\"{{placeholder}}\"\r\n           [attr.disabled]=\"isDisabled\">\r\n\r\n    <!-- label -->\r\n    <label class=\"text-field-label label\">{{ label || placeholder }}</label>\r\n\r\n    <!-- hint -->\r\n    <label class=\"text-field-bottom-label hint-label\" *ngIf=\"!!hint && !error\">{{ hint }}</label>\r\n\r\n    <!-- error -->\r\n    <label class=\"text-field-bottom-label error-label\" *ngIf=\"!!error\">{{ error }}</label>\r\n\r\n    <!-- maxlength -->\r\n    <label class=\"text-field-bottom-label length-label\" *ngIf=\"max\">{{getLength()}}/{{max}}</label>\r\n\r\n\r\n    <!-- error icon -->\r\n    <span *ngIf=\"!!error\" class=\"text-field-icon error-icon\">\r\n        <svg-icon name=\"report\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n    </span>\r\n\r\n    <!-- left icon -->\r\n    <span *ngIf=\"!!startIcon\" class=\"text-field-icon left-icon\">\r\n        <svg-icon name=\"{{startIcon}}\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n    </span>\r\n\r\n    <!-- error icon -->\r\n    <span *ngIf=\"!!endIcon && !error\" class=\"text-field-icon right-icon\">\r\n        <svg-icon name=\"{{endIcon}}\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n    </span>\r\n</div>\r\n\r\n\r\n",
                providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => TextFieldComponent),
                        multi: true
                    }
                ],
                styles: [".form-field{color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.form-field.large{padding:12px 10px}.form-field.large+label{top:12px}.form-field.medium{padding:8px 10px}.form-field.medium+label{top:8px}.form-field.small{padding:6px 10px}.form-field.small+label{top:6px}.form-field.error,.form-field.has-right-icon{padding-right:45px}.form-field.error{border:1px solid #ef5350!important}.form-field.error~label{color:#ef5350!important}.form-field.error:focus,.form-field.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.form-field.has-left-icon{padding-left:45px}.form-field.has-left-icon+label{left:45px}.form-field:hover{border:1px solid #000!important}.form-field.item-focus,.form-field:focus{border:1px solid #f90!important;caret-color:#f90}.form-field.item-focus+label,.form-field:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.text-field-container input::-moz-placeholder{visibility:hidden;opacity:0;-moz-transition:visibility .1s ease-out,opacity .1s ease-out;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input::placeholder{visibility:hidden;opacity:0;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input:focus::-moz-placeholder{visibility:visible;opacity:1}.text-field-container input:focus::placeholder{visibility:visible;opacity:1}.spt-input-container{margin:0;position:relative}.spt-input-container input{box-shadow:none;outline:none;min-height:24px;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.spt-input-container input.large{padding:12px 10px}.spt-input-container input.large+label{top:12px}.spt-input-container input.medium{padding:8px 10px}.spt-input-container input.medium+label{top:8px}.spt-input-container input.small{padding:6px 10px}.spt-input-container input.small+label{top:6px}.spt-input-container input.error,.spt-input-container input.has-right-icon{padding-right:45px}.spt-input-container input.error{border:1px solid #ef5350!important}.spt-input-container input.error~label{color:#ef5350!important}.spt-input-container input.error:focus,.spt-input-container input.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.spt-input-container input.has-left-icon{padding-left:45px}.spt-input-container input.has-left-icon+label{left:45px}.spt-input-container input:hover{border:1px solid #000!important}.spt-input-container input.item-focus,.spt-input-container input:focus{border:1px solid #f90!important;caret-color:#f90}.spt-input-container input.item-focus+label,.spt-input-container input:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input[disabled]{background-color:#fff!important;color:#b1b1b1!important;border:1px solid #b1b1b1!important;cursor:not-allowed}.spt-input-container input[disabled]~label{color:#b1b1b1!important}.spt-input-container input[disabled]:hover{border:1px solid #b1b1b1!important}.spt-input-container input.dirty+label{color:#909090}.spt-input-container input.dirty:hover+label{color:#000}.spt-input-container input.dirty:focus+label{color:#f90}.spt-input-container input.dirty+label{font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input+label{position:absolute;left:12px;font-size:14px;color:#909090;background-color:hsla(0,0%,100%,0);pointer-events:none;transition:all .2s ease,background-color .2s ease-in}.spt-input-container .text-field-icon{position:absolute;height:24px;top:50%;transform:translateY(-50%)}.spt-input-container .error-icon,.spt-input-container .right-icon{right:12px}.spt-input-container .left-icon{left:12px}.spt-input-container .left-icon svg path,.spt-input-container .right-icon svg path{fill:#706f6e}.spt-input-container .error-icon svg path{fill:#ef5350}.spt-input-container label.text-field-bottom-label{font-size:12px;margin-top:10px;position:absolute;bottom:-20px}.spt-input-container label.error-label,.spt-input-container label.hint-label{left:12px}.spt-input-container label.length-label{right:12px}.spt-input-container label.error-label{color:#ef5350}.spt-input-container label.hint-label,.spt-input-container label.length-label{color:#4f4e4d}.spt-input-container.disabled-container .text-field-bottom-label{color:#b1b1b1!important}.spt-input-container.disabled-container .text-field-icon svg path{fill:#b1b1b1}.search-wrapper{display:flex;align-items:center;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.search-wrapper.large{padding:12px 10px}.search-wrapper.large+label{top:12px}.search-wrapper.medium{padding:8px 10px}.search-wrapper.medium+label{top:8px}.search-wrapper.small{padding:6px 10px}.search-wrapper.small+label{top:6px}.search-wrapper.error,.search-wrapper.has-right-icon{padding-right:45px}.search-wrapper.error{border:1px solid #ef5350!important}.search-wrapper.error~label{color:#ef5350!important}.search-wrapper.error:focus,.search-wrapper.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.search-wrapper.has-left-icon{padding-left:45px}.search-wrapper.has-left-icon+label{left:45px}.search-wrapper:hover{border:1px solid #000!important}.search-wrapper.item-focus,.search-wrapper:focus{border:1px solid #f90!important;caret-color:#f90}.search-wrapper.item-focus+label,.search-wrapper:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.search-wrapper input,.search-wrapper input:focus,.search-wrapper input:hover{border:none!important}.search-wrapper .search-icon{height:24px}.search-wrapper.large .search-icon,.search-wrapper.medium .search-icon{margin-left:10px;margin-right:10px}.search-wrapper.small{padding:4px 10px}.search-wrapper.small .search-icon{margin-left:10px;margin-right:10px}.search-wrapper .selected-items{display:flex;flex-wrap:wrap}.search-wrapper .selected-items .selected-item{margin:1px}"]
            },] }
];
TextFieldComponent.ctorParameters = () => [];
TextFieldComponent.propDecorators = {
    type: [{ type: Input }],
    max: [{ type: Input }]
};

class BannerComponent {
    constructor() {
        this.bannerList = [];
        this.closeCallback = new EventEmitter();
        /* icons by type */
        this.icon = {
            error: 'error',
            warning: 'warning',
            success: 'check-circle',
            info: 'priority-high'
        };
        /* close state for each banner */
        this.close = {};
    }
    /* handle close button */
    onCloseButtonClick(id) {
        this.close[id] = true;
        setTimeout(() => {
            this._removeBanner(id);
        }, 200);
    }
    /* remove banner */
    _removeBanner(id) {
        const remove = this.bannerList.filter((b) => b.id !== id);
        this.bannerList = [...remove];
    }
}
BannerComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-banner',
                template: "<div *ngFor=\"let banner of bannerList\" class=\"spt-spacing-y--1\">\r\n    <div class=\"spt-elevation--6 banner-component banner-{{banner.type}}\" [ngClass]=\"{'banner-hide': close[banner.id]}\">\r\n        <div class=\"banner-icon\">\r\n            <svg-icon name=\"{{icon[banner.type]}}\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n        </div>\r\n        <div class=\"banner-message banner-message-action\">{{banner.message}}</div>\r\n        <div class=\"banner-close-action\" (click)=\"onCloseButtonClick(banner.id)\">\r\n            <nz-divider nzType=\"vertical\"></nz-divider>\r\n            <div class=\"banner-icon close-icon\">\r\n                <svg-icon name=\"clear\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n",
                styles: [".banner-component{min-height:48px;min-width:-webkit-fit-content;min-width:-moz-fit-content;min-width:fit-content;width:-webkit-fit-content;width:-moz-fit-content;width:fit-content;left:16px;top:16px;border-radius:4px;padding:12px 16px;display:flex;align-items:center}.banner-component.banner-hide{visibility:hidden;opacity:0;transition:visibility .1s ease-out,opacity .1s ease-out}.banner-component.banner-error{background-color:#ef5350}.banner-component.banner-warning{background-color:#f7ad00}.banner-component.banner-info{background-color:#067bc2}.banner-component.banner-success{background-color:#4caf50}.banner-component .banner-message{color:#fff;padding-left:10px}.banner-component .banner-message.banner-message-action{padding-right:16px}.banner-component .banner-icon{height:24px}.banner-component .banner-icon svg path{fill:#fff}.banner-component .banner-close-action{margin-left:auto;display:flex;align-items:center;cursor:pointer}.banner-component .banner-close-action .ant-divider.ant-divider-vertical{height:24px!important;margin:0!important;background-color:hsla(0,0%,100%,.32);top:0}.banner-component .banner-close-action .close-icon{padding-left:16px}"]
            },] }
];
BannerComponent.propDecorators = {
    bannerList: [{ type: Input }],
    closeCallback: [{ type: Output }]
};

class OverlayTemplateComponent {
    constructor(overlay) {
        this.overlay = overlay;
        this.showing = false;
    }
    ngOnInit() {
    }
    show() {
        this.overlayRef = this.overlay.create(this.getOverlayConfig());
        this.overlayRef.attach(this.contentTemplate);
        this.syncWidth();
        this.overlayRef.backdropClick().subscribe(() => this.hide());
        this.showing = true;
    }
    hide() {
        this.overlayRef.detach();
        this.showing = false;
    }
    onWinResize() {
        this.syncWidth();
    }
    syncWidth() {
        if (!this.overlayRef) {
            return;
        }
        const refRect = this.reference.getBoundingClientRect();
        this.overlayRef.updateSize({ width: refRect.width });
    }
    getOverlayConfig() {
        const positionStrategy = this.overlay.position()
            .flexibleConnectedTo(this.reference)
            .withPush(false)
            .withPositions([{
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'top'
            }, {
                originX: 'start',
                originY: 'top',
                overlayX: 'start',
                overlayY: 'bottom'
            }]);
        return new OverlayConfig({
            positionStrategy,
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop'
        });
    }
}
OverlayTemplateComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-overlay-template',
                template: "<ng-template cdk-portal=\"\">\r\n    <ng-content></ng-content>\r\n</ng-template>\r\n"
            },] }
];
OverlayTemplateComponent.ctorParameters = () => [
    { type: Overlay }
];
OverlayTemplateComponent.propDecorators = {
    reference: [{ type: Input }],
    contentTemplate: [{ type: ViewChild, args: [CdkPortal, { static: true },] }],
    onWinResize: [{ type: HostListener, args: ['window:resize',] }]
};

class DropdownService {
    register(select) {
        this.select = select;
    }
    getSelect() {
        return this.select;
    }
}
DropdownService.decorators = [
    { type: Injectable }
];

class OptionComponent {
    constructor(_dropdownService) {
        this._dropdownService = _dropdownService;
        /* bind class.active */
        this.active = false;
        this.select = this._dropdownService.getSelect();
    }
    /* bind class.selected */
    get selected() {
        return this.select.single_selectedOption === this;
    }
    /* click event listener */
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.select.selectOption(this);
    }
    ngOnInit() {
    }
    /**
     * get option label
     */
    getLabel() {
        return this.text;
    }
    /**
     * set active status
     */
    setActiveStyles() {
        this.active = true;
    }
    /**
     * set inactive status
     */
    setInactiveStyles() {
        this.active = false;
    }
    /**
     * select option item
     */
    selectItem() {
        this.select.selectOption(this);
    }
}
OptionComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-option',
                template: "<div class=\"option-container\">\r\n    <!--- multiple selection (include checkbox -->\r\n    <div *ngIf=\"select.selectMultiple\" nz-col nzSpan=\"8\">\r\n        <label nz-checkbox nzValue=\"{{value}}\" [(ngModel)]=\"checkboxModel\" (ngModelChange)=\"selectItem()\">{{text}}</label>\r\n    </div>\r\n\r\n    <!-- single selection -->\r\n    <div *ngIf=\"!select.selectMultiple\">{{text}}</div>\r\n</div>\r\n",
                styles: [".options-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.option-item-active{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.option-item-active{background-color:#f3f3f3}}:host{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}:host.active,:host.selected,:host:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){:host.active,:host.selected,:host:hover{background-color:#f3f3f3}}:host.selected{font-weight:700}:host.active,:host:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){:host.active,:host:hover{background-color:#f3f3f3}}:host.disabled{color:#93a1aa;cursor:auto}:host.disabled:focus,:host.disabled:hover{outline:none;background-color:#fff}@media screen and (-ms-high-contrast:active){:host.disabled:focus,:host.disabled:hover{background-color:#fff}}.option-container{display:flex}"]
            },] }
];
OptionComponent.ctorParameters = () => [
    { type: DropdownService }
];
OptionComponent.propDecorators = {
    value: [{ type: Input }],
    text: [{ type: Input }],
    selected: [{ type: HostBinding, args: ['class.selected',] }],
    active: [{ type: HostBinding, args: ['class.active',] }],
    onClick: [{ type: HostListener, args: ['click', ['$event'],] }]
};

class DropdownComponent extends FormFieldManager {
    constructor(_dropdownService) {
        super();
        this._dropdownService = _dropdownService;
        /* multiple selection: list of selected OptionComponent */
        this.multiple_selectedOptions = [];
        /* multiple selection: list of selected option values */
        this.multiple_selected = [];
        this._dropdownService.register(this);
    }
    ngAfterViewInit() {
        setTimeout(() => {
            if (this.selectMultiple) {
                this.options.toArray().forEach((o) => {
                    if (this.multiple_selected.includes(o.value)) {
                        this.selectOption(o);
                    }
                });
                this.value = this.multiple_selectedOptions.length ?
                    Array.from(this.multiple_selectedOptions, (o) => o.text).join(', ')
                    : '';
            }
            else {
                this.single_selectedOption = this.options.toArray().find(option => option.value === this.single_selected);
                this.value = this.single_selectedOption ? this.single_selectedOption.text : '';
                this.keyManager = new ActiveDescendantKeyManager(this.options)
                    .withHorizontalOrientation('ltr')
                    .withVerticalOrientation()
                    .withWrap();
            }
            this.checkDirty();
        }, 100);
    }
    /**
     *  override: inherited writeValue
     */
    writeValue(obj) {
        if (obj !== undefined) {
            if (this.selectMultiple) {
                if (Array.isArray(obj)) {
                    this.multiple_selected = obj;
                }
            }
            else {
                this.single_selected = obj;
            }
            this.checkDirty();
        }
    }
    /**
     * show dropdown action
     */
    showDropdown() {
        this.dropdown.show();
        if (!this.options.length) {
            return;
        }
        // set highlighted item only for single selection
        // -- highlight selected item or first item
        if (!this.selectMultiple) {
            if (this.single_selected) {
                this.keyManager.setActiveItem(this.single_selectedOption);
            }
            else {
                this.keyManager.setFirstItemActive();
            }
        }
    }
    /**
     * hide dropdown action
     */
    hideDropdown() {
        this.dropdown.hide();
    }
    /**
     * action when clicking the chevron icon (on the right)
     * @param event
     */
    onDropMenuIconClick(event) {
        event.stopPropagation();
        setTimeout(() => {
            this.input.nativeElement.focus();
            this.input.nativeElement.click();
        }, 10);
    }
    /**
     * select option
     * @param option
     */
    selectOption(option) {
        if (this.selectMultiple) {
            // already selected -- unselect item
            if (this.multiple_selectedOptions.find((o) => o.value === option.value)) {
                this.multiple_selectedOptions = [...this.multiple_selectedOptions.filter((o) => o.value !== option.value)];
                this.multiple_selected = [...this.multiple_selected.filter((s) => s !== option.value)];
                option.checkboxModel = false;
            }
            else {
                // not yet selected -- select item
                if (!this.multiple_selected.includes(option.value)) {
                    this.multiple_selected.push(option.value);
                }
                this.multiple_selectedOptions.push(option);
                option.checkboxModel = true;
            }
            this.value = this.multiple_selectedOptions.length ?
                Array.from(this.multiple_selectedOptions, (o) => o.text).join(', ')
                : '';
        }
        else {
            this.keyManager.setActiveItem(option);
            this.single_selected = option.value;
            this.single_selectedOption = option;
            this.value = this.single_selectedOption ? this.single_selectedOption.text : '';
            this.hideDropdown();
            this.input.nativeElement.blur();
        }
        this.checkDirty();
        this.onChange(this.selectMultiple ? this.multiple_selected : option.value);
    }
    /**
     * keydown event (applies only to single selection items)
     * @param event
     */
    onKeyDown(event) {
        if (this.selectMultiple) {
            return;
        }
        if (['Enter', ' ', 'ArrowDown', 'Down', 'ArrowUp', 'Up'].indexOf(event.key) > -1) {
            if (!this.dropdown.showing) {
                this.showDropdown();
                return;
            }
            if (!this.options.length) {
                event.preventDefault();
                return;
            }
        }
        if (event.key === 'Enter' || event.key === ' ') {
            this.single_selectedOption = this.keyManager.activeItem;
            this.value = this.single_selectedOption ? this.single_selectedOption.text : '';
            this.hideDropdown();
            this.onChange();
            this.checkDirty();
        }
        else if (event.key === 'Escape' || event.key === 'Esc') {
            if (this.dropdown.showing) {
                this.hideDropdown();
            }
        }
        else if (['ArrowUp', 'Up', 'ArrowDown', 'Down', 'ArrowRight', 'Right', 'ArrowLeft', 'Left']
            .indexOf(event.key) > -1) {
            this.keyManager.onKeydown(event);
        }
        else if (event.key === 'PageUp' || event.key === 'PageDown' || event.key === 'Tab') {
            if (this.dropdown.showing) {
                event.preventDefault();
            }
        }
    }
}
DropdownComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-dropdown',
                template: "<div #dropReference class=\"spt-input-container\" [ngClass]=\"{'disabled-container': isDisabled}\">\r\n\r\n    <input #input [ngClass]=\"{'dirty': isDirty, 'error': !!error, 'has-left-icon': !!startIcon, 'disabled-state': isDisabled}\"\r\n           (click)=\"showDropdown()\"\r\n           [(ngModel)]=\"value\"\r\n           (ngModelChange)=\"changeAction($event)\"\r\n           (keydown)=\"onKeyDown($event)\"\r\n           class=\"{{size}} has-right-icon\"\r\n           [attr.disabled]=\"isDisabled\" readonly autocomplete=\"off\">\r\n\r\n    <!-- label -->\r\n    <label class=\"text-field-label label\">{{ label || placeholder }}</label>\r\n\r\n    <!-- hint -->\r\n    <label class=\"text-field-bottom-label hint-label\" *ngIf=\"!!hint && !error\">{{ hint }}</label>\r\n\r\n    <!-- error -->\r\n    <label class=\"text-field-bottom-label error-label\" *ngIf=\"!!error\">{{ error }}</label>\r\n\r\n    <!-- error icon -->\r\n    <span *ngIf=\"!!error\" class=\"text-field-icon error-icon\">\r\n        <svg-icon name=\"report\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n    </span>\r\n\r\n    <!-- left icon -->\r\n    <span *ngIf=\"!!startIcon\" class=\"text-field-icon left-icon\">\r\n        <svg-icon name=\"{{startIcon}}\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n    </span>\r\n\r\n    <!-- right icon (arrow) -->\r\n    <div *ngIf=\"!error\" class=\"text-field-icon right-icon\" (click)=\"onDropMenuIconClick($event)\">\r\n        <svg-icon name=\"expand-more\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n    </div>\r\n\r\n    <spt-overlay-template [reference]=\"dropReference\" #dropdownComp>\r\n        <div class=\"dropdown-options-container spt-elevation--5\">\r\n            <ng-content select=\"spt-option\"></ng-content>\r\n        </div>\r\n    </spt-overlay-template>\r\n\r\n</div>\r\n\r\n\r\n",
                providers: [
                    DropdownService,
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => DropdownComponent),
                        multi: true
                    }
                ],
                styles: [".dropdown-options-container{width:100%;max-height:200px;overflow:auto}.spt-input-container input:focus~.right-icon,.spt-input-container input~.right-icon{transition:all .2s ease,background-color .2s ease-in}.spt-input-container input:focus~.right-icon{transform:rotate(180deg) translateY(50%)}.spt-input-container input:focus~.right-icon svg path{fill:#f90}", ".form-field{color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.form-field.large{padding:12px 10px}.form-field.large+label{top:12px}.form-field.medium{padding:8px 10px}.form-field.medium+label{top:8px}.form-field.small{padding:6px 10px}.form-field.small+label{top:6px}.form-field.error,.form-field.has-right-icon{padding-right:45px}.form-field.error{border:1px solid #ef5350!important}.form-field.error~label{color:#ef5350!important}.form-field.error:focus,.form-field.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.form-field.has-left-icon{padding-left:45px}.form-field.has-left-icon+label{left:45px}.form-field:hover{border:1px solid #000!important}.form-field.item-focus,.form-field:focus{border:1px solid #f90!important;caret-color:#f90}.form-field.item-focus+label,.form-field:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.text-field-container input::-moz-placeholder{visibility:hidden;opacity:0;-moz-transition:visibility .1s ease-out,opacity .1s ease-out;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input::placeholder{visibility:hidden;opacity:0;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input:focus::-moz-placeholder{visibility:visible;opacity:1}.text-field-container input:focus::placeholder{visibility:visible;opacity:1}.spt-input-container{margin:0;position:relative}.spt-input-container input{box-shadow:none;outline:none;min-height:24px;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.spt-input-container input.large{padding:12px 10px}.spt-input-container input.large+label{top:12px}.spt-input-container input.medium{padding:8px 10px}.spt-input-container input.medium+label{top:8px}.spt-input-container input.small{padding:6px 10px}.spt-input-container input.small+label{top:6px}.spt-input-container input.error,.spt-input-container input.has-right-icon{padding-right:45px}.spt-input-container input.error{border:1px solid #ef5350!important}.spt-input-container input.error~label{color:#ef5350!important}.spt-input-container input.error:focus,.spt-input-container input.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.spt-input-container input.has-left-icon{padding-left:45px}.spt-input-container input.has-left-icon+label{left:45px}.spt-input-container input:hover{border:1px solid #000!important}.spt-input-container input.item-focus,.spt-input-container input:focus{border:1px solid #f90!important;caret-color:#f90}.spt-input-container input.item-focus+label,.spt-input-container input:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input[disabled]{background-color:#fff!important;color:#b1b1b1!important;border:1px solid #b1b1b1!important;cursor:not-allowed}.spt-input-container input[disabled]~label{color:#b1b1b1!important}.spt-input-container input[disabled]:hover{border:1px solid #b1b1b1!important}.spt-input-container input.dirty+label{color:#909090}.spt-input-container input.dirty:hover+label{color:#000}.spt-input-container input.dirty:focus+label{color:#f90}.spt-input-container input.dirty+label{font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input+label{position:absolute;left:12px;font-size:14px;color:#909090;background-color:hsla(0,0%,100%,0);pointer-events:none;transition:all .2s ease,background-color .2s ease-in}.spt-input-container .text-field-icon{position:absolute;height:24px;top:50%;transform:translateY(-50%)}.spt-input-container .error-icon,.spt-input-container .right-icon{right:12px}.spt-input-container .left-icon{left:12px}.spt-input-container .left-icon svg path,.spt-input-container .right-icon svg path{fill:#706f6e}.spt-input-container .error-icon svg path{fill:#ef5350}.spt-input-container label.text-field-bottom-label{font-size:12px;margin-top:10px;position:absolute;bottom:-20px}.spt-input-container label.error-label,.spt-input-container label.hint-label{left:12px}.spt-input-container label.length-label{right:12px}.spt-input-container label.error-label{color:#ef5350}.spt-input-container label.hint-label,.spt-input-container label.length-label{color:#4f4e4d}.spt-input-container.disabled-container .text-field-bottom-label{color:#b1b1b1!important}.spt-input-container.disabled-container .text-field-icon svg path{fill:#b1b1b1}.search-wrapper{display:flex;align-items:center;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.search-wrapper.large{padding:12px 10px}.search-wrapper.large+label{top:12px}.search-wrapper.medium{padding:8px 10px}.search-wrapper.medium+label{top:8px}.search-wrapper.small{padding:6px 10px}.search-wrapper.small+label{top:6px}.search-wrapper.error,.search-wrapper.has-right-icon{padding-right:45px}.search-wrapper.error{border:1px solid #ef5350!important}.search-wrapper.error~label{color:#ef5350!important}.search-wrapper.error:focus,.search-wrapper.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.search-wrapper.has-left-icon{padding-left:45px}.search-wrapper.has-left-icon+label{left:45px}.search-wrapper:hover{border:1px solid #000!important}.search-wrapper.item-focus,.search-wrapper:focus{border:1px solid #f90!important;caret-color:#f90}.search-wrapper.item-focus+label,.search-wrapper:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.search-wrapper input,.search-wrapper input:focus,.search-wrapper input:hover{border:none!important}.search-wrapper .search-icon{height:24px}.search-wrapper.large .search-icon,.search-wrapper.medium .search-icon{margin-left:10px;margin-right:10px}.search-wrapper.small{padding:4px 10px}.search-wrapper.small .search-icon{margin-left:10px;margin-right:10px}.search-wrapper .selected-items{display:flex;flex-wrap:wrap}.search-wrapper .selected-items .selected-item{margin:1px}"]
            },] }
];
DropdownComponent.ctorParameters = () => [
    { type: DropdownService }
];
DropdownComponent.propDecorators = {
    selectMultiple: [{ type: Input }],
    input: [{ type: ViewChild, args: ['input',] }],
    dropdown: [{ type: ViewChild, args: [OverlayTemplateComponent,] }],
    options: [{ type: ContentChildren, args: [OptionComponent,] }]
};

class SideNavigationComponent {
    constructor() {
        this.items = new Array();
    }
    ngOnInit() {
    }
}
SideNavigationComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-side-navigation',
                template: "<!-- Menu Item -->\r\n<ng-container *ngIf=\"type == 'menuItem'\">\r\n  <li nz-menu-item class=\"side-navigation-component\">\r\n    <span>\r\n      <svg-icon\r\n        *ngIf=\"icon\"\r\n        nz-icon\r\n        [svgStyle]=\"{ 'height.px': 20 }\"\r\n        [name]=\"icon\"\r\n      ></svg-icon\r\n    ></span>\r\n    <span class=\"text\">{{ text }}</span>\r\n  </li>\r\n</ng-container>\r\n\r\n<!-- Sub Menu -->\r\n<ng-container *ngIf=\"type == 'subMenu'\">\r\n  <li nzOpen nz-submenu>\r\n    <span title\r\n      ><span>\r\n        <svg-icon\r\n          *ngIf=\"icon\"\r\n          nz-icon\r\n          [svgStyle]=\"{ 'height.px': 20 }\"\r\n          [name]=\"icon\"\r\n        ></svg-icon></span\r\n      ><span>{{ text }}</span></span\r\n    >\r\n    <ul>\r\n      <ng-container *ngFor=\"let item of items\">\r\n        <li nz-menu-item>\r\n          <span>\r\n            <svg-icon\r\n              *ngIf=\"item.icon\"\r\n              nz-icon\r\n              [svgStyle]=\"{ 'height.px': 20 }\"\r\n              [name]=\"item.icon\"\r\n            ></svg-icon\r\n          ></span>\r\n          <span class=\"text\">{{ item.text }}</span>\r\n        </li>\r\n      </ng-container>\r\n    </ul>\r\n  </li>\r\n</ng-container>\r\n\r\n<!-- Menu -->\r\n<ng-container *ngIf=\"type == 'menu'\">\r\n  <ul nz-menu></ul>\r\n</ng-container>\r\n",
                styles: ["li[nz-menu-item] .text{font-size:16px;line-height:3px;font-weight:700;margin-left:34px}li[nz-menu-item]:hover{background-color:#f3f3f3;border-radius:0 28px 28px 0;cursor:pointer}li[nz-menu-item].active{background-color:#fff3e0}li[nz-menu-item].active svg-icon svg path{fill:#f90}.ant-menu-submenu-active{outline-style:none!important}svg-icon{transform:translateY(2px)}"]
            },] }
];
SideNavigationComponent.ctorParameters = () => [];
SideNavigationComponent.propDecorators = {
    icon: [{ type: Input }],
    text: [{ type: Input }],
    disabled: [{ type: Input }],
    items: [{ type: Input }],
    type: [{ type: Input }]
};

class SearchService {
    register(select) {
        this.search = select;
    }
    getSearch() {
        return this.search;
    }
}
SearchService.decorators = [
    { type: Injectable }
];

class SearchOptionComponent {
    constructor(_searchService) {
        this._searchService = _searchService;
        /* bind class.active */
        this.active = false;
        this.search = this._searchService.getSearch();
    }
    /* bind class.selected */
    get selected() {
        return this.search.selected === this;
    }
    /* click event listener */
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.search.select(this.value);
    }
    ngOnInit() {
    }
    /**
     * set active status
     */
    setActiveStyles() {
        this.active = true;
    }
    /**
     * set inactive status
     */
    setInactiveStyles() {
        this.active = false;
    }
}
SearchOptionComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-search-option',
                template: "<div class=\"search-option-container\">\r\n    <ng-content></ng-content>\r\n</div>\r\n",
                styles: [".options-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.option-item-active{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.option-item-active{background-color:#f3f3f3}}.search-option-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.search-option-container.active,.search-option-container:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.search-option-container.active,.search-option-container:hover{background-color:#f3f3f3}}"]
            },] }
];
SearchOptionComponent.ctorParameters = () => [
    { type: SearchService }
];
SearchOptionComponent.propDecorators = {
    value: [{ type: Input }],
    selected: [{ type: HostBinding, args: ['class.selected',] }],
    active: [{ type: HostBinding, args: ['class.active',] }],
    onClick: [{ type: HostListener, args: ['click', ['$event'],] }]
};

class SearchComponent extends FormFieldManager {
    constructor(_searchService) {
        super();
        this._searchService = _searchService;
        /* selected items (chips) */
        this.selectedItems = [];
        /* filter action */
        this.filter = new EventEmitter();
        /* item selected action */
        this.itemSelected = new EventEmitter();
        /* item removed action */
        this.itemRemoved = new EventEmitter();
        this._searchService.register(this);
    }
    ngAfterViewInit() {
    }
    /**
     * override: on change action
     */
    changeAction($event) {
        this.onChange($event);
        this.checkDirty();
        if (this.value.length > 0) {
            if (!this.search.showing) {
                this.showDropdown();
            }
            this.filterAction();
        }
        else {
            this.hideDropdown();
        }
    }
    /**
     * show options action
     */
    showDropdown() {
        this.search.show();
    }
    /**
     * hide dropdown action
     */
    hideDropdown() {
        this.search.hide();
    }
    /**
     * keydown event
     */
    onKeyDown(event) {
        if (event.key === 'Escape' || event.key === 'Esc') {
            if (this.search.showing) {
                this.hideDropdown();
            }
        }
    }
    /**
     * on select item
     */
    select(selection) {
        this.itemSelected.emit(selection);
        this.hideDropdown();
    }
    /**
     * on filter action
     */
    filterAction() {
        this.filter.emit();
    }
    /**
     * on close item
     */
    onClose(selection) {
        this.itemRemoved.emit(selection);
    }
}
SearchComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-search',
                template: "<div #searchReference class=\"spt-input-container search-container\" [ngClass]=\"{'disabled-container': isDisabled}\">\r\n    <div class=\"search-wrapper {{size}} \" [ngClass]=\"{'item-focus': focus}\">\r\n        <!-- search icon -->\r\n        <div class=\"search-icon left-icon\">\r\n            <svg-icon name=\"search\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n        </div>\r\n\r\n        <!-- selected items (chips) -->\r\n        <div class=\"selected-items spt-spacing-x--1\" *ngIf=\"selectedItems.length\">\r\n            <div class=\"selected-item\" *ngFor=\"let s of selectedItems\">\r\n                <spt-chip [text]=\"s.text\"\r\n                         [icon]=\"s.icon\" mode=\"closeable\"\r\n                         (onCloseEvent)=\"onClose(s)\"></spt-chip>\r\n            </div>\r\n        </div>\r\n        <input #input *ngIf=\"maximumSelection ? selectedItems.length <= maximumSelection : true\"\r\n               (focus)=\"focus=true\" (blur)=\"focus=false\"\r\n               [ngClass]=\"{'dirty': isDirty, 'error': !!error, 'disabled-state': isDisabled}\"\r\n               [(ngModel)]=\"value\"\r\n               (ngModelChange)=\"changeAction($event)\"\r\n               (keydown)=\"onKeyDown($event)\"\r\n               placeholder=\"{{placeholder}}\" autocomplete=\"off\">\r\n    </div>\r\n\r\n    <spt-overlay-template [reference]=\"searchReference\" #searchComp>\r\n        <div class=\"search-options-container spt-elevation--5\">\r\n            <ng-content select=\"spt-search-option\"></ng-content>\r\n        </div>\r\n    </spt-overlay-template>\r\n\r\n</div>\r\n\r\n\r\n",
                providers: [
                    SearchService,
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => SearchComponent),
                        multi: true
                    }
                ],
                styles: [".spt-input-container input::-moz-placeholder{visibility:visible!important}.spt-input-container input::placeholder{visibility:visible!important}.search-options-container{width:100%;max-height:200px;overflow:auto}", ".form-field{color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.form-field.large{padding:12px 10px}.form-field.large+label{top:12px}.form-field.medium{padding:8px 10px}.form-field.medium+label{top:8px}.form-field.small{padding:6px 10px}.form-field.small+label{top:6px}.form-field.error,.form-field.has-right-icon{padding-right:45px}.form-field.error{border:1px solid #ef5350!important}.form-field.error~label{color:#ef5350!important}.form-field.error:focus,.form-field.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.form-field.has-left-icon{padding-left:45px}.form-field.has-left-icon+label{left:45px}.form-field:hover{border:1px solid #000!important}.form-field.item-focus,.form-field:focus{border:1px solid #f90!important;caret-color:#f90}.form-field.item-focus+label,.form-field:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.text-field-container input::-moz-placeholder{visibility:hidden;opacity:0;-moz-transition:visibility .1s ease-out,opacity .1s ease-out;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input::placeholder{visibility:hidden;opacity:0;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input:focus::-moz-placeholder{visibility:visible;opacity:1}.text-field-container input:focus::placeholder{visibility:visible;opacity:1}.spt-input-container{margin:0;position:relative}.spt-input-container input{box-shadow:none;outline:none;min-height:24px;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.spt-input-container input.large{padding:12px 10px}.spt-input-container input.large+label{top:12px}.spt-input-container input.medium{padding:8px 10px}.spt-input-container input.medium+label{top:8px}.spt-input-container input.small{padding:6px 10px}.spt-input-container input.small+label{top:6px}.spt-input-container input.error,.spt-input-container input.has-right-icon{padding-right:45px}.spt-input-container input.error{border:1px solid #ef5350!important}.spt-input-container input.error~label{color:#ef5350!important}.spt-input-container input.error:focus,.spt-input-container input.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.spt-input-container input.has-left-icon{padding-left:45px}.spt-input-container input.has-left-icon+label{left:45px}.spt-input-container input:hover{border:1px solid #000!important}.spt-input-container input.item-focus,.spt-input-container input:focus{border:1px solid #f90!important;caret-color:#f90}.spt-input-container input.item-focus+label,.spt-input-container input:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input[disabled]{background-color:#fff!important;color:#b1b1b1!important;border:1px solid #b1b1b1!important;cursor:not-allowed}.spt-input-container input[disabled]~label{color:#b1b1b1!important}.spt-input-container input[disabled]:hover{border:1px solid #b1b1b1!important}.spt-input-container input.dirty+label{color:#909090}.spt-input-container input.dirty:hover+label{color:#000}.spt-input-container input.dirty:focus+label{color:#f90}.spt-input-container input.dirty+label{font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input+label{position:absolute;left:12px;font-size:14px;color:#909090;background-color:hsla(0,0%,100%,0);pointer-events:none;transition:all .2s ease,background-color .2s ease-in}.spt-input-container .text-field-icon{position:absolute;height:24px;top:50%;transform:translateY(-50%)}.spt-input-container .error-icon,.spt-input-container .right-icon{right:12px}.spt-input-container .left-icon{left:12px}.spt-input-container .left-icon svg path,.spt-input-container .right-icon svg path{fill:#706f6e}.spt-input-container .error-icon svg path{fill:#ef5350}.spt-input-container label.text-field-bottom-label{font-size:12px;margin-top:10px;position:absolute;bottom:-20px}.spt-input-container label.error-label,.spt-input-container label.hint-label{left:12px}.spt-input-container label.length-label{right:12px}.spt-input-container label.error-label{color:#ef5350}.spt-input-container label.hint-label,.spt-input-container label.length-label{color:#4f4e4d}.spt-input-container.disabled-container .text-field-bottom-label{color:#b1b1b1!important}.spt-input-container.disabled-container .text-field-icon svg path{fill:#b1b1b1}.search-wrapper{display:flex;align-items:center;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.search-wrapper.large{padding:12px 10px}.search-wrapper.large+label{top:12px}.search-wrapper.medium{padding:8px 10px}.search-wrapper.medium+label{top:8px}.search-wrapper.small{padding:6px 10px}.search-wrapper.small+label{top:6px}.search-wrapper.error,.search-wrapper.has-right-icon{padding-right:45px}.search-wrapper.error{border:1px solid #ef5350!important}.search-wrapper.error~label{color:#ef5350!important}.search-wrapper.error:focus,.search-wrapper.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.search-wrapper.has-left-icon{padding-left:45px}.search-wrapper.has-left-icon+label{left:45px}.search-wrapper:hover{border:1px solid #000!important}.search-wrapper.item-focus,.search-wrapper:focus{border:1px solid #f90!important;caret-color:#f90}.search-wrapper.item-focus+label,.search-wrapper:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.search-wrapper input,.search-wrapper input:focus,.search-wrapper input:hover{border:none!important}.search-wrapper .search-icon{height:24px}.search-wrapper.large .search-icon,.search-wrapper.medium .search-icon{margin-left:10px;margin-right:10px}.search-wrapper.small{padding:4px 10px}.search-wrapper.small .search-icon{margin-left:10px;margin-right:10px}.search-wrapper .selected-items{display:flex;flex-wrap:wrap}.search-wrapper .selected-items .selected-item{margin:1px}"]
            },] }
];
SearchComponent.ctorParameters = () => [
    { type: SearchService }
];
SearchComponent.propDecorators = {
    placeholder: [{ type: Input }],
    selectedItems: [{ type: Input }],
    maximumSelection: [{ type: Input }],
    filter: [{ type: Output }],
    itemSelected: [{ type: Output }],
    itemRemoved: [{ type: Output }],
    search: [{ type: ViewChild, args: [OverlayTemplateComponent,] }],
    options: [{ type: ContentChildren, args: [SearchOptionComponent,] }]
};

class SearchTemplateComponent {
    constructor() { }
    ngOnInit() {
    }
}
SearchTemplateComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-search-template',
                template: "<ng-template cdk-portal=\"\">\r\n    <ng-content></ng-content>\r\n</ng-template>\r\n",
                styles: [""]
            },] }
];
SearchTemplateComponent.ctorParameters = () => [];

class StepsComponent {
    constructor() {
        this.type = 'navigation';
        this.direction = 'horizontal';
        this.onIndexChangeEvent = new EventEmitter();
    }
    ngOnInit() {
    }
    onIndexChange(event) {
        this.onIndexChangeEvent.emit(event);
    }
}
StepsComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-steps',
                template: "<nz-steps [nzCurrent]=\"current\" [nzType]=\"type\" (nzIndexChange)=\"onIndexChange($event)\" [nzDirection]=\"direction\">\r\n    <ng-container *ngFor=\"let step of steps\">\r\n        <nz-step [nzTitle]=\"step.title\" [nzDescription]=\"step.description\"></nz-step>\r\n    </ng-container>\r\n</nz-steps>\r\n",
                styles: ["nz-step .ant-steps-item-finish .ant-steps-item-icon{background-color:#fff;border-color:#4caf50!important}"]
            },] }
];
StepsComponent.ctorParameters = () => [];
StepsComponent.propDecorators = {
    current: [{ type: Input }],
    steps: [{ type: Input }],
    type: [{ type: Input }],
    direction: [{ type: Input }],
    onIndexChangeEvent: [{ type: Output }]
};

class MenuService {
    register(menu) {
        this.menu = menu;
    }
    getMenu() {
        return this.menu;
    }
}
MenuService.decorators = [
    { type: Injectable }
];

class MenuItemComponent {
    constructor(_menuService) {
        this._menuService = _menuService;
        /* bind class.active */
        this.active = false;
        this.menu = this._menuService.getMenu();
    }
    /* click event listener */
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.checkboxModel = !this.checkboxModel;
        this.menu.selectMenuItem(this);
    }
    ngOnInit() {
        // verify input
        if (this.menu.multiple) {
            if (this.itemId == null) {
                throw new Error('spt-menu-item: missing attribute: itemId for multiple selection');
            }
        }
    }
    /**
     * set active status
     */
    setActiveStyles() {
        this.active = true;
    }
    /**
     * set inactive status
     */
    setInactiveStyles() {
        this.active = false;
    }
    /**
     * select menu item
     */
    selectItem() {
        this.menu.selectMenuItem(this);
    }
    /**
     * if multiple items can be selected
     */
    isMultiple() {
        return this.menu.multiple;
    }
}
MenuItemComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-menu-item',
                template: "<div class=\"menu-item\" [ngClass]=\"{'multiple-menu-item': isMultiple(), 'single-menu-item': !isMultiple(), 'selected-item': isMultiple() && checkboxModel}\">\r\n\r\n    <!---- start icon ---->\r\n    <div class=\"menu-icon\" *ngIf=\"!!startIcon\">\r\n        <svg-icon *ngIf=\"!!startIcon\" nz-icon [name]=\"startIcon\" [svgStyle]=\"{ 'width.px':20, 'height.px':20 }\"></svg-icon>\r\n    </div>\r\n\r\n    <!---- left checkbox (if there is no start icon) ---->\r\n    <div *ngIf=\"isMultiple() && !startIcon\">\r\n        <label nz-checkbox nzValue=\"{{checkboxModel}}\" [(ngModel)]=\"checkboxModel\" (ngModelChange)=\"selectItem()\"></label>\r\n    </div>\r\n\r\n    <!---- label ---->\r\n    <div [ngClass]=\"{'label': !!startIcon || isMultiple()}\"><ng-content></ng-content></div>\r\n\r\n    <!---- right checkbox (if there is a start icon) ---->\r\n    <div *ngIf=\"isMultiple() && !!startIcon\" class=\"right-checkbox\">\r\n        <label nz-checkbox nzValue=\"{{checkboxModel}}\" [(ngModel)]=\"checkboxModel\" (ngModelChange)=\"selectItem()\"></label>\r\n    </div>\r\n</div>\r\n",
                styles: [".options-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.option-item-active{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.option-item-active{background-color:#f3f3f3}}.menu-item{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.menu-item.selected,.menu-item:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.menu-item.selected,.menu-item:hover{background-color:#f3f3f3}}.menu-item.selected{font-weight:700}.menu-item.active,.menu-item:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.menu-item.active,.menu-item:hover{background-color:#f3f3f3}}.menu-item:active{background-color:#e2e2e2;outline:none}@media screen and (-ms-high-contrast:active){.menu-item:active{background-color:#e2e2e2}}.menu-item.multiple-menu-item:active{background-color:#ffe1b4!important}.menu-item.selected-item{background-color:#fff3e0}.menu-item.disabled{color:#93a1aa;cursor:auto}.menu-item.disabled:focus,.menu-item.disabled:hover{outline:none;background-color:#fff}@media screen and (-ms-high-contrast:active){.menu-item.disabled:focus,.menu-item.disabled:hover{background-color:#fff}}.menu-item .menu-icon svg path{fill:#706f6e}.menu-item .label{margin-left:10px}.menu-icon,.menu-item{display:flex;align-items:center}.right-checkbox{margin-left:auto}"]
            },] }
];
MenuItemComponent.ctorParameters = () => [
    { type: MenuService }
];
MenuItemComponent.propDecorators = {
    itemId: [{ type: Input }],
    startIcon: [{ type: Input }],
    preventClose: [{ type: Input }],
    checkboxModel: [{ type: Input }],
    active: [{ type: HostBinding, args: ['class.active',] }],
    onClick: [{ type: HostListener, args: ['click', ['$event'],] }]
};

class MenuComponent {
    constructor(_menuService) {
        this._menuService = _menuService;
        /* close menu when item is clicked */
        this.closeOnItemClick = true;
        /* toggle select all */
        this.toggleSelectAll = new EventEmitter();
        this.searchModelChange = new EventEmitter();
        /* selected items list (two-way binding) */
        this.selectedItems = [];
        this.selectedItemsChange = new EventEmitter();
        /* is the menu showing */
        this._menuShowing = false;
        this._menuService.register(this);
    }
    ngOnInit() {
    }
    /**
     * toggle show state of the menu items
     */
    toggleMenu() {
        this._menuShowing = !this.isShowing();
        if (this._menuShowing) {
            this.showMenu();
        }
        else {
            this.hideMenu();
        }
    }
    /**
     * show menu action
     */
    showMenu() {
        this.menu.show();
        if (this.search) {
            try {
                this.searchEl.nativeElement.focus();
            }
            catch (e) { }
        }
    }
    /**
     * hide menu action
     */
    hideMenu() {
        this.menu.hide();
        this.searchModel = '';
        this.searchModelChange.emit(this.searchModel);
    }
    /**
     * visibility state of the overlay template
     */
    isShowing() {
        return this.menu ? this.menu.showing : false;
    }
    /**
     * change model action
     */
    change() {
        this.searchModelChange.emit(this.searchModel);
    }
    /**
     * select menu item
     */
    selectMenuItem(item) {
        if (!this.selectedItems) {
            this.selectedItems = [];
        }
        this.selectedItem = item;
        if (!this.multiple) {
            if (this.closeOnItemClick) {
                this.hideMenu();
            }
        }
        else {
            if (item.checkboxModel) {
                if (!this.selectedItems.includes(item.itemId)) {
                    this.selectedItems.push(item.itemId);
                }
            }
            else {
                this.selectedItems = Array.from(this.selectedItems.filter((s) => s !== item.itemId));
                if (this.selectAllOption) {
                    this.selectAll = false;
                }
            }
            this.selectedItemsChange.emit(this.selectedItems);
        }
    }
    /**
     * keydown event (escape is pressed)
     */
    onKeyDown(event) {
        if (event.key === 'Escape' || event.key === 'Esc') {
            if (this.menu.showing) {
                this.hideMenu();
            }
        }
    }
    /**
     * toggle select all
     */
    toggleSelectAllAction(fromCheckbox) {
        if (!fromCheckbox) {
            this.selectAll = !this.selectAll;
        }
        this.toggleSelectAll.emit(this.selectAll);
    }
}
MenuComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-menu',
                template: "<div #menuReference class=\"menu-wrapper\" [ngClass]=\"{'show-menu': isShowing()}\">\r\n    <spt-overlay-template [reference]=\"menuReference\" #menuComp>\r\n        <div class=\"menu-container spt-elevation--5\">\r\n\r\n            <!---- search ---->\r\n            <div *ngIf=\"search\" class=\"search-container spt-spacing--1\">\r\n                <input #searchEl\r\n                       placeholder=\"Search\"\r\n                       [(ngModel)]=\"searchModel\"\r\n                       (ngModelChange)=\"change()\"\r\n                       (keydown)=\"onKeyDown($event)\"/>\r\n            </div>\r\n\r\n            <!---- select all ---->\r\n            <div *ngIf=\"multiple && selectAllOption\" class=\"menu-item spt-spacing--1 multiple-menu-item\" (click)=\"toggleSelectAllAction()\">\r\n                <div>\r\n                    <label nz-checkbox [(ngModel)]=\"selectAll\" (ngModelChange)=\"toggleSelectAllAction(true)\"></label>\r\n                </div>\r\n                <div class=\"label\">Select All</div>\r\n            </div>\r\n\r\n            <!-- options list -->\r\n            <ng-content select=\"spt-menu-item\"></ng-content>\r\n        </div>\r\n    </spt-overlay-template>\r\n</div>\r\n\r\n",
                providers: [MenuService],
                styles: [".options-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.option-item-active{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.option-item-active{background-color:#f3f3f3}}.menu-item{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.menu-item.selected,.menu-item:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.menu-item.selected,.menu-item:hover{background-color:#f3f3f3}}.menu-item.selected{font-weight:700}.menu-item.active,.menu-item:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.menu-item.active,.menu-item:hover{background-color:#f3f3f3}}.menu-item:active{background-color:#e2e2e2;outline:none}@media screen and (-ms-high-contrast:active){.menu-item:active{background-color:#e2e2e2}}.menu-item.multiple-menu-item:active{background-color:#ffe1b4!important}.menu-item.selected-item{background-color:#fff3e0}.menu-item.disabled{color:#93a1aa;cursor:auto}.menu-item.disabled:focus,.menu-item.disabled:hover{outline:none;background-color:#fff}@media screen and (-ms-high-contrast:active){.menu-item.disabled:focus,.menu-item.disabled:hover{background-color:#fff}}.menu-item .menu-icon svg path{fill:#706f6e}.menu-item .label{margin-left:10px}.menu-icon,.menu-item{display:flex;align-items:center}.right-checkbox{margin-left:auto}.menu-wrapper{width:280px;visibility:hidden}.menu-container{width:100%;overflow:hidden}.search-container{background-color:#fff}.search-container input{padding:6px 10px;width:100%;color:#0d0c0b;border-radius:4px;border:1px solid #909090!important;outline:none}.search-container input:hover{border:1px solid #000!important}.search-container input.item-focus,.search-container input:focus{border:1px solid #f90!important;caret-color:#f90}.show-menu{visibility:visible}.select-all-container{display:flex;background-color:#fff}"]
            },] }
];
MenuComponent.ctorParameters = () => [
    { type: MenuService }
];
MenuComponent.propDecorators = {
    multiple: [{ type: Input }],
    closeOnItemClick: [{ type: Input }],
    search: [{ type: Input }],
    selectAllOption: [{ type: Input }],
    toggleSelectAll: [{ type: Output }],
    searchModel: [{ type: Input }],
    searchModelChange: [{ type: Output }],
    selectedItems: [{ type: Input }],
    selectedItemsChange: [{ type: Output }],
    searchEl: [{ type: ViewChild, args: ['searchEl',] }],
    menu: [{ type: ViewChild, args: [OverlayTemplateComponent,] }],
    menuItems: [{ type: ContentChildren, args: [MenuItemComponent,] }]
};

class MenuTriggerDirective {
    /* click event listener */
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.spMenuTrigger.toggleMenu();
    }
}
MenuTriggerDirective.decorators = [
    { type: Directive, args: [{
                selector: '[spMenuTrigger]'
            },] }
];
MenuTriggerDirective.propDecorators = {
    spMenuTrigger: [{ type: Input }],
    onClick: [{ type: HostListener, args: ['click', ['$event'],] }]
};

class BackNavigationComponent {
    constructor() { }
    ngOnInit() {
    }
}
BackNavigationComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-back-navigation',
                template: "<nz-page-header class=\"site-page-header\" nzBackIcon [nzTitle]=\"title\" [nzSubtitle]=\"subTitle\">\r\n</nz-page-header>",
                styles: [".site-page-header{padding:0}"]
            },] }
];
BackNavigationComponent.ctorParameters = () => [];
BackNavigationComponent.propDecorators = {
    title: [{ type: Input }],
    subTitle: [{ type: Input }],
    route: [{ type: Input }]
};

class BreadcrumbComponent {
    constructor() { }
    ngOnInit() {
    }
}
BreadcrumbComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-breadcrumb',
                template: "<nz-breadcrumb [nzSeparator]=\"'>'\">\r\n    <ng-container *ngFor=\"let item of items\">\r\n        <nz-breadcrumb-item>\r\n            <a *ngIf=\"item.route\" [routerLink]=\"item.route\">{{item.label}}</a>\r\n            <span *ngIf=\"!item.route\">{{item.label}}</span>\r\n        </nz-breadcrumb-item>\r\n    </ng-container>\r\n</nz-breadcrumb>",
                styles: [""]
            },] }
];
BreadcrumbComponent.ctorParameters = () => [];
BreadcrumbComponent.propDecorators = {
    items: [{ type: Input }]
};

class SnackbarComponent {
    constructor(notification) {
        this.notification = notification;
    }
    ngOnInit() {
    }
    createSnackbar(snackbar) {
        this.notification.template(this.template, {
            nzStyle: {
                background: '#0D0C0B',
                color: 'white'
            },
            nzData: snackbar,
            nzPlacement: 'bottomLeft'
        });
    }
    onAction(callback) {
        callback();
    }
}
SnackbarComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-snackbar',
                template: "<ng-template #template let-snackbar=\"data\">\r\n    <div class=\"ant-notification-notice-content\">\r\n        <div>\r\n            <div class=\"ant-notification-notice-message\">\r\n                {{ snackbar.message }}\r\n            </div>\r\n            <div class=\"ant-notification-notice-description\">\r\n                {{ snackbar.description }}\r\n            </div>\r\n            <span class=\"ant-notification-notice-btn\">\r\n        <span *ngIf=\"snackbar.actionMessage\" (click)=\"onAction(snackbar.actionEvent)\">\r\n          {{ snackbar.actionMessage }}\r\n        </span>\r\n            </span>\r\n        </div>\r\n    </div>\r\n</ng-template>\r\n",
                styles: [".ant-notification-notice-content{background-color:#0d0c0b;color:#fff}.ant-notification-notice-btn,.ant-notification-notice-message{color:#fff}.ant-notification-notice-btn{float:left;margin-top:8px;cursor:pointer}"]
            },] }
];
SnackbarComponent.ctorParameters = () => [
    { type: NzNotificationService }
];
SnackbarComponent.propDecorators = {
    template: [{ type: ViewChild, args: [TemplateRef,] }]
};

class AvatarComponent {
    constructor() { }
    ngOnInit() {
        this.styles = { 'background-color': this.backgroundColor, 'color': this.color };
    }
}
AvatarComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-avatar',
                template: "<nz-avatar [nzText]=\"text\" [nzSize]=\"size\" [ngStyle]=\"styles\"></nz-avatar>\r\n",
                styles: ["nz-avatar{margin:10px}"]
            },] }
];
AvatarComponent.ctorParameters = () => [];
AvatarComponent.propDecorators = {
    size: [{ type: Input }],
    text: [{ type: Input }],
    color: [{ type: Input }],
    backgroundColor: [{ type: Input }]
};

class BadgeComponent {
    constructor() { }
    ngOnInit() {
    }
}
BadgeComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-badge',
                template: "\r\n<nz-tag class=\"badges\" nzStandalone [nzColor]=\"color\">{{name}}</nz-tag>\r\n",
                styles: [".badges{display:flex}nz-tag{padding:4px 12px}.ant-tag{line-height:24px!important}"]
            },] }
];
BadgeComponent.ctorParameters = () => [];
BadgeComponent.propDecorators = {
    name: [{ type: Input }],
    color: [{ type: Input }]
};

class DividerComponent {
    constructor() {
        this.type = DividerType.horizontal;
    }
    ngOnInit() {
    }
}
DividerComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-divider',
                template: "<nz-divider class=\"divider\" [nzType]=\"type\"></nz-divider>",
                styles: [".divider{height:1px;margin:0}"]
            },] }
];
DividerComponent.ctorParameters = () => [];
DividerComponent.propDecorators = {
    type: [{ type: Input }]
};

class ProgressBarComponent {
    constructor() {
        this.type = ProgressType.line;
    }
    ngOnInit() {
    }
}
ProgressBarComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-progress-bar',
                template: "<nz-progress [nzPercent]=\"percent\" [nzShowInfo]=\"info\" [nzType]=\"type\"></nz-progress>",
                styles: [""]
            },] }
];
ProgressBarComponent.ctorParameters = () => [];
ProgressBarComponent.propDecorators = {
    percent: [{ type: Input }],
    info: [{ type: Input }],
    type: [{ type: Input }]
};

class CheckboxComponent {
    constructor() {
        this.span = 8;
        this.onChangeEvent = new EventEmitter();
    }
    ngOnInit() {
    }
    onChange(e) {
        this.onChangeEvent.emit(e);
    }
}
CheckboxComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-checkbox',
                template: "<div nz-col [nzSpan]=\"span\"><label nz-checkbox [nzIndeterminate]=\"indeterminate\" [ngModel]=\"check\" (ngModelChange)=\"onChange($event)\" [nzValue]=\"value\">{{value}}</label></div>",
                styles: [""]
            },] }
];
CheckboxComponent.ctorParameters = () => [];
CheckboxComponent.propDecorators = {
    indeterminate: [{ type: Input }],
    check: [{ type: Input }],
    value: [{ type: Input }],
    onChangeEvent: [{ type: Output }]
};

class RadioButtonComponent {
    constructor() {
        this.radioButtons = [
            { radioName: 'A', disable: false },
            { radioName: 'B', disable: true },
            { radioName: 'C', disable: false },
            { radioName: 'D', disable: false },
        ];
    }
    ngOnInit() { }
}
RadioButtonComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-radio-button',
                template: "<nz-radio-group \r\n[ngModel]=\"model\"\r\n>\r\n    <label\r\n    *ngFor=\"let btn of radioButtons\" \r\n    nz-radio \r\n    [nzValue]=\"btn.radioName\"\r\n    [nzDisabled]=\"btn.disable\"\r\n    >{{btn.radioName}}</label>\r\n</nz-radio-group>",
                styles: [""]
            },] }
];
RadioButtonComponent.ctorParameters = () => [];
RadioButtonComponent.propDecorators = {
    model: [{ type: Input }]
};

class SwitchComponent {
    constructor() {
        this.on = false;
    }
    ngOnInit() {
    }
}
SwitchComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-switch',
                template: "<nz-switch [ngModel]=\"on\"></nz-switch>",
                styles: ["nz-switch{margin:10px}"]
            },] }
];
SwitchComponent.ctorParameters = () => [];
SwitchComponent.propDecorators = {
    on: [{ type: Input }]
};

class SliderComponent {
    constructor() { }
    ngOnInit() {
    }
}
SliderComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-slider',
                template: "<nz-slider [nzMax]=\"max\" [nzDisabled]=\"disable\" [nzStep]=\"step\" [ngModel]=\"start\"></nz-slider>",
                styles: [""]
            },] }
];
SliderComponent.ctorParameters = () => [];
SliderComponent.propDecorators = {
    max: [{ type: Input }],
    disable: [{ type: Input }],
    step: [{ type: Input }],
    start: [{ type: Input }]
};

class TabComponent {
    constructor() { }
    ngOnInit() {
    }
}
TabComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-tab',
                template: "<nz-tabset>\r\n    <nz-tab *ngFor=\"let tab of tabs\" [nzTitle]=\"tab.name\" [nzDisabled]=\"tab.disabled\">\r\n        {{ tab.name }}\r\n    </nz-tab>\r\n</nz-tabset>",
                styles: [""]
            },] }
];
TabComponent.ctorParameters = () => [];
TabComponent.propDecorators = {
    tabs: [{ type: Input }]
};

class TooltipComponent {
    constructor() { }
    ngOnInit() {
    }
}
TooltipComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-tooltip',
                template: "<span nz-tooltip [nzTooltipTitle]=\"title\">{{content}}</span>",
                styles: [""]
            },] }
];
TooltipComponent.ctorParameters = () => [];
TooltipComponent.propDecorators = {
    title: [{ type: Input }],
    content: [{ type: Input }]
};

class ElevationComponent {
    constructor() { }
    ngOnInit() {
    }
}
ElevationComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-elevation',
                template: "<div class=\"elevation\">\r\n    <div class=\"elevation-container\">\r\n        <p>01 dp</p>\r\n        <div class=\"spt-elevation--1 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>02 dp</p>\r\n        <div class=\"spt-elevation--2 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>06 dp</p>\r\n        <div class=\"spt-elevation--3 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>08 dp</p>\r\n        <div class=\"spt-elevation--4 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>12 dp</p>\r\n        <div class=\"spt-elevation--5 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>24 dp</p>\r\n        <div class=\"spt-elevation--6 elevation-box\"></div>\r\n    </div>\r\n</div>\r\n",
                styles: [".elevation{display:flex;flex-wrap:wrap}.elevation .elevation-container{margin-top:20px}.elevation .elevation-container p{margin-bottom:5px}.elevation .elevation-container .elevation-box{width:280px;height:184px;margin:10px}"]
            },] }
];
ElevationComponent.ctorParameters = () => [];

class SpacingComponent {
    constructor() {
        this.spacing = [
            {
                sectionName: '8px',
                sectionClassName: 'spacing--8',
                sections: [
                    { label: '8px (around)', className: 'spt-spacing--1' },
                    { label: '8px (vertical)', className: 'spt-spacing-y--1' },
                    { label: '8px (horizontal)', className: 'spt-spacing-x--1' },
                    { label: '8px (top)', className: 'spt-spacing-y-top--1' },
                    { label: '8px (bottom)', className: 'spt-spacing-y-bottom--1' },
                    { label: '8px (left)', className: 'spt-spacing-y-left--1' },
                    { label: '8px (right)', className: 'spt-spacing-y-right--1' },
                ]
            },
            {
                sectionName: '16px',
                sectionClassName: 'spacing--16',
                sections: [
                    { label: '16px (around)', className: 'spt-spacing--2' },
                    { label: '16px (top)', className: 'spt-spacing-y-top--2' },
                    { label: '8px (vertical)', className: 'spt-spacing-y--2' },
                    { label: '8px (horizontal)', className: 'spt-spacing-x--2' },
                    { label: '16px (bottom)', className: 'spt-spacing-y-bottom--2' },
                    { label: '16px (left)', className: 'spt-spacing-y-left--2' },
                    { label: '16px (right)', className: 'spt-spacing-y-right--2' },
                ]
            }
        ];
        this.spacing = this.getSpacing();
    }
    ngOnInit() {
    }
    getSpacing() {
        const spacing = [];
        const offsetArr = [1, 2, 3, 6, 8, 10, 14];
        const sections = [
            { label: '(around)', className: 'spt-spacing' },
            { label: '(vertical)', className: 'spt-spacing-y' },
            { label: '(horizontal)', className: 'spt-spacing-x' },
            { label: '(top)', className: 'spt-spacing-y-top' },
            { label: '(bottom)', className: 'spt-spacing-y-bottom' },
            { label: '(left)', className: 'spt-spacing-y-left' },
            { label: '(right)', className: 'spt-spacing-y-right' },
        ];
        offsetArr.forEach((offset, i) => {
            const size = 8 * offset;
            const currentSections = Array.from(sections, s => {
                return {
                    label: `${size}px ${s.label}`,
                    className: `${s.className}--${i + 1}`
                };
            });
            const newSection = {
                sectionClassName: `spacing--${size}`,
                sectionName: `${size}px`,
                sections: currentSections
            };
            spacing.push(newSection);
        });
        return spacing;
    }
}
SpacingComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-spacing',
                template: "<div class=\"spacing\">\r\n    <div *ngFor=\"let section of spacing\" class=\"spacing-section\">\r\n        <h3>{{ section.sectionName }}</h3>\r\n        <div class=\"spacing-container\">\r\n            <div *ngFor=\"let subsection of section.sections\" class=\"spacing-example\">\r\n                <div class=\"spacing-wrapper spt-elevation--2 {{ section.sectionClassName }} {{subsection.className}}\">\r\n                    <div class=\"spacing-box\">\r\n                        <p class=\"spacing-label\">{{ subsection.label }}</p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n",
                styles: [".spacing .spacing-section{padding-top:20px}.spacing .spacing-section .spacing-container{display:flex;align-content:center;flex-wrap:wrap}.spacing .spacing-section .spacing-container .spacing-example{text-align:center;padding:10px}.spacing .spacing-section .spacing-container .spacing-example .spacing--8{background-color:rgba(239,83,80,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--16{background-color:rgba(236,64,122,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--24{background-color:rgba(171,71,188,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--48{background-color:rgba(126,87,194,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--64{background-color:rgba(92,107,192,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--80{background-color:rgba(66,165,245,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--112{background-color:rgba(38,198,218,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing-wrapper{width:-webkit-fit-content;width:-moz-fit-content;width:fit-content;margin:0 auto}.spacing .spacing-section .spacing-container .spacing-example .spacing-wrapper .spacing-box{width:80px;height:80px;background-color:#fff;display:flex;align-items:center;justify-content:center}.spacing .spacing-section .spacing-container .spacing-example .spacing-wrapper .spacing-box p{font-size:12px}"]
            },] }
];
SpacingComponent.ctorParameters = () => [];

class IconComponent {
    constructor() {
        this.color = '#0D0C0B';
        this.svgIconSettings = {
            'height': '20px',
            'fill': this.color
        };
    }
    ngOnInit() { }
}
IconComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-icon',
                template: "<span nz-tooltip [nzTooltipTitle]=\"toolTipTittle\">\r\n  <svg-icon class=\"icons\" nz-icon [name]=\"name\" [svgStyle]=\"svgIconSettings\">\r\n  </svg-icon>\r\n</span>\r\n",
                styles: [""]
            },] }
];
IconComponent.ctorParameters = () => [];
IconComponent.propDecorators = {
    toolTipTittle: [{ type: Input }],
    name: [{ type: Input }],
    color: [{ type: Input }]
};

class DataVisualizationComponent {
    constructor() { }
    ngOnInit() {
    }
}
DataVisualizationComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-data-visualization',
                template: "<div class=\"data-visualization\">\r\n  <span class=\"data-visualization-title\">{{ title }}</span>\r\n  <span class=\"data-visualization-description\">{{ description }}</span>\r\n  <ng-content></ng-content>\r\n</div>\r\n",
                styles: [".data-visualization{border:1px solid #e2e2e2;border-radius:4px;padding:32px;background-color:#fff}.data-visualization-title{display:flex;font-family:Nunito;font-style:normal;font-weight:700;font-size:48px;line-height:56px}.data-visualization-description{display:flex;font-family:Nunito Sans;font-style:normal;font-weight:400;font-size:16px;line-height:24px}"]
            },] }
];
DataVisualizationComponent.ctorParameters = () => [];
DataVisualizationComponent.propDecorators = {
    title: [{ type: Input }],
    description: [{ type: Input }]
};

class ChartComponent {
    constructor() {
        this.options = {};
        this.data = [];
        this.labels = [];
    }
    ngOnInit() {
    }
}
ChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-chart',
                template: "<div style=\"width: 100%;\">\r\n  <canvas\r\n    baseChart\r\n    [chartType]=\"type\"\r\n    [datasets]=\"data\"\r\n    [labels]=\"labels\"\r\n    [options]=\"options\"\r\n    [legend]=\"true\"\r\n  >\r\n  </canvas>\r\n</div>\r\n",
                styles: [""]
            },] }
];
ChartComponent.ctorParameters = () => [];
ChartComponent.propDecorators = {
    options: [{ type: Input }],
    data: [{ type: Input }],
    labels: [{ type: Input }],
    type: [{ type: Input }]
};
var ChartType;
(function (ChartType) {
    ChartType["pie"] = "pie";
    ChartType["doughnut"] = "doughnut";
    ChartType["bar"] = "bar";
    ChartType["line"] = "line";
    ChartType["polarArea"] = "polarArea";
    ChartType["radar"] = "radar";
    ChartType["horizontalBar"] = "horizontalBar";
})(ChartType || (ChartType = {}));

class DialogsComponent {
    constructor(modal, viewContainerRef) {
        this.modal = modal;
        this.viewContainerRef = viewContainerRef;
    }
    createModal(dialog) {
        this.dialog = dialog;
        this.createTplModal(this.tplTitle, this.tplContent, this.tplFooter);
    }
    createTplModal(tplTitle, tplContent, tplFooter) {
        this.modalRef = this.modal.create({
            nzTitle: tplTitle,
            nzContent: tplContent,
            nzFooter: tplFooter,
            nzMaskClosable: false,
            nzClosable: true,
        });
    }
    ngOnInit() {
    }
}
DialogsComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-dialogs',
                template: "<ng-template #tplTitle>\r\n  <span class=\"title\">\r\n    {{ dialog.title }}\r\n  </span>\r\n</ng-template>\r\n<ng-template #tplContent>\r\n  <span class=\"content\">\r\n    {{ dialog.content }}\r\n  </span>\r\n</ng-template>\r\n<ng-template #tplFooter let-ref=\"modalRef\">\r\n  <button\r\n    nz-button\r\n    nzType=\"secondary\"\r\n    (click)=\"modalRef.destroy(); dialog.action1()\"\r\n  >\r\n    {{ dialog.action1Label }}\r\n  </button>\r\n  <button\r\n    nz-button\r\n    nzType=\"primary\"\r\n    (click)=\"modalRef.destroy(); dialog.action2()\"\r\n  >\r\n    {{ dialog.action2Label }}\r\n  </button>\r\n</ng-template>\r\n",
                styles: [".title{font-family:Nunito;font-weight:700;font-size:24px;line-height:32px;color:#0d0c0b}.content,.title{font-style:normal}.content{font-family:Nunito Sans;font-weight:400;font-size:16px;line-height:24px;color:#4f4e4d}"]
            },] }
];
DialogsComponent.ctorParameters = () => [
    { type: NzModalService },
    { type: ViewContainerRef }
];
DialogsComponent.propDecorators = {
    tplTitle: [{ type: ViewChild, args: ['tplTitle',] }],
    tplContent: [{ type: ViewChild, args: ['tplContent',] }],
    tplFooter: [{ type: ViewChild, args: ['tplFooter',] }]
};

const appExpandMoreIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7.71 9.29l3.88 3.88 3.88-3.88a.996.996 0 111.41 1.41l-4.59 4.59a.996.996 0 01-1.41 0L6.29 10.7a.996.996 0 010-1.41c.39-.38 1.03-.39 1.42 0z" fill="#0D0C0B"/></svg>`,
    name: 'expand-more'
};

const appLogoutIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 5h6c.55 0 1-.45 1-1s-.45-1-1-1H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h6c.55 0 1-.45 1-1s-.45-1-1-1H5V5z" fill="#0D0C0B"/><path d="M20.65 11.65l-2.79-2.79a.501.501 0 00-.86.35V11h-7c-.55 0-1 .45-1 1s.45 1 1 1h7v1.79c0 .45.54.67.85.35l2.79-2.79c.2-.19.2-.51.01-.7z" fill="#0D0C0B"/></svg>`,
    name: 'logout'
};

const appAccountBoxIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M3 5v14a2 2 0 002 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2H5a2 2 0 00-2 2zm12 4c0 1.66-1.34 3-3 3s-3-1.34-3-3 1.34-3 3-3 3 1.34 3 3zm-9 8c0-2 4-3.1 6-3.1s6 1.1 6 3.1v1H6v-1z" fill="#0D0C0B"/></svg>`,
    name: 'account-box'
};

const appExpandLessIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7.71 15.29l3.88-3.88 3.88 3.88a.996.996 0 101.41-1.41l-4.59-4.59a.996.996 0 00-1.41 0l-4.59 4.59a.996.996 0 000 1.41c.39.38 1.03.39 1.42 0z" fill="#0D0C0B"/></svg>`,
    name: 'expand-less'
};

const appKeyboardTabIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M11.71 8.12L8.83 11H21c.55 0 1 .45 1 1s-.45 1-1 1H8.83l2.88 2.88a.996.996 0 11-1.41 1.41L5.71 12.7a.996.996 0 010-1.41L10.3 6.7a.996.996 0 011.41 0c.38.39.39 1.03 0 1.42zM4 7v10c0 .55-.45 1-1 1s-1-.45-1-1V7c0-.55.45-1 1-1s1 .45 1 1z" fill="#0D0C0B"/></svg>`,
    name: 'keyboard-tab'
};

class SidebarComponent {
    constructor() {
        this.sidebarData = {};
        this.userDisplay = {};
        this.otherAccounts = [];
        this.AccountsDisplay = this.otherAccounts;
        this.multipleAccounts = false;
        this.avatarSize = AvatarSize.medium;
        this.keyboarTab = appKeyboardTabIcon.name;
        this.expandLess = appExpandLessIcon.name;
        this.accountBox = appAccountBoxIcon.name;
        this.logoutIcon = appLogoutIcon.name;
        this.expandMore = appExpandMoreIcon.name;
        this.buttonType = ButtonType.secondary;
        this.buttonSize = ButtonSize.medium;
        this.iconColor = '#FFF';
        this.isCollapse = false;
        this.onToggleLogout = false;
        this.multipleAccountsSelection = false;
        this.MenuWidht = '280px';
        this.MenuHeight = '857px';
        this.OptionWidht = '240px';
        this.lineRight = '-20px';
    }
    ngOnInit() {
        if (this.sidebarData.users.length > 1) {
            this.multipleAccounts = true;
        }
        this.sidebarData.users.forEach((user) => {
            this.sidebarData.users.indexOf(user) === 0 ? this.userDisplay = user : this.otherAccounts.push(user);
        });
    }
    onCollapse() {
        if (this.isCollapse) {
            this.isCollapse = false;
            this.MenuWidht = '280px';
            this.OptionWidht = '240px';
            this.lineRight = '-20px';
        }
        else if (!this.isCollapse && this.onToggleLogout) {
            this.isCollapse = true;
            this.MenuWidht = '88px';
            this.OptionWidht = '46px';
            this.lineRight = '-22px';
            this.onToggleLogout = false;
            this.MenuHeight = '857px';
        }
        else {
            this.isCollapse = true;
            this.MenuWidht = '88px';
            this.OptionWidht = '46px';
            this.lineRight = '-22px';
            this.multipleAccountsSelection = false;
        }
    }
    onActive(option) {
        this.optionsData.forEach((e) => {
            if (e.title === option.title) {
                option.isActive = true;
            }
            else {
                e.isActive = false;
            }
        });
    }
    toggleLogout() {
        if (this.onToggleLogout && !this.isCollapse) {
            this.onToggleLogout = false;
            this.MenuHeight = '857px';
        }
        else {
            this.onToggleLogout = true;
            this.MenuHeight = '780px';
        }
    }
    expandAccounts() {
        if (this.multipleAccountsSelection) {
            this.multipleAccountsSelection = false;
        }
        else {
            this.multipleAccountsSelection = true;
        }
    }
    switchAccount(account) {
        this.userDisplay = {};
        this.otherAccounts = [];
        this.sidebarData.users.forEach((user) => {
            user.id === account.id ? this.userDisplay = user : this.otherAccounts.push(user);
        });
    }
    filter() {
        this.AccountsDisplay = [];
        this.otherAccounts.filter((user) => {
            const test = user.name.toLocaleLowerCase().includes(this.inputFilter.toLocaleLowerCase());
            if (test) {
                this.AccountsDisplay.push(user);
            }
        });
    }
}
SidebarComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-sidebar',
                template: "<div class=\"container\" [ngStyle]=\"{ width: MenuWidht }\">\r\n  <div class=\"user\">\r\n    <spt-avatar [text]=\"userDisplay.name.charAt(0).toUpperCase()\"></spt-avatar>\r\n    <div class=\"text\" *ngIf=\"!isCollapse\">\r\n      <span>{{ userDisplay.name }}</span>\r\n      <span>{{ userDisplay.company }}</span>\r\n    </div>\r\n    <spt-icon\r\n      class=\"icons\"\r\n      [toolTipTittle]=\"expandMore\"\r\n      [name]=\"expandMore\"\r\n      *ngIf=\"multipleAccounts && !isCollapse\"\r\n      (click)=\"expandAccounts()\"\r\n      [color]=\"iconColor\"\r\n    ></spt-icon>\r\n    <div\r\n      *ngIf=\"multipleAccountsSelection && !isCollapse\"\r\n      class=\"multiAccount spt-elevation--3 elevation-box\"\r\n    >\r\n      <spt-text-field\r\n        [placeholder]=\"'Filter by name'\"\r\n        [(ngModel)]=\"inputFilter\"\r\n        (ngModelChange)=\"filter()\"\r\n      ></spt-text-field>\r\n      {{ inputFilter }}\r\n      <div\r\n        class=\"userMultiAccount\"\r\n        *ngFor=\"let account of AccountsDisplay\"\r\n        (click)=\"switchAccount(account)\"\r\n      >\r\n        <spt-avatar [text]=\"account.title.charAt(0).toUpperCase()\"></spt-avatar>\r\n        <div class=\"text-multiple-accounts\" *ngIf=\"!isCollapse\">\r\n          <span>{{ account.name }}</span>\r\n          <span>{{ account.company }}</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <spt-divider></spt-divider>\r\n  <div class=\"menu\" [ngStyle]=\"{ height: MenuHeight }\">\r\n    <div\r\n      *ngFor=\"let option of optionsData\"\r\n      class=\"option\"\r\n      [ngStyle]=\"{ width: OptionWidht }\"\r\n      [ngClass]=\"{ active: option.isActive }\"\r\n      (click)=\"onActive(option)\"\r\n    >\r\n      <spt-icon\r\n        class=\"icons\"\r\n        [toolTipTittle]=\"option.title\"\r\n        [name]=\"option.icon.name\"\r\n        [color]=\"iconColor\"\r\n      ></spt-icon>\r\n      <span *ngIf=\"!isCollapse\">{{ option.title }}</span>\r\n      <div\r\n        class=\"orange-line\"\r\n        [ngStyle]=\"{ right: lineRight }\"\r\n        *ngIf=\"option.isActive\"\r\n      ></div>\r\n    </div>\r\n  </div>\r\n  <spt-divider></spt-divider>\r\n  <div class=\"collapse\" (click)=\"onCollapse()\">\r\n    <spt-icon\r\n      class=\"icons\"\r\n      [toolTipTittle]=\"keyboarTab\"\r\n      [name]=\"keyboarTab\"\r\n      [color]=\"iconColor\"\r\n    ></spt-icon>\r\n  </div>\r\n  <spt-divider></spt-divider>\r\n  <div class=\"user-email\">\r\n    <div class=\"user\">\r\n      <div class=\"text\" *ngIf=\"!isCollapse\">\r\n        <span>{{ userDisplay.name }}</span>\r\n        <span class=\"small\">{{ userDisplay.email }}</span>\r\n      </div>\r\n      <spt-icon\r\n        class=\"icons\"\r\n        [toolTipTittle]=\"expandLess\"\r\n        [name]=\"expandLess\"\r\n        *ngIf=\"!onToggleLogout\"\r\n        (click)=\"toggleLogout()\"\r\n        [color]=\"iconColor\"\r\n      ></spt-icon>\r\n      <spt-icon\r\n        class=\"icons\"\r\n        [toolTipTittle]=\"accountBox\"\r\n        [name]=\"accountBox\"\r\n        *ngIf=\"onToggleLogout\"\r\n        (click)=\"toggleLogout()\"\r\n        [color]=\"iconColor\"\r\n      ></spt-icon>\r\n    </div>\r\n    <div class=\"flex-btn\" *ngIf=\"onToggleLogout && !isCollapse\">\r\n      <spt-button\r\n        class=\"btn\"\r\n        [text]=\"'LOGOUT'\"\r\n        [type]=\"buttonType\"\r\n        [size]=\"buttonSize\"\r\n        [leftIcon]=\"logoutIcon\"\r\n        (click)=\"sidebarData.logout()\"\r\n      ></spt-button>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
                styles: [".container{height:1080px;background-color:#0d0c0b;color:#d2d2d2;font-family:Nunito Sans;font-style:normal;font-size:16px;line-height:24px;z-index:1}.icons{padding-top:4px;margin:10px}.user,.userMultiAccount{position:relative;display:flex;flex-direction:row;align-items:center;padding:20px}.elevation-box{position:absolute;width:280px;left:24px;top:64px;background-color:#fff;z-index:2}.text,.text-multiple-accounts{display:flex;flex-direction:column}.text .small{font-weight:400;font-size:12px;line-height:16px;color:#b1b1b1}.text-multiple-accounts{color:#000}.multiAccount{display:flex;flex-direction:column;padding:20px;justify-content:space-around}.userMultiAccount{margin:10px 0 0;border-radius:4px;padding:12px 6px}.userMultiAccount:hover{background-color:#2e2d2c}.userMultiAccount:hover span{color:#fff}.textFiel{width:80%}.menu{padding:20px}.menu .option{position:relative;display:flex;align-items:center;width:240px;height:48px;padding:12px 6px 12px 6;border-radius:4px;margin:16px 0}.menu .option:hover{background-color:#2e2d2c;color:#f90}.menu .orange-line{position:absolute;right:-20px;background-color:#f90;width:4px;height:40px;border-radius:30px 0 0 30px}.collapse{padding:20px;display:flex;align-items:center;width:240px;height:48px}.active{background-color:#2e2d2c}.user-email{display:flex;flex-direction:column}.flex-btn{display:flex;justify-content:center}spt-icon span svg-icon svg path{fill:#d2d2d2}"]
            },] }
];
SidebarComponent.ctorParameters = () => [];
SidebarComponent.propDecorators = {
    sidebarData: [{ type: Input }],
    optionsData: [{ type: Input }]
};

class TableComponent {
    constructor() { }
    ngOnInit() {
        this.totalData = this.dataSet.length;
    }
}
TableComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-table',
                template: "<nz-table class=\"table\" #secondTable [nzData]=\"dataSet\">\r\n  <thead>\r\n    <tr>\r\n      <th *ngIf=\"checkboxOn\">\r\n        <spt-checkbox></spt-checkbox>\r\n      </th>\r\n      <th *ngFor=\"let title of rows\">\r\n        <b>{{ title }}</b>\r\n      </th>\r\n    </tr>\r\n  </thead>\r\n  <tbody>\r\n    <tr *ngFor=\"let data of secondTable.data\">\r\n      <td *ngIf=\"checkboxOn\">\r\n        <spt-checkbox></spt-checkbox>\r\n      </td>\r\n      <td>{{ data.number }}</td>\r\n      <td>{{ data.date }}</td>\r\n      <td>{{ data.description }}</td>\r\n      <td>{{ data.amount }}</td>\r\n      <td>\r\n        <spt-badge\r\n          [name]=\"data.status ? 'PAID' : 'NOT PAID'\"\r\n          color=\"#66BB6A\"\r\n        ></spt-badge>\r\n      </td>\r\n      <td>{{ data.invoice }}</td>\r\n    </tr>\r\n  </tbody>\r\n</nz-table>\r\n",
                styles: [".table{font-family:Nunito Sans;font-style:normal;font-weight:400;font-size:14px;line-height:24px;border:1px solid #e2e2e2;border-radius:4px}thead,tr:hover{background-color:#fff}thead>tr>th{background:#fff}"]
            },] }
];
TableComponent.ctorParameters = () => [];
TableComponent.propDecorators = {
    checkboxOn: [{ type: Input }],
    rows: [{ type: Input }],
    dataSet: [{ type: Input }]
};

const appUploadFileIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19.41 7.41l-4.83-4.83c-.37-.37-.88-.58-1.41-.58H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8.83c0-.53-.21-1.04-.59-1.42zM14.8 15H13v3c0 .55-.45 1-1 1s-1-.45-1-1v-3H9.21c-.45 0-.67-.54-.35-.85l2.8-2.79c.2-.19.51-.19.71 0l2.79 2.79c.3.31.08.85-.36.85zM14 9c-.55 0-1-.45-1-1V3.5L18.5 9H14z" fill="#0D0C0B"/></svg>`,
    name: 'upload-file'
};

class UploadComponent {
    constructor(modal, viewContainerRef, msg) {
        this.modal = modal;
        this.viewContainerRef = viewContainerRef;
        this.msg = msg;
        this.uploadFile = appUploadFileIcon.name;
    }
    createModalUpload(upload) {
        this.upload = upload;
        this.createTplModal(this.tplTitle, this.tplContent, this.tplFooter);
    }
    createTplModal(tplTitle, tplContent, tplFooter) {
        this.modalRef = this.modal.create({
            nzTitle: tplTitle,
            nzContent: tplContent,
            nzFooter: tplFooter,
            nzMaskClosable: false,
            nzClosable: true,
        });
    }
    ngOnInit() {
    }
    handleChange({ file, fileList }) {
        const status = file.status;
        if (status === 'done') {
            this.msg.success(`${file.name} file uploaded successfully.`);
        }
        else if (status === 'error') {
            this.msg.error(`${file.name} file upload failed.`);
        }
    }
}
UploadComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-upload',
                template: "<ng-template #tplTitle>\r\n    <span class=\"title\">\r\n    {{ upload.title }}\r\n    </span>\r\n</ng-template>\r\n<ng-template #tplContent>\r\n    <span class=\"content\">\r\n    {{ upload.content }}\r\n  </span>\r\n  <br>\r\n  <br>\r\n    <nz-upload\r\n    nzType=\"drag\"\r\n    [nzMultiple]=\"true\"\r\n    nzAction=\"https://www.mocky.io/v2/5cc8019d300000980a055e76\"\r\n    (nzChange)=\"handleChange($event)\"\r\n    class=\"upload-box\"\r\n  >\r\n    <div class=\"upload-content\">\r\n      <spt-icon class=\"icons\" [toolTipTittle]=\"uploadFile\" [name]=\"uploadFile\"></spt-icon>\r\n      <span>Drag and Drop here</span>\r\n      <span>or</span>\r\n      <span><b>BROWSE FILES</b></span>\r\n\r\n    </div>\r\n    </nz-upload>\r\n\r\n    <div class=\"under-upload-text\">\r\n    <span>Accepted files</span>\r\n    <span>Maximum size</span>\r\n    </div>\r\n\r\n</ng-template>\r\n<ng-template #tplFooter let-ref=\"modalRef\">\r\n    <button nz-button nzType=\"secondary\" (click)=\"modalRef.destroy(); upload.action1()\">\r\n    {{ upload.action1Label }}\r\n  </button>\r\n</ng-template>\r\n",
                styles: [".title{font-family:Nunito;font-weight:700;font-size:24px;line-height:32px;color:#0d0c0b}.content,.title{font-style:normal}.content{font-family:Nunito Sans;font-weight:400;font-size:16px;line-height:24px;color:#4f4e4d}.upload-box{width:468px;height:304px;box-sizing:border-box;border-radius:4px}.upload-box,.upload-content{display:flex;flex-direction:column;align-items:center;justify-content:center}.upload-box:hover{background-color:#f3f3f3}.under-upload-text{display:flex;width:468px;justify-content:space-between;font-size:12px;line-height:16px;color:#909090}.icons{padding-top:4px;margin:10px}"]
            },] }
];
UploadComponent.ctorParameters = () => [
    { type: NzModalService },
    { type: ViewContainerRef },
    { type: NzMessageService }
];
UploadComponent.propDecorators = {
    tplTitle: [{ type: ViewChild, args: ['tplTitle',] }],
    tplContent: [{ type: ViewChild, args: ['tplContent',] }],
    tplFooter: [{ type: ViewChild, args: ['tplFooter',] }]
};

class HeaderComponent {
    constructor() {
        this.buttonType = ButtonType.primary;
        this.buttonSize = ButtonSize.medium;
    }
    ngOnInit() { }
}
HeaderComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-header',
                template: "<div class=\"header\">\r\n  <div class=\"sub-header-1\">\r\n    <spt-back-navigation\r\n      *ngIf=\"backTitle\"\r\n      [title]=\"backTitle\"\r\n    ></spt-back-navigation>\r\n    <spt-breadcrumb *ngIf=\"breadcrumbs\" [items]=\"breadcrumbs\"></spt-breadcrumb>\r\n    <span class=\"title\">{{ title }}</span>\r\n  </div>\r\n  <div class=\"sub-header-2\">\r\n    <div class=\"search\">\r\n      <spt-search *ngIf=\"search\"></spt-search>\r\n    </div>\r\n    <spt-button\r\n      *ngIf=\"btnTitle\"\r\n      [text]=\"btnTitle\"\r\n      [type]=\"buttonType\"\r\n      [size]=\"buttonSize\"\r\n      (click)=\"action()\"\r\n    ></spt-button>\r\n  </div>\r\n</div>\r\n",
                styles: [".header{display:flex;width:100%;flex-direction:row;justify-content:space-between;align-items:center;padding:24px 0}.sub-header-1{display:flex;flex-direction:column}.sub-header-2{display:flex;flex-direction:row;align-items:center;justify-content:flex-end}.search{width:300px;padding-right:30px}.title{font-family:Nunito;font-style:normal;font-weight:700;font-size:32px;line-height:48px;display:flex;align-items:center}"]
            },] }
];
HeaderComponent.ctorParameters = () => [];
HeaderComponent.propDecorators = {
    title: [{ type: Input }],
    backTitle: [{ type: Input }],
    breadcrumbs: [{ type: Input }],
    btnTitle: [{ type: Input }],
    search: [{ type: Input }],
    action: [{ type: Input }]
};

const appRedeemIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M20 6h-2.18c.11-.31.18-.65.18-1a2.996 2.996 0 00-5.5-1.65l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7.6 10.02a.995.995 0 00.22 1.4c.44.32 1.07.22 1.39-.22L12 7.4l2.79 3.8c.32.44.95.54 1.39.22.45-.32.55-.95.22-1.4L14.92 8H20v6z" fill="#0D0C0B"/></svg>`,
    name: 'redeem'
};

const appCallIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M15.63 14.4l-2.52 2.5c-2.5-1.43-4.57-3.5-6-6l2.5-2.52c.23-.24.33-.57.27-.9L9.13 3.8c-.09-.46-.5-.8-.98-.8H4c-.56 0-1.03.47-1 1.03.17 2.89 1.05 5.6 2.43 7.97 1.58 2.73 3.85 4.99 6.57 6.57 2.37 1.37 5.08 2.26 7.97 2.43.56.03 1.03-.44 1.03-1v-4.15c0-.48-.34-.89-.8-.98l-3.67-.73a.985.985 0 00-.9.26z" fill="#0D0C0B"/></svg>`,
    name: 'call'
};

const appEmailIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-.4 4.25l-7.07 4.42c-.32.2-.74.2-1.06 0L4.4 8.25a.85.85 0 11.9-1.44L12 11l6.7-4.19a.85.85 0 11.9 1.44z" fill="#0D0C0B"/></svg>`,
    name: 'email'
};

const appSmartphoneIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17 1H7c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2zm0 17H7V6h10v12z" fill="#0D0C0B"/></svg>`,
    name: 'smartphone'
};

const appEastIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M14.29 5.71a.996.996 0 000 1.41L18.17 11H3c-.55 0-1 .45-1 1s.45 1 1 1h15.18l-3.88 3.88a.996.996 0 101.41 1.41l5.59-5.59a.996.996 0 000-1.41l-5.6-5.58a.996.996 0 00-1.41 0z" fill="#0D0C0B"/></svg>`,
    name: 'east'
};

const appMoreVertIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" fill="#0D0C0B"/></svg>`,
    name: 'more-vert'
};

const appSmsIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 19.58c0 .89 1.08 1.34 1.71.71L6 18h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM8 11c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm4 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm4 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z" fill="#0D0C0B"/></svg>`,
    name: 'sms'
};

const appPeopleIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18"><path d="M11.25 6a4.485 4.485 0 00-.998-2.82c.316-.105.646-.18.998-.18a3 3 0 110 6 3.13 3.13 0 01-.922-.158l-.075-.022A4.485 4.485 0 0011.25 6zm1.245 3.848c1.028.697 1.755 1.642 1.755 2.902V15h3v-2.25c0-1.635-2.685-2.602-4.755-2.902zM6.75 3a3 3 0 110 6 3 3 0 110-6zm0 6.75c2.002 0 6 1.005 6 3V15h-12v-2.25c0-1.995 3.997-3 6-3z" fill="#0D0C0B"/></svg>`,
    name: 'people'
};

class CardComponent {
    constructor() {
        this.sms = appSmsIcon.name;
        this.people = appPeopleIcon.name;
        this.send = appEastIcon.name;
        this.moreVert = appMoreVertIcon.name;
        this.email = appEmailIcon.name;
        this.smartphone = appSmartphoneIcon.name;
        this.call = appCallIcon.name;
        this.redeem = appRedeemIcon.name;
        this.isSend = true;
        this.white = '#FFEBEE';
        this.red = '#EF5350';
        this.green = '#66BB6A';
        this.avatarSize = AvatarSize.large;
        this.btnType = ButtonType.secondary;
        this.buttonSize = ButtonSize.medium;
    }
    ngOnInit() {
        this.isMouseOver = false;
    }
    toggleCard() {
        if (this.isSend) {
            this.isSend = false;
        }
        else {
            this.isSend = true;
        }
    }
}
CardComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-card',
                template: "<div\r\n  [ngClass]=\"{ card: campaign || giftManagement, cardForCustomer: customer }\"\r\n  (mouseover)=\"isMouseOver = true\"\r\n  (mouseout)=\"isMouseOver = false\"\r\n  [ngStyle]=\"{ 'background-color': customer?.isSelect ? '#F3F3F3' : '' }\"\r\n>\r\n  <div class=\"col1\">\r\n    <div class=\"campaign\">\r\n      <div class=\"campaign\" *ngIf=\"campaign\">\r\n        <spt-icon\r\n          class=\"icons\"\r\n          [toolTipTittle]=\"campaign.plataform\"\r\n          [name]=\"campaign.plataform\"\r\n        ></spt-icon>\r\n        <span class=\"shadow-text\" *ngIf=\"campaign.plataform === 'sms'\"\r\n          ><b>{{ campaign.plataform | uppercase }}</b></span\r\n        >\r\n      </div>\r\n      <div\r\n        class=\"campaign\"\r\n        *ngIf=\"customer\"\r\n        [ngStyle]=\"{ 'background-color': !isMouseOver ? white : '' }\"\r\n      >\r\n        <spt-avatar\r\n          [hidden]=\"isMouseOver\"\r\n          [text]=\"customer.name | slice: 0:1\"\r\n          [size]=\"avatarSize\"\r\n          [backgroundColor]=\"white\"\r\n          [color]=\"red\"\r\n        ></spt-avatar>\r\n        <spt-checkbox\r\n          [hidden]=\"!isMouseOver\"\r\n          [check]=\"customer.isSelect\"\r\n          (onChangeEvent)=\"customer.isSelect = $event\"\r\n        ></spt-checkbox>\r\n      </div>\r\n      <div class=\"campaign\" *ngIf=\"giftManagement\">\r\n        <spt-icon\r\n          class=\"icons\"\r\n          [toolTipTittle]=\"redeem\"\r\n          [name]=\"redeem\"\r\n        ></spt-icon>\r\n      </div>\r\n    </div>\r\n    <div class=\"content\">\r\n      <div class=\"content\" *ngIf=\"campaign\">\r\n        <div class=\"sub-content1\">\r\n          <spt-badge\r\n            class=\"badge\"\r\n            [color]=\"campaign.isSend ? green : red\"\r\n            [name]=\"campaign.isSend ? 'SEND' : 'SENDING'\"\r\n          ></spt-badge>\r\n          <span class=\"shadow-text\">Created: {{ campaign.dateCreated }}</span>\r\n        </div>\r\n        <span>{{ campaign.title }}</span>\r\n        <div class=\"sub-content2\">\r\n          <spt-icon\r\n            class=\"icons\"\r\n            [toolTipTittle]=\"people\"\r\n            [name]=\"people\"\r\n          ></spt-icon>\r\n          <span class=\"shadow-text\">{{ campaign.targetGroup }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"content\" *ngIf=\"customer\">\r\n        <div class=\"sub-content3\">\r\n          <span>{{ customer.name }}</span>\r\n          <span class=\"shadow-text\"\r\n            >Member Since: {{ customer.dateCreated }}</span\r\n          >\r\n        </div>\r\n      </div>\r\n      <div class=\"content\" *ngIf=\"giftManagement\">\r\n        <div class=\"sub-content1\">\r\n          <spt-badge\r\n            class=\"badge\"\r\n            [name]=\"giftManagement.deliverProcess | uppercase\"\r\n            color=\"#66BB6A\"\r\n          ></spt-badge>\r\n          <span class=\"shadow-text\"\r\n            >Created: {{ giftManagement.dateCreated }}</span\r\n          >\r\n        </div>\r\n        <span\r\n          ><b>ID: {{ giftManagement.id }}</b></span\r\n        >\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"col2\">\r\n    <div class=\"col2\" *ngIf=\"campaign\">\r\n      <div class=\"printer-container\">\r\n        <span class=\"shadow-text\">Send</span>\r\n        <div class=\"printer\">\r\n          <span>{{ campaign.sendCount === 0 ? \"0\" : campaign.sendCount }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"sendIcon\">\r\n        <spt-icon class=\"icons\" [toolTipTittle]=\"send\" [name]=\"send\"></spt-icon>\r\n      </div>\r\n      <div class=\"printer-container\">\r\n        <span class=\"shadow-text\">Open</span>\r\n        <div class=\"printer\">\r\n          <span>{{\r\n            campaign.openCount === 0 ? \"--\" : campaign.openCount + \"%\"\r\n          }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"sendIcon\">\r\n        <spt-icon class=\"icons\" [toolTipTittle]=\"send\" [name]=\"send\"></spt-icon>\r\n      </div>\r\n      <div class=\"printer-container\">\r\n        <span class=\"shadow-text\">Visit</span>\r\n        <div class=\"printer\">\r\n          <span>{{\r\n            campaign.visitCount === 0 ? \"--\" : campaign.visitCount\r\n          }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"sendIcon\">\r\n        <spt-icon class=\"icons\" [toolTipTittle]=\"send\" [name]=\"send\"></spt-icon>\r\n      </div>\r\n      <div class=\"printer-container\">\r\n        <span class=\"shadow-text\">Spend</span>\r\n        <div class=\"printer\">\r\n          <span>{{\r\n            campaign.spendCount === 0 ? \"--\" : \"$\" + campaign.spendCount\r\n          }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"moreVertIcon\">\r\n        <spt-icon\r\n          class=\"icons\"\r\n          [toolTipTittle]=\"moreVert\"\r\n          [name]=\"moreVert\"\r\n          (click)=\"option()\"\r\n        ></spt-icon>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"col2\" *ngIf=\"customer\">\r\n      <div class=\"sub-content3\">\r\n        <div>\r\n          <spt-icon\r\n            class=\"icons\"\r\n            [toolTipTittle]=\"email\"\r\n            [name]=\"email\"\r\n          ></spt-icon>\r\n          <span class=\"shadow-text\">Email</span>\r\n        </div>\r\n        <div class=\"sub-content4\">\r\n          <span>{{ customer.email }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"sub-content3\">\r\n        <div>\r\n          <spt-icon class=\"icons\" [toolTipTittle]=\"call\" [name]=\"call\"></spt-icon>\r\n          <span class=\"shadow-text\">Phone</span>\r\n        </div>\r\n        <div class=\"sub-content4\">\r\n          <span>{{ customer.phone }}</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n    <div class=\"col2\" *ngIf=\"giftManagement\">\r\n      <div class=\"sub-content3\">\r\n        <div>\r\n          <spt-icon\r\n            class=\"icons\"\r\n            [toolTipTittle]=\"email\"\r\n            [name]=\"email\"\r\n          ></spt-icon>\r\n          <span class=\"shadow-text\">Email</span>\r\n        </div>\r\n        <div class=\"sub-content4\">\r\n          <span>{{ giftManagement.email }}</span>\r\n        </div>\r\n      </div>\r\n      <div class=\"sub-content3\">\r\n        <div>\r\n          <spt-icon class=\"icons\" [toolTipTittle]=\"call\" [name]=\"call\"></spt-icon>\r\n          <span class=\"shadow-text\">Phone</span>\r\n        </div>\r\n        <div class=\"sub-content4\">\r\n          <span>{{ giftManagement.phone }}</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"col3\" *ngIf=\"giftManagement\">\r\n    <spt-button\r\n      [size]=\"buttonSize\"\r\n      [type]=\"btnType\"\r\n      [text]=\"'CANCEL'\"\r\n      (click)=\"cancel()\"\r\n    ></spt-button>\r\n    <spt-button\r\n      [size]=\"buttonSize\"\r\n      [type]=\"btnType\"\r\n      [text]=\"'GO TO GUEST'\"\r\n      (click)=\"goToGuest()\"\r\n    ></spt-button>\r\n  </div>\r\n</div>\r\n",
                styles: [".card,.cardForCustomer{display:flex;justify-content:space-between;height:120px;border:1px solid #e2e2e2;border-radius:4px;font-family:Nunito Sans;font-style:normal;font-weight:700;font-size:16px;line-height:24px}.cardForCustomer{justify-content:flex-start}.card:active{background-color:#f3f3f3}.col1{width:400px;display:flex;flex-direction:row}.campaign{min-width:120px;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;background-color:#f3f3f3}.content{width:100%;margin:8px 0 8px 24px}.sub-content1 nz-tag{margin:0}.sub-content2{display:flex;align-items:center}.sub-content3{width:250px;height:100%;display:flex;flex-direction:column;justify-content:space-evenly}.sub-content4{margin-left:40px}.shadow-text{color:#909090;font-weight:400;font-size:14px;padding-left:10px}.col2{display:flex;flex-direction:row;align-items:center}.printer-container{display:flex;flex-direction:column;justify-content:center}.printer{display:flex;align-items:center;width:144px;height:48px;background-color:#f3f3f3;border-radius:4px;padding:10px}.sendIcon{padding-top:30px;margin:0 15px 0 10px}.moreVertIcon{padding-bottom:60px}.col3{width:300px;display:flex;flex-direction:row;align-items:center;justify-content:space-between;padding:0 15px}.active{background-color:#f3f3f3}"]
            },] }
];
CardComponent.ctorParameters = () => [];
CardComponent.propDecorators = {
    campaign: [{ type: Input }],
    customer: [{ type: Input }],
    giftManagement: [{ type: Input }],
    option: [{ type: Input }],
    cancel: [{ type: Input }],
    goToGuest: [{ type: Input }]
};

const appCheckCircleIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.95 8.23l-5.66 5.66a.996.996 0 01-1.41 0l-2.83-2.83a.996.996 0 111.41-1.41l2.12 2.12 4.95-4.95a.996.996 0 011.41 0c.4.39.4 1.02.01 1.41z" fill="#0D0C0B"/></svg>`,
    name: 'check-circle'
};

const appExpandIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M4 5v14c0 .55-.45 1-1 1s-1-.45-1-1V5c0-.55.45-1 1-1s1 .45 1 1zm18 0v14c0 .55-.45 1-1 1s-1-.45-1-1V5c0-.55.45-1 1-1s1 .45 1 1zm-7 8v1.79c0 .45.54.67.85.35l2.79-2.79c.2-.2.2-.51 0-.71l-2.79-2.79a.5.5 0 00-.85.36V11H9V9.21c0-.45-.54-.67-.85-.35l-2.79 2.79c-.2.2-.2.51 0 .71l2.79 2.79A.5.5 0 009 14.8V13h6z" fill="#0D0C0B"/></svg>`,
    name: 'expand'
};

const appFavoriteIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M10.67 19.8C5.15 14.85 1.95 12.16 2 8.41c.04-2.97 2.3-4.39 2.35-4.43 3.61-2.46 6.89.22 7.65 1.11.75-.88 3.99-3.51 7.56-1.16.52.34 2.23 1.65 2.42 4.12.32 4.28-4.14 7.76-8.65 11.76-.38.34-.86.5-1.34.5-.47 0-.94-.17-1.32-.51z" fill="#0D0C0B"/></svg>`,
    name: 'favorite'
};

const appHomeIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M10.8 3.9l-6 4.5c-.5.38-.8.97-.8 1.6v9c0 1.1.9 2 2 2h4v-7h4v7h4c1.1 0 2-.9 2-2v-9c0-.63-.3-1.22-.8-1.6l-6-4.5a2.01 2.01 0 00-2.4 0z" fill="#0D0C0B"/></svg>`,
    name: 'home'
};

const appSearchIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M20.29 18.88l-5.56-5.56c1.13-1.55 1.63-3.58.98-5.74-.68-2.23-2.57-3.98-4.85-4.44a6.511 6.511 0 00-7.72 7.72c.46 2.29 2.21 4.18 4.44 4.85 2.16.65 4.19.15 5.74-.98l5.56 5.56a.996.996 0 101.41-1.41zM5 9.5C5 7.01 7.01 5 9.5 5S14 7.01 14 9.5 11.99 14 9.5 14 5 11.99 5 9.5z" fill="#0D0C0B"/></svg>`,
    name: 'search'
};

const appSettingsIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19.5 12c0-.23-.01-.45-.03-.68l1.86-1.41c.4-.3.51-.86.26-1.3l-1.87-3.23a.987.987 0 00-1.25-.42l-2.15.91c-.37-.26-.76-.49-1.17-.68l-.29-2.31c-.06-.5-.49-.88-.99-.88h-3.73c-.51 0-.94.38-1 .88l-.29 2.31c-.41.19-.8.42-1.17.68l-2.15-.91c-.46-.2-1-.02-1.25.42L2.41 8.62c-.25.44-.14.99.26 1.3l1.86 1.41a7.343 7.343 0 000 1.35l-1.86 1.41c-.4.3-.51.86-.26 1.3l1.87 3.23c.25.44.79.62 1.25.42l2.15-.91c.37.26.76.49 1.17.68l.29 2.31c.06.5.49.88.99.88h3.73c.5 0 .93-.38.99-.88l.29-2.31c.41-.19.8-.42 1.17-.68l2.15.91c.46.2 1 .02 1.25-.42l1.87-3.23c.25-.44.14-.99-.26-1.3l-1.86-1.41c.03-.23.04-.45.04-.68zm-7.46 3.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z" fill="#0D0C0B"/></svg>`,
    name: 'settings'
};

const actionIcons = [appAccountBoxIcon, appCheckCircleIcon, appExpandIcon, appFavoriteIcon, appHomeIcon, appLogoutIcon, appRedeemIcon, appSearchIcon, appSettingsIcon];

const appErrorIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 11c-.55 0-1-.45-1-1V8c0-.55.45-1 1-1s1 .45 1 1v4c0 .55-.45 1-1 1zm0 4c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z" fill="#0D0C0B"/></svg>`,
    name: 'error'
};

const appWarningIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M2.73 21h18.53c.77 0 1.25-.83.87-1.5l-9.27-16a.996.996 0 00-1.73 0l-9.27 16c-.38.67.1 1.5.87 1.5zM12 15c-.55 0-1-.45-1-1v-3c0-.55.45-1 1-1s1 .45 1 1v3c0 .55-.45 1-1 1zm1 2c0 .55-.45 1-1 1s-1-.45-1-1 .45-1 1-1 1 .45 1 1z" fill="#0D0C0B"/></svg>`,
    name: 'warning'
};

const alertIcons = [appErrorIcon, appWarningIcon];

const appRecentActorsIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M13 5H3c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zM8 7.75c1.52 0 2.75 1.23 2.75 2.75S9.52 13.25 8 13.25s-2.75-1.23-2.75-2.75S6.48 7.75 8 7.75zM13 17H3v-.4c0-.79.46-1.53 1.19-1.83C5.36 14.27 6.65 14 8 14s2.64.27 3.81.76c.73.31 1.19 1.04 1.19 1.84v.4zM21 6v12c0 .55.45 1 1 1s1-.45 1-1V6c0-.55-.45-1-1-1s-1 .45-1 1zM18 19c.55 0 1-.45 1-1V6c0-.55-.45-1-1-1s-1 .45-1 1v12c0 .55.45 1 1 1z" fill="#0D0C0B"/></svg>`,
    name: 'recent-actors'
};

const avIcons = [appRecentActorsIcon];

const communicationIcons = [appCallIcon, appEmailIcon];

const appAddIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M18 13h-5v5c0 .55-.45 1-1 1s-1-.45-1-1v-5H6c-.55 0-1-.45-1-1s.45-1 1-1h5V6c0-.55.45-1 1-1s1 .45 1 1v5h5c.55 0 1 .45 1 1s-.45 1-1 1z" fill="#0D0C0B"/></svg>`,
    name: 'add'
};

const appAddCircleOutlineIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 7c-.55 0-1 .45-1 1v3H8c-.55 0-1 .45-1 1s.45 1 1 1h3v3c0 .55.45 1 1 1s1-.45 1-1v-3h3c.55 0 1-.45 1-1s-.45-1-1-1h-3V8c0-.55-.45-1-1-1zm0-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="#0D0C0B"/></svg>`,
    name: 'add-circle-outline'
};

const appReportIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M14.9 3H9.1c-.53 0-1.04.21-1.42.59l-4.1 4.1C3.21 8.06 3 8.57 3 9.1v5.8c0 .53.21 1.04.59 1.41l4.1 4.1c.37.38.88.59 1.41.59h5.8c.53 0 1.04-.21 1.41-.59l4.1-4.1c.38-.37.59-.88.59-1.41V9.1c0-.53-.21-1.04-.59-1.41l-4.1-4.1c-.37-.38-.88-.59-1.41-.59zM12 13c-.55 0-1-.45-1-1V8c0-.55.45-1 1-1s1 .45 1 1v4c0 .55-.45 1-1 1zm1 3c0 .55-.45 1-1 1s-1-.45-1-1 .45-1 1-1 1 .45 1 1z" fill="#0D0C0B"/></svg>`,
    name: 'report'
};

const appSendIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M3 5.51v3.71c0 .46.31.86.76.97L11 12l-7.24 1.81c-.45.11-.76.51-.76.97v3.71c0 .72.73 1.2 1.39.92l15.42-6.49c.82-.34.82-1.5 0-1.84L4.39 4.58C3.73 4.31 3 4.79 3 5.51z" fill="#0D0C0B"/></svg>`,
    name: 'send'
};

const contentIcons = [appAddCircleOutlineIcon, appAddIcon, appReportIcon, appSendIcon];

const fileIcons = [appUploadFileIcon];

const hardwareIcons = [appKeyboardTabIcon, appSmartphoneIcon];

const appEditIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M3 17.46v3.04c0 .28.22.5.5.5h3.04c.13 0 .26-.05.35-.15L17.81 9.94l-3.75-3.75L3.15 17.1c-.1.1-.15.22-.15.36zM20.71 5.63l-2.34-2.34a.996.996 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83a.996.996 0 000-1.41z" fill="#0D0C0B"/></svg>`,
    name: 'edit'
};

const appWbIncandescentIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 6c.56 0 1-.45 1-1V4c0-.55-.45-1-1-1s-1 .45-1 1v1c0 .55.45 1 1 1zM18.01 7.91l.71-.71a.996.996 0 10-1.41-1.41l-.71.71a.996.996 0 000 1.41c.38.38 1.02.38 1.41 0zM19 13c0 .55.45 1 1 1h1c.55 0 1-.45 1-1s-.45-1-1-1h-1c-.55 0-1 .45-1 1zM3 14h1c.55 0 1-.45 1-1s-.45-1-1-1H3c-.55 0-1 .45-1 1s.45 1 1 1zM5.99 7.91A.996.996 0 107.4 6.5l-.71-.71A.996.996 0 105.28 7.2l.71.71zM9 16.98V20c0 1.1.9 2 2 2h2c1.1 0 2-.9 2-2v-3.02c1.43-1.08 2.28-2.9 1.91-4.91-.36-1.95-1.9-3.55-3.84-3.95A4.995 4.995 0 007 13c0 1.63.79 3.06 2 3.98zm2 .92c.32.06.66.1 1 .1.34 0 .68-.04 1-.1V20h-2v-2.1z" fill="#0D0C0B"/></svg>`,
    name: 'wb-incandescent'
};

const imageIcons = [appEditIcon, appWbIncandescentIcon];

const appPlaceIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2c-4.2 0-8 3.22-8 8.2 0 3.18 2.45 6.92 7.34 11.23.38.33.95.33 1.33 0C17.55 17.12 20 13.38 20 10.2 20 5.22 16.2 2 12 2zm0 10c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z" fill="#0D0C0B"/></svg>`,
    name: 'place'
};

const mapsIcons = [appPlaceIcon];

const appArrowBackIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 11H7.83l4.88-4.88c.39-.39.39-1.03 0-1.42a.996.996 0 00-1.41 0l-6.59 6.59a.996.996 0 000 1.41l6.59 6.59a.996.996 0 101.41-1.41L7.83 13H19c.55 0 1-.45 1-1s-.45-1-1-1z" fill="#0D0C0B"/></svg>`,
    name: 'arrow-back'
};

const appArrowDownwardIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M11 5v11.17l-4.88-4.88c-.39-.39-1.03-.39-1.42 0a.996.996 0 000 1.41l6.59 6.59c.39.39 1.02.39 1.41 0l6.59-6.59a.996.996 0 10-1.41-1.41L13 16.17V5c0-.55-.45-1-1-1s-1 .45-1 1z" fill="#0D0C0B"/></svg>`,
    name: 'arrow-downward'
};

const appArrowForwardIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 13h11.17l-4.88 4.88c-.39.39-.39 1.03 0 1.42.39.39 1.02.39 1.41 0l6.59-6.59a.996.996 0 000-1.41l-6.58-6.6a.996.996 0 10-1.41 1.41L16.17 11H5c-.55 0-1 .45-1 1s.45 1 1 1z" fill="#0D0C0B"/></svg>`,
    name: 'arrow-forward'
};

const appArrowUpwardIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M13 19V7.83l4.88 4.88c.39.39 1.03.39 1.42 0a.996.996 0 000-1.41l-6.59-6.59a.996.996 0 00-1.41 0l-6.6 6.58a.996.996 0 101.41 1.41L11 7.83V19c0 .55.45 1 1 1s1-.45 1-1z" fill="#0D0C0B"/></svg>`,
    name: 'arrow-upward'
};

const appCancelBlackIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18"><path d="M9 1.5A7.493 7.493 0 001.5 9c0 4.148 3.353 7.5 7.5 7.5 4.148 0 7.5-3.352 7.5-7.5 0-4.147-3.352-7.5-7.5-7.5zm3.217 9.668a.747.747 0 11-1.057 1.057L9 10.057l-2.168 2.168a.747.747 0 11-1.057-1.057L7.942 9l-2.16-2.168A.747.747 0 116.84 5.775L9 7.942l2.168-2.167a.747.747 0 111.057 1.057L10.057 9l2.16 2.168z" fill="#0D0C0B"/></svg>`,
    name: 'cancel-black'
};

const appCheckIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M18 6.7l-8.48 8.48-3.54-3.54a.996.996 0 10-1.41 1.41l4.24 4.24c.39.39 1.02.39 1.41 0l9.18-9.18a.999.999 0 00-.01-1.42c-.37-.38-1-.38-1.39.01z" fill="#0D0C0B"/></svg>`,
    name: 'check'
};

const appChevronLeftIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M15.29 15.46l-3.88-3.88 3.88-3.88a.996.996 0 10-1.41-1.41l-4.59 4.59a.996.996 0 000 1.41l4.59 4.59c.39.39 1.02.39 1.41 0 .38-.39.39-1.03 0-1.42z" fill="#0D0C0B"/></svg>`,
    name: 'chevron-left'
};

const appChevronRightIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M9.29 15.46l3.88-3.88L9.29 7.7a.996.996 0 111.41-1.41l4.59 4.59c.39.39.39 1.02 0 1.41l-4.59 4.59a.996.996 0 01-1.41 0c-.38-.39-.39-1.03 0-1.42z" fill="#0D0C0B"/></svg>`,
    name: 'chevron-right'
};

const appClearIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M18.3 5.71a.996.996 0 00-1.41 0L12 10.59 7.11 5.7A.996.996 0 105.7 7.11L10.59 12 5.7 16.89a.996.996 0 101.41 1.41L12 13.41l4.89 4.89a.996.996 0 101.41-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z" fill="#000"/></svg>`,
    name: 'clear'
};

const appFirstPageIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.7 15.89L13.82 12l3.89-3.89A.996.996 0 1016.3 6.7l-4.59 4.59a.996.996 0 000 1.41l4.59 4.59c.39.39 1.02.39 1.41 0a.993.993 0 00-.01-1.4zM7 6c.55 0 1 .45 1 1v10c0 .55-.45 1-1 1s-1-.45-1-1V7c0-.55.45-1 1-1z" fill="#0D0C0B"/></svg>`,
    name: 'first-page'
};

const appLastPageIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M6.29 8.11L10.18 12l-3.89 3.89A.996.996 0 107.7 17.3l4.59-4.59a.996.996 0 000-1.41L7.7 6.7a.996.996 0 00-1.41 0c-.38.39-.38 1.03 0 1.41zM17 6c.55 0 1 .45 1 1v10c0 .55-.45 1-1 1s-1-.45-1-1V7c0-.55.45-1 1-1z" fill="#0D0C0B"/></svg>`,
    name: 'last-page'
};

const appRefreshIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.65 6.35a7.95 7.95 0 00-6.48-2.31c-3.67.37-6.69 3.35-7.1 7.02C3.52 15.91 7.27 20 12 20a7.98 7.98 0 007.21-4.56c.32-.67-.16-1.44-.9-1.44-.37 0-.72.2-.88.53a5.994 5.994 0 01-6.8 3.31c-2.22-.49-4.01-2.3-4.48-4.52A6.002 6.002 0 0112 6c1.66 0 3.14.69 4.22 1.78l-1.51 1.51c-.63.63-.19 1.71.7 1.71H19c.55 0 1-.45 1-1V6.41c0-.89-1.08-1.34-1.71-.71l-.64.65z" fill="#0D0C0B"/></svg>`,
    name: 'refresh'
};

const navigationIcons = [appArrowBackIcon, appArrowDownwardIcon, appArrowForwardIcon, appArrowUpwardIcon, appCancelBlackIcon, appCheckIcon, appChevronLeftIcon, appChevronRightIcon, appClearIcon, appEastIcon, appExpandLessIcon, appExpandMoreIcon, appFirstPageIcon, appLastPageIcon, appMoreVertIcon, appRefreshIcon];

const appPriorityHighIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 21a2 2 0 100-4 2 2 0 000 4zM12 3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2s2-.9 2-2V5c0-1.1-.9-2-2-2z" fill="#0D0C0B"/></svg>`,
    name: 'priority-high'
};

const notificationIcons = [appPriorityHighIcon, appSmsIcon];

const socialIcons = [appPeopleIcon];

const appCheckBoxIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9.88 15.54l-2.83-2.83a.996.996 0 111.41-1.41l2.12 2.12 4.95-4.95a.996.996 0 111.41 1.41l-5.66 5.66a.984.984 0 01-1.4 0z" fill="#0D0C0B"/></svg>`,
    name: 'check-box'
};

const appCheckBoxOutlineBlankIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 19H5V5h14v14zm0-16H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z" fill="#0D0C0B"/></svg>`,
    name: 'check-box-outline-blank'
};

const appIndeterminateCheckBoxIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-3 10H8c-.55 0-1-.45-1-1s.45-1 1-1h8c.55 0 1 .45 1 1s-.45 1-1 1z" fill="#0D0C0B"/></svg>`,
    name: 'indeterminate-check-box'
};

const appRadioButtonCheckedIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z" fill="#0D0C0B"/><path d="M12 17a5 5 0 100-10 5 5 0 000 10z" fill="#0D0C0B"/></svg>`,
    name: 'radio-button-checked'
};

const appRadioButtonUncheckedIcon = {
    data: `<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z" fill="#0D0C0B"/></svg>`,
    name: 'radio-button-unchecked'
};

const toggleIcons = [appCheckBoxOutlineBlankIcon, appCheckBoxIcon, appIndeterminateCheckBoxIcon, appRadioButtonCheckedIcon, appRadioButtonUncheckedIcon];

class SpComponentsComponent {
    constructor(iconReg) {
        this.iconReg = iconReg;
        this.registerIcons(this.iconReg);
    }
    ngOnInit() {
    }
    registerIcons(iconReg) {
        // Action Icons
        actionIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Alert Icons
        alertIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // AV Icons
        avIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Communications Icons
        communicationIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Content Icons
        contentIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // File Icons
        fileIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Hardware Icons
        hardwareIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Image Icons
        imageIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Maps Icons
        mapsIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Navigation Icons
        navigationIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Notification Icons
        notificationIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Social Icons
        socialIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
        // Toggle Icons
        toggleIcons.forEach(element => {
            iconReg.addSvg(element.name, element.data);
        });
    }
}
SpComponentsComponent.decorators = [
    { type: Component, args: [{
                selector: 'sp-components',
                template: '',
                encapsulation: ViewEncapsulation.None
            },] }
];
SpComponentsComponent.ctorParameters = () => [
    { type: SvgIconRegistryService }
];

class DatePickerComponent extends FormFieldManager {
    constructor() {
        super();
    }
    /**
     * override: inherited writeValue
     */
    writeValue(obj) {
        if (obj !== undefined) {
            this.value = obj;
            this.setDate();
            this.checkDirty();
        }
    }
    /**
     * set date to display
     */
    setDate() {
        if (this.value) {
            const date = this.value;
            this.formattedDate = date.toLocaleDateString();
        }
    }
    /**
     * format date to display
     */
    convertDate(event) {
        this.setDate();
        this.changeAction(event);
    }
}
DatePickerComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-date-picker',
                template: "<div class=\"spt-input-container text-field-container\" [ngClass]=\"{'disabled-container': isDisabled}\">\r\n    <input nz-input [ngClass]=\"{'dirty': isDirty, 'error': !!error, 'has-left-icon': !!startIcon, 'has-right-icon': !!endIcon, 'disabled-state': isDisabled}\"\r\n           (click)=\"isDisabled ? $event.stopPropagation() : datePickerEl.open()\"\r\n           [(ngModel)]=\"formattedDate\"\r\n           [class]=\"size\" placeholder=\"{{placeholder}}\"\r\n           [attr.disabled]=\"isDisabled\" readonly>\r\n    <!-- label -->\r\n    <label class=\"text-field-label label\">{{ label || placeholder }}</label>\r\n\r\n    <!-- error -->\r\n    <label class=\"text-field-bottom-label error-label\" *ngIf=\"!!error\">{{ error }}</label>\r\n\r\n    <!-- error icon -->\r\n    <span *ngIf=\"!!error\" class=\"text-field-icon error-icon\">\r\n        <svg-icon name=\"report\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n    </span>\r\n</div>\r\n\r\n<nz-date-picker #datePickerEl style=\"visibility: hidden; transform: translateY(-35px)\"\r\n                [(ngModel)]=\"value\" (ngModelChange)=\"convertDate($event)\"></nz-date-picker>\r\n",
                providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => DatePickerComponent),
                        multi: true
                    }
                ],
                styles: [".form-field{color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.form-field.large{padding:12px 10px}.form-field.large+label{top:12px}.form-field.medium{padding:8px 10px}.form-field.medium+label{top:8px}.form-field.small{padding:6px 10px}.form-field.small+label{top:6px}.form-field.error,.form-field.has-right-icon{padding-right:45px}.form-field.error{border:1px solid #ef5350!important}.form-field.error~label{color:#ef5350!important}.form-field.error:focus,.form-field.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.form-field.has-left-icon{padding-left:45px}.form-field.has-left-icon+label{left:45px}.form-field:hover{border:1px solid #000!important}.form-field.item-focus,.form-field:focus{border:1px solid #f90!important;caret-color:#f90}.form-field.item-focus+label,.form-field:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.text-field-container input::-moz-placeholder{visibility:hidden;opacity:0;-moz-transition:visibility .1s ease-out,opacity .1s ease-out;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input::placeholder{visibility:hidden;opacity:0;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input:focus::-moz-placeholder{visibility:visible;opacity:1}.text-field-container input:focus::placeholder{visibility:visible;opacity:1}.spt-input-container{margin:0;position:relative}.spt-input-container input{box-shadow:none;outline:none;min-height:24px;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.spt-input-container input.large{padding:12px 10px}.spt-input-container input.large+label{top:12px}.spt-input-container input.medium{padding:8px 10px}.spt-input-container input.medium+label{top:8px}.spt-input-container input.small{padding:6px 10px}.spt-input-container input.small+label{top:6px}.spt-input-container input.error,.spt-input-container input.has-right-icon{padding-right:45px}.spt-input-container input.error{border:1px solid #ef5350!important}.spt-input-container input.error~label{color:#ef5350!important}.spt-input-container input.error:focus,.spt-input-container input.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.spt-input-container input.has-left-icon{padding-left:45px}.spt-input-container input.has-left-icon+label{left:45px}.spt-input-container input:hover{border:1px solid #000!important}.spt-input-container input.item-focus,.spt-input-container input:focus{border:1px solid #f90!important;caret-color:#f90}.spt-input-container input.item-focus+label,.spt-input-container input:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input[disabled]{background-color:#fff!important;color:#b1b1b1!important;border:1px solid #b1b1b1!important;cursor:not-allowed}.spt-input-container input[disabled]~label{color:#b1b1b1!important}.spt-input-container input[disabled]:hover{border:1px solid #b1b1b1!important}.spt-input-container input.dirty+label{color:#909090}.spt-input-container input.dirty:hover+label{color:#000}.spt-input-container input.dirty:focus+label{color:#f90}.spt-input-container input.dirty+label{font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input+label{position:absolute;left:12px;font-size:14px;color:#909090;background-color:hsla(0,0%,100%,0);pointer-events:none;transition:all .2s ease,background-color .2s ease-in}.spt-input-container .text-field-icon{position:absolute;height:24px;top:50%;transform:translateY(-50%)}.spt-input-container .error-icon,.spt-input-container .right-icon{right:12px}.spt-input-container .left-icon{left:12px}.spt-input-container .left-icon svg path,.spt-input-container .right-icon svg path{fill:#706f6e}.spt-input-container .error-icon svg path{fill:#ef5350}.spt-input-container label.text-field-bottom-label{font-size:12px;margin-top:10px;position:absolute;bottom:-20px}.spt-input-container label.error-label,.spt-input-container label.hint-label{left:12px}.spt-input-container label.length-label{right:12px}.spt-input-container label.error-label{color:#ef5350}.spt-input-container label.hint-label,.spt-input-container label.length-label{color:#4f4e4d}.spt-input-container.disabled-container .text-field-bottom-label{color:#b1b1b1!important}.spt-input-container.disabled-container .text-field-icon svg path{fill:#b1b1b1}.search-wrapper{display:flex;align-items:center;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.search-wrapper.large{padding:12px 10px}.search-wrapper.large+label{top:12px}.search-wrapper.medium{padding:8px 10px}.search-wrapper.medium+label{top:8px}.search-wrapper.small{padding:6px 10px}.search-wrapper.small+label{top:6px}.search-wrapper.error,.search-wrapper.has-right-icon{padding-right:45px}.search-wrapper.error{border:1px solid #ef5350!important}.search-wrapper.error~label{color:#ef5350!important}.search-wrapper.error:focus,.search-wrapper.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.search-wrapper.has-left-icon{padding-left:45px}.search-wrapper.has-left-icon+label{left:45px}.search-wrapper:hover{border:1px solid #000!important}.search-wrapper.item-focus,.search-wrapper:focus{border:1px solid #f90!important;caret-color:#f90}.search-wrapper.item-focus+label,.search-wrapper:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.search-wrapper input,.search-wrapper input:focus,.search-wrapper input:hover{border:none!important}.search-wrapper .search-icon{height:24px}.search-wrapper.large .search-icon,.search-wrapper.medium .search-icon{margin-left:10px;margin-right:10px}.search-wrapper.small{padding:4px 10px}.search-wrapper.small .search-icon{margin-left:10px;margin-right:10px}.search-wrapper .selected-items{display:flex;flex-wrap:wrap}.search-wrapper .selected-items .selected-item{margin:1px}"]
            },] }
];
DatePickerComponent.ctorParameters = () => [];

registerLocaleData(en);
const ɵ0 = en_US;
class SpComponentsModule {
}
SpComponentsModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    SpComponentsComponent,
                    ChipComponent,
                    ButtonComponent,
                    TextFieldComponent,
                    BannerComponent,
                    SideNavigationComponent,
                    StepsComponent,
                    DropdownComponent,
                    OptionComponent,
                    OverlayTemplateComponent,
                    SidebarComponent,
                    SearchComponent,
                    SearchTemplateComponent,
                    SearchOptionComponent,
                    BackNavigationComponent,
                    BreadcrumbComponent,
                    SnackbarComponent,
                    MenuComponent,
                    MenuTriggerDirective,
                    MenuItemComponent,
                    AvatarComponent,
                    BadgeComponent,
                    DividerComponent,
                    ProgressBarComponent,
                    CheckboxComponent,
                    RadioButtonComponent,
                    SwitchComponent,
                    SliderComponent,
                    TabComponent,
                    TooltipComponent,
                    ElevationComponent,
                    SpacingComponent,
                    IconComponent,
                    DataVisualizationComponent,
                    ChartComponent,
                    DialogsComponent,
                    TableComponent,
                    UploadComponent,
                    HeaderComponent,
                    CardComponent,
                    DatePickerComponent
                ],
                exports: [
                    SpComponentsComponent,
                    ChipComponent,
                    ButtonComponent,
                    TextFieldComponent,
                    BannerComponent,
                    SideNavigationComponent,
                    StepsComponent,
                    DropdownComponent,
                    OptionComponent,
                    OverlayTemplateComponent,
                    SidebarComponent,
                    SearchComponent,
                    SearchTemplateComponent,
                    SearchOptionComponent,
                    BackNavigationComponent,
                    BreadcrumbComponent,
                    SnackbarComponent,
                    MenuComponent,
                    MenuTriggerDirective,
                    MenuItemComponent,
                    AvatarComponent,
                    BadgeComponent,
                    DividerComponent,
                    ProgressBarComponent,
                    CheckboxComponent,
                    RadioButtonComponent,
                    SwitchComponent,
                    SliderComponent,
                    TabComponent,
                    TooltipComponent,
                    ElevationComponent,
                    SpacingComponent,
                    IconComponent,
                    DataVisualizationComponent,
                    ChartComponent,
                    DialogsComponent,
                    TableComponent,
                    UploadComponent,
                    HeaderComponent,
                    CardComponent,
                    DatePickerComponent
                ],
                imports: [
                    CommonModule,
                    ChartsModule,
                    FormsModule,
                    HttpClientModule,
                    RouterModule,
                    AngularSvgIconModule.forRoot(),
                    ReactiveFormsModule,
                    PortalModule,
                    OverlayModule,
                    ...NZMODULES,
                ],
                providers: [{ provide: NZ_I18N, useValue: ɵ0 }, ThemeService],
            },] }
];

/**
 * Generated bundle index. Do not edit.
 */

export { AvatarComponent, AvatarSize, BackNavigationComponent, BadgeComponent, BreadcrumbComponent, ButtonComponent, ButtonSize, ButtonType, CardComponent, ChartComponent, ChartType, CheckboxComponent, ChipComponent, DataVisualizationComponent, DatePickerComponent, DialogsComponent, DividerComponent, DividerType, DropdownComponent, ElevationComponent, HeaderComponent, ICardType, MenuComponent, ProgressBarComponent, ProgressType, RadioButtonComponent, SearchComponent, SideNavigationComponent, SideNavigationType, SidebarComponent, SliderComponent, SnackbarComponent, SpComponentsComponent, SpComponentsModule, SpacingComponent, StepsComponent, SwitchComponent, TabComponent, TableComponent, TagType, TextFieldComponent, TooltipComponent, UploadComponent, actionIcons, alertIcons, avIcons, communicationIcons, contentIcons, fileIcons, hardwareIcons, imageIcons, mapsIcons, navigationIcons, notificationIcons, socialIcons, toggleIcons, ɵ0, FormFieldManager as ɵa, BannerComponent as ɵb, appEmailIcon as ɵba, appAddCircleOutlineIcon as ɵbb, appAddIcon as ɵbc, appReportIcon as ɵbd, appSendIcon as ɵbe, appUploadFileIcon as ɵbf, appKeyboardTabIcon as ɵbg, appSmartphoneIcon as ɵbh, appEditIcon as ɵbi, appWbIncandescentIcon as ɵbj, appPlaceIcon as ɵbk, appArrowBackIcon as ɵbl, appArrowDownwardIcon as ɵbm, appArrowForwardIcon as ɵbn, appArrowUpwardIcon as ɵbo, appCancelBlackIcon as ɵbp, appCheckIcon as ɵbq, appChevronLeftIcon as ɵbr, appChevronRightIcon as ɵbs, appClearIcon as ɵbt, appEastIcon as ɵbu, appExpandLessIcon as ɵbv, appExpandMoreIcon as ɵbw, appFirstPageIcon as ɵbx, appLastPageIcon as ɵby, appMoreVertIcon as ɵbz, DropdownService as ɵc, appRefreshIcon as ɵca, appPriorityHighIcon as ɵcb, appSmsIcon as ɵcc, appPeopleIcon as ɵcd, appCheckBoxOutlineBlankIcon as ɵce, appCheckBoxIcon as ɵcf, appIndeterminateCheckBoxIcon as ɵcg, appRadioButtonCheckedIcon as ɵch, appRadioButtonUncheckedIcon as ɵci, OverlayTemplateComponent as ɵd, OptionComponent as ɵe, SearchService as ɵf, SearchOptionComponent as ɵg, SearchTemplateComponent as ɵh, MenuService as ɵi, MenuItemComponent as ɵj, MenuTriggerDirective as ɵk, IconComponent as ɵl, NZMODULES as ɵm, appAccountBoxIcon as ɵn, appCheckCircleIcon as ɵo, appExpandIcon as ɵp, appFavoriteIcon as ɵq, appHomeIcon as ɵr, appLogoutIcon as ɵs, appRedeemIcon as ɵt, appSearchIcon as ɵu, appSettingsIcon as ɵv, appErrorIcon as ɵw, appWarningIcon as ɵx, appRecentActorsIcon as ɵy, appCallIcon as ɵz };
//# sourceMappingURL=spoonity-sp-components.js.map
