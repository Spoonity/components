import { appUploadFileIcon } from '../../../svg/File/upload_file';
import { Component, ViewChild, ViewContainerRef } from '@angular/core';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NzMessageService } from 'ng-zorro-antd/message';
export class UploadComponent {
    constructor(modal, viewContainerRef, msg) {
        this.modal = modal;
        this.viewContainerRef = viewContainerRef;
        this.msg = msg;
        this.uploadFile = appUploadFileIcon.name;
    }
    createModalUpload(upload) {
        this.upload = upload;
        this.createTplModal(this.tplTitle, this.tplContent, this.tplFooter);
    }
    createTplModal(tplTitle, tplContent, tplFooter) {
        this.modalRef = this.modal.create({
            nzTitle: tplTitle,
            nzContent: tplContent,
            nzFooter: tplFooter,
            nzMaskClosable: false,
            nzClosable: true,
        });
    }
    ngOnInit() {
    }
    handleChange({ file, fileList }) {
        const status = file.status;
        if (status === 'done') {
            this.msg.success(`${file.name} file uploaded successfully.`);
        }
        else if (status === 'error') {
            this.msg.error(`${file.name} file upload failed.`);
        }
    }
}
UploadComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-upload',
                template: "<ng-template #tplTitle>\r\n    <span class=\"title\">\r\n    {{ upload.title }}\r\n    </span>\r\n</ng-template>\r\n<ng-template #tplContent>\r\n    <span class=\"content\">\r\n    {{ upload.content }}\r\n  </span>\r\n  <br>\r\n  <br>\r\n    <nz-upload\r\n    nzType=\"drag\"\r\n    [nzMultiple]=\"true\"\r\n    nzAction=\"https://www.mocky.io/v2/5cc8019d300000980a055e76\"\r\n    (nzChange)=\"handleChange($event)\"\r\n    class=\"upload-box\"\r\n  >\r\n    <div class=\"upload-content\">\r\n      <spt-icon class=\"icons\" [toolTipTittle]=\"uploadFile\" [name]=\"uploadFile\"></spt-icon>\r\n      <span>Drag and Drop here</span>\r\n      <span>or</span>\r\n      <span><b>BROWSE FILES</b></span>\r\n\r\n    </div>\r\n    </nz-upload>\r\n\r\n    <div class=\"under-upload-text\">\r\n    <span>Accepted files</span>\r\n    <span>Maximum size</span>\r\n    </div>\r\n\r\n</ng-template>\r\n<ng-template #tplFooter let-ref=\"modalRef\">\r\n    <button nz-button nzType=\"secondary\" (click)=\"modalRef.destroy(); upload.action1()\">\r\n    {{ upload.action1Label }}\r\n  </button>\r\n</ng-template>\r\n",
                styles: [".title{font-family:Nunito;font-weight:700;font-size:24px;line-height:32px;color:#0d0c0b}.content,.title{font-style:normal}.content{font-family:Nunito Sans;font-weight:400;font-size:16px;line-height:24px;color:#4f4e4d}.upload-box{width:468px;height:304px;box-sizing:border-box;border-radius:4px}.upload-box,.upload-content{display:flex;flex-direction:column;align-items:center;justify-content:center}.upload-box:hover{background-color:#f3f3f3}.under-upload-text{display:flex;width:468px;justify-content:space-between;font-size:12px;line-height:16px;color:#909090}.icons{padding-top:4px;margin:10px}"]
            },] }
];
UploadComponent.ctorParameters = () => [
    { type: NzModalService },
    { type: ViewContainerRef },
    { type: NzMessageService }
];
UploadComponent.propDecorators = {
    tplTitle: [{ type: ViewChild, args: ['tplTitle',] }],
    tplContent: [{ type: ViewChild, args: ['tplContent',] }],
    tplFooter: [{ type: ViewChild, args: ['tplFooter',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBsb2FkLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9PcmdhbmlzbXMvdXBsb2FkL3VwbG9hZC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sK0JBQStCLENBQUM7QUFDbEUsT0FBTyxFQUFFLFNBQVMsRUFBdUIsU0FBUyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzVGLE9BQU8sRUFBYyxjQUFjLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQztBQUNqRSxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQWN6RCxNQUFNLE9BQU8sZUFBZTtJQVcxQixZQUNVLEtBQXFCLEVBQ3JCLGdCQUFrQyxFQUNsQyxHQUFxQjtRQUZyQixVQUFLLEdBQUwsS0FBSyxDQUFnQjtRQUNyQixxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWtCO1FBQ2xDLFFBQUcsR0FBSCxHQUFHLENBQWtCO1FBVi9CLGVBQVUsR0FBRyxpQkFBaUIsQ0FBQyxJQUFJLENBQUM7SUFVRCxDQUFDO0lBRXBDLGlCQUFpQixDQUFDLE1BQWU7UUFDL0IsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFFRCxjQUFjLENBQUMsUUFBeUIsRUFBRSxVQUEyQixFQUFFLFNBQTBCO1FBQy9GLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDaEMsT0FBTyxFQUFFLFFBQVE7WUFDakIsU0FBUyxFQUFFLFVBQVU7WUFDckIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsY0FBYyxFQUFFLEtBQUs7WUFDckIsVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELFFBQVE7SUFDUixDQUFDO0lBRUQsWUFBWSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBTztRQUNsQyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzNCLElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUNyQixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLDhCQUE4QixDQUFDLENBQUM7U0FDOUQ7YUFBTSxJQUFJLE1BQU0sS0FBSyxPQUFPLEVBQUU7WUFDN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxzQkFBc0IsQ0FBQyxDQUFDO1NBQ3BEO0lBQ0gsQ0FBQzs7O1lBOUNGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsWUFBWTtnQkFDdEIsdWxDQUFzQzs7YUFFdkM7OztZQWRvQixjQUFjO1lBRGlCLGdCQUFnQjtZQUUzRCxnQkFBZ0I7Ozt1QkFxQnRCLFNBQVMsU0FBQyxVQUFVO3lCQUNwQixTQUFTLFNBQUMsWUFBWTt3QkFDdEIsU0FBUyxTQUFDLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhcHBVcGxvYWRGaWxlSWNvbiB9IGZyb20gJy4uLy4uLy4uL3N2Zy9GaWxlL3VwbG9hZF9maWxlJztcclxuaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIFRlbXBsYXRlUmVmLCBWaWV3Q2hpbGQsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTnpNb2RhbFJlZiwgTnpNb2RhbFNlcnZpY2UgfSBmcm9tICduZy16b3Jyby1hbnRkL21vZGFsJztcclxuaW1wb3J0IHsgTnpNZXNzYWdlU2VydmljZSB9IGZyb20gJ25nLXpvcnJvLWFudGQvbWVzc2FnZSc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElVcGxvYWQge1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgY29udGVudDogc3RyaW5nO1xyXG4gIGFjdGlvbjE6ICgpID0+IGFueTtcclxuICBhY3Rpb24xTGFiZWw6IHN0cmluZztcclxufVxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdzcHQtdXBsb2FkJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vdXBsb2FkLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi91cGxvYWQuY29tcG9uZW50Lmxlc3MnXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgVXBsb2FkQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgdXBsb2FkOiBJVXBsb2FkO1xyXG5cclxuICB1cGxvYWRGaWxlID0gYXBwVXBsb2FkRmlsZUljb24ubmFtZTtcclxuXHJcbiAgbW9kYWxSZWY6IE56TW9kYWxSZWY7XHJcbiAgQFZpZXdDaGlsZCgndHBsVGl0bGUnKSB0cGxUaXRsZT86IFRlbXBsYXRlUmVmPHt9PjtcclxuICBAVmlld0NoaWxkKCd0cGxDb250ZW50JykgdHBsQ29udGVudD86IFRlbXBsYXRlUmVmPHt9PjtcclxuICBAVmlld0NoaWxkKCd0cGxGb290ZXInKSB0cGxGb290ZXI/OiBUZW1wbGF0ZVJlZjx7fT47XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgcHJpdmF0ZSBtb2RhbDogTnpNb2RhbFNlcnZpY2UsXHJcbiAgICBwcml2YXRlIHZpZXdDb250YWluZXJSZWY6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBwcml2YXRlIG1zZzogTnpNZXNzYWdlU2VydmljZSkgeyB9XHJcblxyXG4gIGNyZWF0ZU1vZGFsVXBsb2FkKHVwbG9hZDogSVVwbG9hZCkge1xyXG4gICAgdGhpcy51cGxvYWQgPSB1cGxvYWQ7XHJcbiAgICB0aGlzLmNyZWF0ZVRwbE1vZGFsKHRoaXMudHBsVGl0bGUsIHRoaXMudHBsQ29udGVudCwgdGhpcy50cGxGb290ZXIpO1xyXG4gIH1cclxuXHJcbiAgY3JlYXRlVHBsTW9kYWwodHBsVGl0bGU6IFRlbXBsYXRlUmVmPHt9PiwgdHBsQ29udGVudDogVGVtcGxhdGVSZWY8e30+LCB0cGxGb290ZXI6IFRlbXBsYXRlUmVmPHt9Pik6IHZvaWQge1xyXG4gICAgdGhpcy5tb2RhbFJlZiA9IHRoaXMubW9kYWwuY3JlYXRlKHtcclxuICAgICAgbnpUaXRsZTogdHBsVGl0bGUsXHJcbiAgICAgIG56Q29udGVudDogdHBsQ29udGVudCxcclxuICAgICAgbnpGb290ZXI6IHRwbEZvb3RlcixcclxuICAgICAgbnpNYXNrQ2xvc2FibGU6IGZhbHNlLFxyXG4gICAgICBuekNsb3NhYmxlOiB0cnVlLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICB9XHJcblxyXG4gIGhhbmRsZUNoYW5nZSh7IGZpbGUsIGZpbGVMaXN0IH06IGFueSk6IHZvaWQge1xyXG4gICAgY29uc3Qgc3RhdHVzID0gZmlsZS5zdGF0dXM7XHJcbiAgICBpZiAoc3RhdHVzID09PSAnZG9uZScpIHtcclxuICAgICAgdGhpcy5tc2cuc3VjY2VzcyhgJHtmaWxlLm5hbWV9IGZpbGUgdXBsb2FkZWQgc3VjY2Vzc2Z1bGx5LmApO1xyXG4gICAgfSBlbHNlIGlmIChzdGF0dXMgPT09ICdlcnJvcicpIHtcclxuICAgICAgdGhpcy5tc2cuZXJyb3IoYCR7ZmlsZS5uYW1lfSBmaWxlIHVwbG9hZCBmYWlsZWQuYCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxufVxyXG4iXX0=