import { Component, Input } from '@angular/core';
export class DataVisualizationComponent {
    constructor() { }
    ngOnInit() {
    }
}
DataVisualizationComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-data-visualization',
                template: "<div class=\"data-visualization\">\r\n  <span class=\"data-visualization-title\">{{ title }}</span>\r\n  <span class=\"data-visualization-description\">{{ description }}</span>\r\n  <ng-content></ng-content>\r\n</div>\r\n",
                styles: [".data-visualization{border:1px solid #e2e2e2;border-radius:4px;padding:32px;background-color:#fff}.data-visualization-title{display:flex;font-family:Nunito;font-style:normal;font-weight:700;font-size:48px;line-height:56px}.data-visualization-description{display:flex;font-family:Nunito Sans;font-style:normal;font-weight:400;font-size:16px;line-height:24px}"]
            },] }
];
DataVisualizationComponent.ctorParameters = () => [];
DataVisualizationComponent.propDecorators = {
    title: [{ type: Input }],
    description: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YS12aXN1YWxpemF0aW9uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9PcmdhbmlzbXMvZGF0YS12aXN1YWxpemF0aW9uL2RhdGEtdmlzdWFsaXphdGlvbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFPekQsTUFBTSxPQUFPLDBCQUEwQjtJQUtyQyxnQkFBZ0IsQ0FBQztJQUVqQixRQUFRO0lBQ1IsQ0FBQzs7O1lBYkYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSx3QkFBd0I7Z0JBQ2xDLHlPQUFrRDs7YUFFbkQ7Ozs7b0JBR0UsS0FBSzswQkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3NwdC1kYXRhLXZpc3VhbGl6YXRpb24nLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9kYXRhLXZpc3VhbGl6YXRpb24uY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL2RhdGEtdmlzdWFsaXphdGlvbi5jb21wb25lbnQubGVzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBEYXRhVmlzdWFsaXphdGlvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIEBJbnB1dCgpIHRpdGxlOiBzdHJpbmc7XHJcbiAgQElucHV0KCkgZGVzY3JpcHRpb246IHN0cmluZztcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxufVxyXG4iXX0=