import { Component, Input } from '@angular/core';
import { ButtonSize, ButtonType } from '../../../utils/enums';
export class HeaderComponent {
    constructor() {
        this.buttonType = ButtonType.primary;
        this.buttonSize = ButtonSize.medium;
    }
    ngOnInit() { }
}
HeaderComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-header',
                template: "<div class=\"header\">\r\n  <div class=\"sub-header-1\">\r\n    <spt-back-navigation\r\n      *ngIf=\"backTitle\"\r\n      [title]=\"backTitle\"\r\n    ></spt-back-navigation>\r\n    <spt-breadcrumb *ngIf=\"breadcrumbs\" [items]=\"breadcrumbs\"></spt-breadcrumb>\r\n    <span class=\"title\">{{ title }}</span>\r\n  </div>\r\n  <div class=\"sub-header-2\">\r\n    <div class=\"search\">\r\n      <spt-search *ngIf=\"search\"></spt-search>\r\n    </div>\r\n    <spt-button\r\n      *ngIf=\"btnTitle\"\r\n      [text]=\"btnTitle\"\r\n      [type]=\"buttonType\"\r\n      [size]=\"buttonSize\"\r\n      (click)=\"action()\"\r\n    ></spt-button>\r\n  </div>\r\n</div>\r\n",
                styles: [".header{display:flex;width:100%;flex-direction:row;justify-content:space-between;align-items:center;padding:24px 0}.sub-header-1{display:flex;flex-direction:column}.sub-header-2{display:flex;flex-direction:row;align-items:center;justify-content:flex-end}.search{width:300px;padding-right:30px}.title{font-family:Nunito;font-style:normal;font-weight:700;font-size:32px;line-height:48px;display:flex;align-items:center}"]
            },] }
];
HeaderComponent.ctorParameters = () => [];
HeaderComponent.propDecorators = {
    title: [{ type: Input }],
    backTitle: [{ type: Input }],
    breadcrumbs: [{ type: Input }],
    btnTitle: [{ type: Input }],
    search: [{ type: Input }],
    action: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9PcmdhbmlzbXMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFDekQsT0FBTyxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQVE5RCxNQUFNLE9BQU8sZUFBZTtJQVMxQjtRQUVBLGVBQVUsR0FBZSxVQUFVLENBQUMsT0FBTyxDQUFDO1FBQzVDLGVBQVUsR0FBZSxVQUFVLENBQUMsTUFBTSxDQUFDO0lBSDNCLENBQUM7SUFLakIsUUFBUSxLQUFJLENBQUM7OztZQW5CZCxTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLFlBQVk7Z0JBQ3RCLHdxQkFBc0M7O2FBRXZDOzs7O29CQUdFLEtBQUs7d0JBQ0wsS0FBSzswQkFDTCxLQUFLO3VCQUNMLEtBQUs7cUJBQ0wsS0FBSztxQkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEJ1dHRvblNpemUsIEJ1dHRvblR5cGUgfSBmcm9tICcuLi8uLi8uLi91dGlscy9lbnVtcyc7XHJcbmltcG9ydCB7IElCcmVhZENydW1iSXRlbSB9IGZyb20gJy4uLy4uL01vbGVjdWxlcy9icmVhZGNydW1iL2JyZWFkY3J1bWIuY29tcG9uZW50JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LWhlYWRlcicsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2hlYWRlci5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vaGVhZGVyLmNvbXBvbmVudC5sZXNzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIEhlYWRlckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIEBJbnB1dCgpIHRpdGxlOiBzdHJpbmc7XHJcbiAgQElucHV0KCkgYmFja1RpdGxlOiBzdHJpbmc7XHJcbiAgQElucHV0KCkgYnJlYWRjcnVtYnM6IHN0cmluZztcclxuICBASW5wdXQoKSBidG5UaXRsZTogc3RyaW5nO1xyXG4gIEBJbnB1dCgpIHNlYXJjaDogYm9vbGVhbjtcclxuICBASW5wdXQoKSBhY3Rpb246ICgpID0+IHt9O1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHsgfVxyXG5cclxuICBidXR0b25UeXBlOiBCdXR0b25UeXBlID0gQnV0dG9uVHlwZS5wcmltYXJ5O1xyXG4gIGJ1dHRvblNpemU6IEJ1dHRvblNpemUgPSBCdXR0b25TaXplLm1lZGl1bTtcclxuXHJcbiAgbmdPbkluaXQoKSB7fVxyXG5cclxufVxyXG4iXX0=