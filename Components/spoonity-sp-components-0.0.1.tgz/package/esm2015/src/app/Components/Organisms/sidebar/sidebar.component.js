import { appExpandMoreIcon } from '../../../svg/Navigation/expand_more';
import { appLogoutIcon } from '../../../svg/Action/logout';
import { appAccountBoxIcon } from '../../../svg/Action/account_box';
import { appExpandLessIcon } from '../../../svg/Navigation/expand_less';
import { appKeyboardTabIcon } from '../../../svg/Hardware/keyboard_tab';
import { AvatarSize, ButtonSize, ButtonType } from '../../../utils/enums';
import { Component, Input } from '@angular/core';
export class SidebarComponent {
    constructor() {
        this.sidebarData = {};
        this.userDisplay = {};
        this.otherAccounts = [];
        this.AccountsDisplay = this.otherAccounts;
        this.multipleAccounts = false;
        this.avatarSize = AvatarSize.medium;
        this.keyboarTab = appKeyboardTabIcon.name;
        this.expandLess = appExpandLessIcon.name;
        this.accountBox = appAccountBoxIcon.name;
        this.logoutIcon = appLogoutIcon.name;
        this.expandMore = appExpandMoreIcon.name;
        this.buttonType = ButtonType.secondary;
        this.buttonSize = ButtonSize.medium;
        this.iconColor = '#FFF';
        this.isCollapse = false;
        this.onToggleLogout = false;
        this.multipleAccountsSelection = false;
        this.MenuWidht = '280px';
        this.MenuHeight = '857px';
        this.OptionWidht = '240px';
        this.lineRight = '-20px';
    }
    ngOnInit() {
        if (this.sidebarData.users.length > 1) {
            this.multipleAccounts = true;
        }
        this.sidebarData.users.forEach((user) => {
            this.sidebarData.users.indexOf(user) === 0 ? this.userDisplay = user : this.otherAccounts.push(user);
        });
    }
    onCollapse() {
        if (this.isCollapse) {
            this.isCollapse = false;
            this.MenuWidht = '280px';
            this.OptionWidht = '240px';
            this.lineRight = '-20px';
        }
        else if (!this.isCollapse && this.onToggleLogout) {
            this.isCollapse = true;
            this.MenuWidht = '88px';
            this.OptionWidht = '46px';
            this.lineRight = '-22px';
            this.onToggleLogout = false;
            this.MenuHeight = '857px';
        }
        else {
            this.isCollapse = true;
            this.MenuWidht = '88px';
            this.OptionWidht = '46px';
            this.lineRight = '-22px';
            this.multipleAccountsSelection = false;
        }
    }
    onActive(option) {
        this.optionsData.forEach((e) => {
            if (e.title === option.title) {
                option.isActive = true;
            }
            else {
                e.isActive = false;
            }
        });
    }
    toggleLogout() {
        if (this.onToggleLogout && !this.isCollapse) {
            this.onToggleLogout = false;
            this.MenuHeight = '857px';
        }
        else {
            this.onToggleLogout = true;
            this.MenuHeight = '780px';
        }
    }
    expandAccounts() {
        if (this.multipleAccountsSelection) {
            this.multipleAccountsSelection = false;
        }
        else {
            this.multipleAccountsSelection = true;
        }
    }
    switchAccount(account) {
        this.userDisplay = {};
        this.otherAccounts = [];
        this.sidebarData.users.forEach((user) => {
            user.id === account.id ? this.userDisplay = user : this.otherAccounts.push(user);
        });
    }
    filter() {
        this.AccountsDisplay = [];
        this.otherAccounts.filter((user) => {
            const test = user.name.toLocaleLowerCase().includes(this.inputFilter.toLocaleLowerCase());
            if (test) {
                this.AccountsDisplay.push(user);
            }
        });
    }
}
SidebarComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-sidebar',
                template: "<div class=\"container\" [ngStyle]=\"{ width: MenuWidht }\">\r\n  <div class=\"user\">\r\n    <spt-avatar [text]=\"userDisplay.name.charAt(0).toUpperCase()\"></spt-avatar>\r\n    <div class=\"text\" *ngIf=\"!isCollapse\">\r\n      <span>{{ userDisplay.name }}</span>\r\n      <span>{{ userDisplay.company }}</span>\r\n    </div>\r\n    <spt-icon\r\n      class=\"icons\"\r\n      [toolTipTittle]=\"expandMore\"\r\n      [name]=\"expandMore\"\r\n      *ngIf=\"multipleAccounts && !isCollapse\"\r\n      (click)=\"expandAccounts()\"\r\n      [color]=\"iconColor\"\r\n    ></spt-icon>\r\n    <div\r\n      *ngIf=\"multipleAccountsSelection && !isCollapse\"\r\n      class=\"multiAccount spt-elevation--3 elevation-box\"\r\n    >\r\n      <spt-text-field\r\n        [placeholder]=\"'Filter by name'\"\r\n        [(ngModel)]=\"inputFilter\"\r\n        (ngModelChange)=\"filter()\"\r\n      ></spt-text-field>\r\n      {{ inputFilter }}\r\n      <div\r\n        class=\"userMultiAccount\"\r\n        *ngFor=\"let account of AccountsDisplay\"\r\n        (click)=\"switchAccount(account)\"\r\n      >\r\n        <spt-avatar [text]=\"account.title.charAt(0).toUpperCase()\"></spt-avatar>\r\n        <div class=\"text-multiple-accounts\" *ngIf=\"!isCollapse\">\r\n          <span>{{ account.name }}</span>\r\n          <span>{{ account.company }}</span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <spt-divider></spt-divider>\r\n  <div class=\"menu\" [ngStyle]=\"{ height: MenuHeight }\">\r\n    <div\r\n      *ngFor=\"let option of optionsData\"\r\n      class=\"option\"\r\n      [ngStyle]=\"{ width: OptionWidht }\"\r\n      [ngClass]=\"{ active: option.isActive }\"\r\n      (click)=\"onActive(option)\"\r\n    >\r\n      <spt-icon\r\n        class=\"icons\"\r\n        [toolTipTittle]=\"option.title\"\r\n        [name]=\"option.icon.name\"\r\n        [color]=\"iconColor\"\r\n      ></spt-icon>\r\n      <span *ngIf=\"!isCollapse\">{{ option.title }}</span>\r\n      <div\r\n        class=\"orange-line\"\r\n        [ngStyle]=\"{ right: lineRight }\"\r\n        *ngIf=\"option.isActive\"\r\n      ></div>\r\n    </div>\r\n  </div>\r\n  <spt-divider></spt-divider>\r\n  <div class=\"collapse\" (click)=\"onCollapse()\">\r\n    <spt-icon\r\n      class=\"icons\"\r\n      [toolTipTittle]=\"keyboarTab\"\r\n      [name]=\"keyboarTab\"\r\n      [color]=\"iconColor\"\r\n    ></spt-icon>\r\n  </div>\r\n  <spt-divider></spt-divider>\r\n  <div class=\"user-email\">\r\n    <div class=\"user\">\r\n      <div class=\"text\" *ngIf=\"!isCollapse\">\r\n        <span>{{ userDisplay.name }}</span>\r\n        <span class=\"small\">{{ userDisplay.email }}</span>\r\n      </div>\r\n      <spt-icon\r\n        class=\"icons\"\r\n        [toolTipTittle]=\"expandLess\"\r\n        [name]=\"expandLess\"\r\n        *ngIf=\"!onToggleLogout\"\r\n        (click)=\"toggleLogout()\"\r\n        [color]=\"iconColor\"\r\n      ></spt-icon>\r\n      <spt-icon\r\n        class=\"icons\"\r\n        [toolTipTittle]=\"accountBox\"\r\n        [name]=\"accountBox\"\r\n        *ngIf=\"onToggleLogout\"\r\n        (click)=\"toggleLogout()\"\r\n        [color]=\"iconColor\"\r\n      ></spt-icon>\r\n    </div>\r\n    <div class=\"flex-btn\" *ngIf=\"onToggleLogout && !isCollapse\">\r\n      <spt-button\r\n        class=\"btn\"\r\n        [text]=\"'LOGOUT'\"\r\n        [type]=\"buttonType\"\r\n        [size]=\"buttonSize\"\r\n        [leftIcon]=\"logoutIcon\"\r\n        (click)=\"sidebarData.logout()\"\r\n      ></spt-button>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
                styles: [".container{height:1080px;background-color:#0d0c0b;color:#d2d2d2;font-family:Nunito Sans;font-style:normal;font-size:16px;line-height:24px;z-index:1}.icons{padding-top:4px;margin:10px}.user,.userMultiAccount{position:relative;display:flex;flex-direction:row;align-items:center;padding:20px}.elevation-box{position:absolute;width:280px;left:24px;top:64px;background-color:#fff;z-index:2}.text,.text-multiple-accounts{display:flex;flex-direction:column}.text .small{font-weight:400;font-size:12px;line-height:16px;color:#b1b1b1}.text-multiple-accounts{color:#000}.multiAccount{display:flex;flex-direction:column;padding:20px;justify-content:space-around}.userMultiAccount{margin:10px 0 0;border-radius:4px;padding:12px 6px}.userMultiAccount:hover{background-color:#2e2d2c}.userMultiAccount:hover span{color:#fff}.textFiel{width:80%}.menu{padding:20px}.menu .option{position:relative;display:flex;align-items:center;width:240px;height:48px;padding:12px 6px 12px 6;border-radius:4px;margin:16px 0}.menu .option:hover{background-color:#2e2d2c;color:#f90}.menu .orange-line{position:absolute;right:-20px;background-color:#f90;width:4px;height:40px;border-radius:30px 0 0 30px}.collapse{padding:20px;display:flex;align-items:center;width:240px;height:48px}.active{background-color:#2e2d2c}.user-email{display:flex;flex-direction:column}.flex-btn{display:flex;justify-content:center}spt-icon span svg-icon svg path{fill:#d2d2d2}"]
            },] }
];
SidebarComponent.ctorParameters = () => [];
SidebarComponent.propDecorators = {
    sidebarData: [{ type: Input }],
    optionsData: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2lkZWJhci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL0NvbXBvbmVudHMvT3JnYW5pc21zL3NpZGViYXIvc2lkZWJhci5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0scUNBQXFDLENBQUM7QUFDeEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQzNELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLGlDQUFpQyxDQUFDO0FBQ3BFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLHFDQUFxQyxDQUFDO0FBQ3hFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ3hFLE9BQU8sRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQzFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFVLE1BQU0sZUFBZSxDQUFDO0FBMkJ6RCxNQUFNLE9BQU8sZ0JBQWdCO0lBbUMzQjtRQWpDUyxnQkFBVyxHQUFhLEVBQWMsQ0FBQztRQUdoRCxnQkFBVyxHQUFjLEVBQWUsQ0FBQztRQUN6QyxrQkFBYSxHQUFnQixFQUFpQixDQUFDO1FBQy9DLG9CQUFlLEdBQWdCLElBQUksQ0FBQyxhQUFhLENBQUM7UUFFbEQscUJBQWdCLEdBQUcsS0FBSyxDQUFDO1FBRXpCLGVBQVUsR0FBZSxVQUFVLENBQUMsTUFBTSxDQUFDO1FBRTNDLGVBQVUsR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLENBQUM7UUFDckMsZUFBVSxHQUFHLGlCQUFpQixDQUFDLElBQUksQ0FBQztRQUNwQyxlQUFVLEdBQUcsaUJBQWlCLENBQUMsSUFBSSxDQUFDO1FBQ3BDLGVBQVUsR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDO1FBQ2hDLGVBQVUsR0FBRyxpQkFBaUIsQ0FBQyxJQUFJLENBQUM7UUFFcEMsZUFBVSxHQUFlLFVBQVUsQ0FBQyxTQUFTLENBQUM7UUFDOUMsZUFBVSxHQUFlLFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFJM0MsY0FBUyxHQUFHLE1BQU0sQ0FBQztRQUVuQixlQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ25CLG1CQUFjLEdBQUcsS0FBSyxDQUFDO1FBQ3ZCLDhCQUF5QixHQUFHLEtBQUssQ0FBQztRQUVsQyxjQUFTLEdBQUcsT0FBTyxDQUFDO1FBQ3BCLGVBQVUsR0FBRyxPQUFPLENBQUM7UUFDckIsZ0JBQVcsR0FBRyxPQUFPLENBQUM7UUFDdEIsY0FBUyxHQUFHLE9BQU8sQ0FBQztJQUVKLENBQUM7SUFFakIsUUFBUTtRQUNOLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUFFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7U0FBRTtRQUN4RSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFlLEVBQUUsRUFBRTtZQUNqRCxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkcsQ0FBQyxDQUFDLENBQUM7SUFFTCxDQUFDO0lBRUQsVUFBVTtRQUNSLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNuQixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztZQUN4QixJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQztZQUN6QixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQztZQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQztTQUUxQjthQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDbEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUM7WUFDeEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUM7WUFDMUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7WUFDekIsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUM7U0FFM0I7YUFBTTtZQUNMLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDO1lBQzFCLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDO1lBQ3pCLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxLQUFLLENBQUM7U0FDeEM7SUFDSCxDQUFDO0lBRUQsUUFBUSxDQUFDLE1BQWtCO1FBQ3pCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUU7WUFDbEMsSUFBSSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxLQUFLLEVBQUU7Z0JBQzVCLE1BQU0sQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO2FBQ3hCO2lCQUFNO2dCQUNMLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2FBQ3BCO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsWUFBWTtRQUNWLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDM0MsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUM7U0FDM0I7YUFBTTtZQUNMLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1lBQzNCLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDO1NBQzNCO0lBQ0gsQ0FBQztJQUVELGNBQWM7UUFDWixJQUFJLElBQUksQ0FBQyx5QkFBeUIsRUFBRTtZQUNsQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsS0FBSyxDQUFDO1NBQ3hDO2FBQU07WUFDTCxJQUFJLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFDO1NBQ3ZDO0lBQ0gsQ0FBQztJQUVELGFBQWEsQ0FBQyxPQUFrQjtRQUM5QixJQUFJLENBQUMsV0FBVyxHQUFHLEVBQWUsQ0FBQztRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFlLEVBQUUsRUFBRTtZQUNqRCxJQUFJLENBQUMsRUFBRSxLQUFLLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuRixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxNQUFNO1FBQ0osSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFlLEVBQUUsRUFBRTtZQUM1QyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDO1lBQzFGLElBQUksSUFBSSxFQUFFO2dCQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQUU7UUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDOzs7WUFwSEYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxhQUFhO2dCQUN2QixrL0dBQXVDOzthQUV4Qzs7OzswQkFHRSxLQUFLOzBCQUNMLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhcHBFeHBhbmRNb3JlSWNvbiB9IGZyb20gJy4uLy4uLy4uL3N2Zy9OYXZpZ2F0aW9uL2V4cGFuZF9tb3JlJztcclxuaW1wb3J0IHsgYXBwTG9nb3V0SWNvbiB9IGZyb20gJy4uLy4uLy4uL3N2Zy9BY3Rpb24vbG9nb3V0JztcclxuaW1wb3J0IHsgYXBwQWNjb3VudEJveEljb24gfSBmcm9tICcuLi8uLi8uLi9zdmcvQWN0aW9uL2FjY291bnRfYm94JztcclxuaW1wb3J0IHsgYXBwRXhwYW5kTGVzc0ljb24gfSBmcm9tICcuLi8uLi8uLi9zdmcvTmF2aWdhdGlvbi9leHBhbmRfbGVzcyc7XHJcbmltcG9ydCB7IGFwcEtleWJvYXJkVGFiSWNvbiB9IGZyb20gJy4uLy4uLy4uL3N2Zy9IYXJkd2FyZS9rZXlib2FyZF90YWInO1xyXG5pbXBvcnQgeyBBdmF0YXJTaXplLCBCdXR0b25TaXplLCBCdXR0b25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZW51bXMnO1xyXG5pbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVVzZXJEYXRhIHtcclxuICBuYW1lOiBzdHJpbmc7XHJcbiAgaWQ6IHN0cmluZztcclxuICBlbWFpbDogc3RyaW5nO1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgY29tcGFueTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElTaWRlYmFyIHtcclxuICB1c2VyczogSVVzZXJEYXRhW107XHJcbiAgbG9nb3V0OiAoKSA9PiBhbnk7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSU1lbnVJdGVtcyB7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBpY29uOiBhbnk7XHJcbiAgbGluazogc3RyaW5nLFxyXG4gIGlzQWN0aXZlOiBib29sZWFuO1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3NwdC1zaWRlYmFyJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vc2lkZWJhci5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vc2lkZWJhci5jb21wb25lbnQubGVzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTaWRlYmFyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgQElucHV0KCkgc2lkZWJhckRhdGE6IElTaWRlYmFyID0ge30gYXMgSVNpZGViYXI7XHJcbiAgQElucHV0KCkgb3B0aW9uc0RhdGE6IElNZW51SXRlbXNbXTtcclxuXHJcbiAgdXNlckRpc3BsYXk6IElVc2VyRGF0YSA9IHt9IGFzIElVc2VyRGF0YTtcclxuICBvdGhlckFjY291bnRzOiBJVXNlckRhdGFbXSA9IFtdIGFzIElVc2VyRGF0YVtdO1xyXG4gIEFjY291bnRzRGlzcGxheTogSVVzZXJEYXRhW10gPSB0aGlzLm90aGVyQWNjb3VudHM7XHJcblxyXG4gIG11bHRpcGxlQWNjb3VudHMgPSBmYWxzZTtcclxuXHJcbiAgYXZhdGFyU2l6ZTogQXZhdGFyU2l6ZSA9IEF2YXRhclNpemUubWVkaXVtO1xyXG5cclxuICBrZXlib2FyVGFiID0gYXBwS2V5Ym9hcmRUYWJJY29uLm5hbWU7XHJcbiAgZXhwYW5kTGVzcyA9IGFwcEV4cGFuZExlc3NJY29uLm5hbWU7XHJcbiAgYWNjb3VudEJveCA9IGFwcEFjY291bnRCb3hJY29uLm5hbWU7XHJcbiAgbG9nb3V0SWNvbiA9IGFwcExvZ291dEljb24ubmFtZTtcclxuICBleHBhbmRNb3JlID0gYXBwRXhwYW5kTW9yZUljb24ubmFtZTtcclxuXHJcbiAgYnV0dG9uVHlwZTogQnV0dG9uVHlwZSA9IEJ1dHRvblR5cGUuc2Vjb25kYXJ5O1xyXG4gIGJ1dHRvblNpemU6IEJ1dHRvblNpemUgPSBCdXR0b25TaXplLm1lZGl1bTtcclxuXHJcbiAgaW5wdXRGaWx0ZXI6IHN0cmluZztcclxuXHJcbiAgaWNvbkNvbG9yID0gJyNGRkYnO1xyXG5cclxuICBpc0NvbGxhcHNlID0gZmFsc2U7XHJcbiAgb25Ub2dnbGVMb2dvdXQgPSBmYWxzZTtcclxuICBtdWx0aXBsZUFjY291bnRzU2VsZWN0aW9uID0gZmFsc2U7XHJcblxyXG4gIE1lbnVXaWRodCA9ICcyODBweCc7XHJcbiAgTWVudUhlaWdodCA9ICc4NTdweCc7XHJcbiAgT3B0aW9uV2lkaHQgPSAnMjQwcHgnO1xyXG4gIGxpbmVSaWdodCA9ICctMjBweCc7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gICAgaWYgKHRoaXMuc2lkZWJhckRhdGEudXNlcnMubGVuZ3RoID4gMSkgeyB0aGlzLm11bHRpcGxlQWNjb3VudHMgPSB0cnVlOyB9XHJcbiAgICB0aGlzLnNpZGViYXJEYXRhLnVzZXJzLmZvckVhY2goKHVzZXI6IElVc2VyRGF0YSkgPT4ge1xyXG4gICAgICB0aGlzLnNpZGViYXJEYXRhLnVzZXJzLmluZGV4T2YodXNlcikgPT09IDAgPyB0aGlzLnVzZXJEaXNwbGF5ID0gdXNlciA6IHRoaXMub3RoZXJBY2NvdW50cy5wdXNoKHVzZXIpO1xyXG4gICAgfSk7XHJcblxyXG4gIH1cclxuXHJcbiAgb25Db2xsYXBzZSgpIHtcclxuICAgIGlmICh0aGlzLmlzQ29sbGFwc2UpIHtcclxuICAgICAgdGhpcy5pc0NvbGxhcHNlID0gZmFsc2U7XHJcbiAgICAgIHRoaXMuTWVudVdpZGh0ID0gJzI4MHB4JztcclxuICAgICAgdGhpcy5PcHRpb25XaWRodCA9ICcyNDBweCc7XHJcbiAgICAgIHRoaXMubGluZVJpZ2h0ID0gJy0yMHB4JztcclxuXHJcbiAgICB9IGVsc2UgaWYgKCF0aGlzLmlzQ29sbGFwc2UgJiYgdGhpcy5vblRvZ2dsZUxvZ291dCkge1xyXG4gICAgICB0aGlzLmlzQ29sbGFwc2UgPSB0cnVlO1xyXG4gICAgICB0aGlzLk1lbnVXaWRodCA9ICc4OHB4JztcclxuICAgICAgdGhpcy5PcHRpb25XaWRodCA9ICc0NnB4JztcclxuICAgICAgdGhpcy5saW5lUmlnaHQgPSAnLTIycHgnO1xyXG4gICAgICB0aGlzLm9uVG9nZ2xlTG9nb3V0ID0gZmFsc2U7XHJcbiAgICAgIHRoaXMuTWVudUhlaWdodCA9ICc4NTdweCc7XHJcblxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5pc0NvbGxhcHNlID0gdHJ1ZTtcclxuICAgICAgdGhpcy5NZW51V2lkaHQgPSAnODhweCc7XHJcbiAgICAgIHRoaXMuT3B0aW9uV2lkaHQgPSAnNDZweCc7XHJcbiAgICAgIHRoaXMubGluZVJpZ2h0ID0gJy0yMnB4JztcclxuICAgICAgdGhpcy5tdWx0aXBsZUFjY291bnRzU2VsZWN0aW9uID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBvbkFjdGl2ZShvcHRpb246IElNZW51SXRlbXMpIHtcclxuICAgIHRoaXMub3B0aW9uc0RhdGEuZm9yRWFjaCgoZTogYW55KSA9PiB7XHJcbiAgICAgIGlmIChlLnRpdGxlID09PSBvcHRpb24udGl0bGUpIHtcclxuICAgICAgICBvcHRpb24uaXNBY3RpdmUgPSB0cnVlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGUuaXNBY3RpdmUgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICB0b2dnbGVMb2dvdXQoKSB7XHJcbiAgICBpZiAodGhpcy5vblRvZ2dsZUxvZ291dCAmJiAhdGhpcy5pc0NvbGxhcHNlKSB7XHJcbiAgICAgIHRoaXMub25Ub2dnbGVMb2dvdXQgPSBmYWxzZTtcclxuICAgICAgdGhpcy5NZW51SGVpZ2h0ID0gJzg1N3B4JztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMub25Ub2dnbGVMb2dvdXQgPSB0cnVlO1xyXG4gICAgICB0aGlzLk1lbnVIZWlnaHQgPSAnNzgwcHgnO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZXhwYW5kQWNjb3VudHMoKSB7XHJcbiAgICBpZiAodGhpcy5tdWx0aXBsZUFjY291bnRzU2VsZWN0aW9uKSB7XHJcbiAgICAgIHRoaXMubXVsdGlwbGVBY2NvdW50c1NlbGVjdGlvbiA9IGZhbHNlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5tdWx0aXBsZUFjY291bnRzU2VsZWN0aW9uID0gdHJ1ZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN3aXRjaEFjY291bnQoYWNjb3VudDogSVVzZXJEYXRhKSB7XHJcbiAgICB0aGlzLnVzZXJEaXNwbGF5ID0ge30gYXMgSVVzZXJEYXRhO1xyXG4gICAgdGhpcy5vdGhlckFjY291bnRzID0gW107XHJcbiAgICB0aGlzLnNpZGViYXJEYXRhLnVzZXJzLmZvckVhY2goKHVzZXI6IElVc2VyRGF0YSkgPT4ge1xyXG4gICAgICB1c2VyLmlkID09PSBhY2NvdW50LmlkID8gdGhpcy51c2VyRGlzcGxheSA9IHVzZXIgOiB0aGlzLm90aGVyQWNjb3VudHMucHVzaCh1c2VyKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgZmlsdGVyKCkge1xyXG4gICAgdGhpcy5BY2NvdW50c0Rpc3BsYXkgPSBbXTtcclxuICAgIHRoaXMub3RoZXJBY2NvdW50cy5maWx0ZXIoKHVzZXI6IElVc2VyRGF0YSkgPT4ge1xyXG4gICAgICBjb25zdCB0ZXN0ID0gdXNlci5uYW1lLnRvTG9jYWxlTG93ZXJDYXNlKCkuaW5jbHVkZXModGhpcy5pbnB1dEZpbHRlci50b0xvY2FsZUxvd2VyQ2FzZSgpKTtcclxuICAgICAgaWYgKHRlc3QpIHsgdGhpcy5BY2NvdW50c0Rpc3BsYXkucHVzaCh1c2VyKTsgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxufVxyXG4iXX0=