import { Component, Input } from '@angular/core';
export class ChartComponent {
    constructor() {
        this.options = {};
        this.data = [];
        this.labels = [];
    }
    ngOnInit() {
    }
}
ChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-chart',
                template: "<div style=\"width: 100%;\">\r\n  <canvas\r\n    baseChart\r\n    [chartType]=\"type\"\r\n    [datasets]=\"data\"\r\n    [labels]=\"labels\"\r\n    [options]=\"options\"\r\n    [legend]=\"true\"\r\n  >\r\n  </canvas>\r\n</div>\r\n",
                styles: [""]
            },] }
];
ChartComponent.ctorParameters = () => [];
ChartComponent.propDecorators = {
    options: [{ type: Input }],
    data: [{ type: Input }],
    labels: [{ type: Input }],
    type: [{ type: Input }]
};
export var ChartType;
(function (ChartType) {
    ChartType["pie"] = "pie";
    ChartType["doughnut"] = "doughnut";
    ChartType["bar"] = "bar";
    ChartType["line"] = "line";
    ChartType["polarArea"] = "polarArea";
    ChartType["radar"] = "radar";
    ChartType["horizontalBar"] = "horizontalBar";
})(ChartType || (ChartType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhcnQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9Db21wb25lbnRzL09yZ2FuaXNtcy9jaGFydC9jaGFydC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBVSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFPekQsTUFBTSxPQUFPLGNBQWM7SUFPekI7UUFMUyxZQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2IsU0FBSSxHQUFHLEVBQUUsQ0FBQztRQUNWLFdBQU0sR0FBRyxFQUFFLENBQUM7SUFHTCxDQUFDO0lBRWpCLFFBQVE7SUFDUixDQUFDOzs7WUFmRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLGtQQUFxQzs7YUFFdEM7Ozs7c0JBR0UsS0FBSzttQkFDTCxLQUFLO3FCQUNMLEtBQUs7bUJBQ0wsS0FBSzs7QUFTUixNQUFNLENBQU4sSUFBWSxTQVFYO0FBUkQsV0FBWSxTQUFTO0lBQ25CLHdCQUFXLENBQUE7SUFDWCxrQ0FBcUIsQ0FBQTtJQUNyQix3QkFBVyxDQUFBO0lBQ1gsMEJBQWEsQ0FBQTtJQUNiLG9DQUF1QixDQUFBO0lBQ3ZCLDRCQUFlLENBQUE7SUFDZiw0Q0FBK0IsQ0FBQTtBQUNqQyxDQUFDLEVBUlcsU0FBUyxLQUFULFNBQVMsUUFRcEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LWNoYXJ0JyxcclxuICB0ZW1wbGF0ZVVybDogJy4vY2hhcnQuY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL2NoYXJ0LmNvbXBvbmVudC5sZXNzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIENoYXJ0Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgQElucHV0KCkgb3B0aW9ucyA9IHt9O1xyXG4gIEBJbnB1dCgpIGRhdGEgPSBbXTtcclxuICBASW5wdXQoKSBsYWJlbHMgPSBbXTtcclxuICBASW5wdXQoKSB0eXBlOiBDaGFydFR5cGU7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gIH1cclxuXHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIENoYXJ0VHlwZSB7XHJcbiAgcGllID0gJ3BpZScsXHJcbiAgZG91Z2hudXQgPSAnZG91Z2hudXQnLFxyXG4gIGJhciA9ICdiYXInLFxyXG4gIGxpbmUgPSAnbGluZScsXHJcbiAgcG9sYXJBcmVhID0gJ3BvbGFyQXJlYScsXHJcbiAgcmFkYXIgPSAncmFkYXInLFxyXG4gIGhvcml6b250YWxCYXIgPSAnaG9yaXpvbnRhbEJhcidcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJQ2hhcnQge1xyXG4gIGRhdGE6IEFycmF5PElEYXRhPjtcclxuICBsYWJlbHM6IEFycmF5PHN0cmluZz47XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSURhdGEge1xyXG4gIGRhdGE6IG51bWJlcjtcclxuICBsYWJlbDogc3RyaW5nO1xyXG59XHJcblxyXG4iXX0=