import { Component, Input } from '@angular/core';
export class TableComponent {
    constructor() { }
    ngOnInit() {
        this.totalData = this.dataSet.length;
    }
}
TableComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-table',
                template: "<nz-table class=\"table\" #secondTable [nzData]=\"dataSet\">\r\n  <thead>\r\n    <tr>\r\n      <th *ngIf=\"checkboxOn\">\r\n        <spt-checkbox></spt-checkbox>\r\n      </th>\r\n      <th *ngFor=\"let title of rows\">\r\n        <b>{{ title }}</b>\r\n      </th>\r\n    </tr>\r\n  </thead>\r\n  <tbody>\r\n    <tr *ngFor=\"let data of secondTable.data\">\r\n      <td *ngIf=\"checkboxOn\">\r\n        <spt-checkbox></spt-checkbox>\r\n      </td>\r\n      <td>{{ data.number }}</td>\r\n      <td>{{ data.date }}</td>\r\n      <td>{{ data.description }}</td>\r\n      <td>{{ data.amount }}</td>\r\n      <td>\r\n        <spt-badge\r\n          [name]=\"data.status ? 'PAID' : 'NOT PAID'\"\r\n          color=\"#66BB6A\"\r\n        ></spt-badge>\r\n      </td>\r\n      <td>{{ data.invoice }}</td>\r\n    </tr>\r\n  </tbody>\r\n</nz-table>\r\n",
                styles: [".table{font-family:Nunito Sans;font-style:normal;font-weight:400;font-size:14px;line-height:24px;border:1px solid #e2e2e2;border-radius:4px}thead,tr:hover{background-color:#fff}thead>tr>th{background:#fff}"]
            },] }
];
TableComponent.ctorParameters = () => [];
TableComponent.propDecorators = {
    checkboxOn: [{ type: Input }],
    rows: [{ type: Input }],
    dataSet: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFibGUuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9Db21wb25lbnRzL09yZ2FuaXNtcy90YWJsZS90YWJsZS5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFnQnpELE1BQU0sT0FBTyxjQUFjO0lBUXpCLGdCQUFnQixDQUFDO0lBRWpCLFFBQVE7UUFDTixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO0lBQ3ZDLENBQUM7OztZQWpCRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLHMxQkFBcUM7O2FBRXRDOzs7O3lCQUdFLEtBQUs7bUJBQ0wsS0FBSztzQkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElEYXRhU2V0IHtcclxuICBudW1iZXI6IG51bWJlcjtcclxuICBkYXRlOiBzdHJpbmc7XHJcbiAgZGVzY3JpcHRpb246IHN0cmluZztcclxuICBhbW91bnQ6IHN0cmluZztcclxuICBzdGF0dXM6IGJvb2xlYW47XHJcbiAgaW52b2ljZTogc3RyaW5nO1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3NwdC10YWJsZScsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3RhYmxlLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi90YWJsZS5jb21wb25lbnQubGVzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBUYWJsZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIEBJbnB1dCgpIGNoZWNrYm94T246IGJvb2xlYW47XHJcbiAgQElucHV0KCkgcm93czogW107XHJcbiAgQElucHV0KCkgZGF0YVNldDogSURhdGFTZXRbXTtcclxuXHJcbiAgdG90YWxEYXRhOiBudW1iZXI7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gICAgdGhpcy50b3RhbERhdGEgPSB0aGlzLmRhdGFTZXQubGVuZ3RoO1xyXG4gIH1cclxuXHJcbn1cclxuIl19