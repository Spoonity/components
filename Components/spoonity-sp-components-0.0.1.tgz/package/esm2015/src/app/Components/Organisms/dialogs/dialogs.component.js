import { Component, ViewChild, ViewContainerRef } from '@angular/core';
import { NzModalService } from 'ng-zorro-antd/modal';
export class DialogsComponent {
    constructor(modal, viewContainerRef) {
        this.modal = modal;
        this.viewContainerRef = viewContainerRef;
    }
    createModal(dialog) {
        this.dialog = dialog;
        this.createTplModal(this.tplTitle, this.tplContent, this.tplFooter);
    }
    createTplModal(tplTitle, tplContent, tplFooter) {
        this.modalRef = this.modal.create({
            nzTitle: tplTitle,
            nzContent: tplContent,
            nzFooter: tplFooter,
            nzMaskClosable: false,
            nzClosable: true,
        });
    }
    ngOnInit() {
    }
}
DialogsComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-dialogs',
                template: "<ng-template #tplTitle>\r\n  <span class=\"title\">\r\n    {{ dialog.title }}\r\n  </span>\r\n</ng-template>\r\n<ng-template #tplContent>\r\n  <span class=\"content\">\r\n    {{ dialog.content }}\r\n  </span>\r\n</ng-template>\r\n<ng-template #tplFooter let-ref=\"modalRef\">\r\n  <button\r\n    nz-button\r\n    nzType=\"secondary\"\r\n    (click)=\"modalRef.destroy(); dialog.action1()\"\r\n  >\r\n    {{ dialog.action1Label }}\r\n  </button>\r\n  <button\r\n    nz-button\r\n    nzType=\"primary\"\r\n    (click)=\"modalRef.destroy(); dialog.action2()\"\r\n  >\r\n    {{ dialog.action2Label }}\r\n  </button>\r\n</ng-template>\r\n",
                styles: [".title{font-family:Nunito;font-weight:700;font-size:24px;line-height:32px;color:#0d0c0b}.content,.title{font-style:normal}.content{font-family:Nunito Sans;font-weight:400;font-size:16px;line-height:24px;color:#4f4e4d}"]
            },] }
];
DialogsComponent.ctorParameters = () => [
    { type: NzModalService },
    { type: ViewContainerRef }
];
DialogsComponent.propDecorators = {
    tplTitle: [{ type: ViewChild, args: ['tplTitle',] }],
    tplContent: [{ type: ViewChild, args: ['tplContent',] }],
    tplFooter: [{ type: ViewChild, args: ['tplFooter',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlhbG9ncy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL0NvbXBvbmVudHMvT3JnYW5pc21zL2RpYWxvZ3MvZGlhbG9ncy5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBOEIsU0FBUyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ25HLE9BQU8sRUFBYyxjQUFjLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQztBQU9qRSxNQUFNLE9BQU8sZ0JBQWdCO0lBUzNCLFlBQW9CLEtBQXFCLEVBQVUsZ0JBQWtDO1FBQWpFLFVBQUssR0FBTCxLQUFLLENBQWdCO1FBQVUscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFrQjtJQUFJLENBQUM7SUFFMUYsV0FBVyxDQUFDLE1BQWM7UUFDeEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFFRCxjQUFjLENBQUMsUUFBeUIsRUFBRSxVQUEyQixFQUFFLFNBQTBCO1FBQy9GLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDaEMsT0FBTyxFQUFFLFFBQVE7WUFDakIsU0FBUyxFQUFFLFVBQVU7WUFDckIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsY0FBYyxFQUFFLEtBQUs7WUFDckIsVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELFFBQVE7SUFDUixDQUFDOzs7WUFoQ0YsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxhQUFhO2dCQUN2Qixxb0JBQXVDOzthQUV4Qzs7O1lBTm9CLGNBQWM7WUFEd0IsZ0JBQWdCOzs7dUJBYXhFLFNBQVMsU0FBQyxVQUFVO3lCQUNwQixTQUFTLFNBQUMsWUFBWTt3QkFDdEIsU0FBUyxTQUFDLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQsIFRlbXBsYXRlUmVmLCBWaWV3Q2hpbGQsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTnpNb2RhbFJlZiwgTnpNb2RhbFNlcnZpY2UgfSBmcm9tICduZy16b3Jyby1hbnRkL21vZGFsJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LWRpYWxvZ3MnLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9kaWFsb2dzLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9kaWFsb2dzLmNvbXBvbmVudC5sZXNzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIERpYWxvZ3NDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG5cclxuICBkaWFsb2c6IElNb2RhbDtcclxuXHJcbiAgbW9kYWxSZWY6IE56TW9kYWxSZWY7XHJcbiAgQFZpZXdDaGlsZCgndHBsVGl0bGUnKSB0cGxUaXRsZT86IFRlbXBsYXRlUmVmPHt9PjtcclxuICBAVmlld0NoaWxkKCd0cGxDb250ZW50JykgdHBsQ29udGVudD86IFRlbXBsYXRlUmVmPHt9PjtcclxuICBAVmlld0NoaWxkKCd0cGxGb290ZXInKSB0cGxGb290ZXI/OiBUZW1wbGF0ZVJlZjx7fT47XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgbW9kYWw6IE56TW9kYWxTZXJ2aWNlLCBwcml2YXRlIHZpZXdDb250YWluZXJSZWY6IFZpZXdDb250YWluZXJSZWYpIHsgfVxyXG5cclxuICBjcmVhdGVNb2RhbChkaWFsb2c6IElNb2RhbCkge1xyXG4gICAgdGhpcy5kaWFsb2cgPSBkaWFsb2c7XHJcbiAgICB0aGlzLmNyZWF0ZVRwbE1vZGFsKHRoaXMudHBsVGl0bGUsIHRoaXMudHBsQ29udGVudCwgdGhpcy50cGxGb290ZXIpO1xyXG4gIH1cclxuXHJcbiAgY3JlYXRlVHBsTW9kYWwodHBsVGl0bGU6IFRlbXBsYXRlUmVmPHt9PiwgdHBsQ29udGVudDogVGVtcGxhdGVSZWY8e30+LCB0cGxGb290ZXI6IFRlbXBsYXRlUmVmPHt9Pik6IHZvaWQge1xyXG4gICAgdGhpcy5tb2RhbFJlZiA9IHRoaXMubW9kYWwuY3JlYXRlKHtcclxuICAgICAgbnpUaXRsZTogdHBsVGl0bGUsXHJcbiAgICAgIG56Q29udGVudDogdHBsQ29udGVudCxcclxuICAgICAgbnpGb290ZXI6IHRwbEZvb3RlcixcclxuICAgICAgbnpNYXNrQ2xvc2FibGU6IGZhbHNlLFxyXG4gICAgICBuekNsb3NhYmxlOiB0cnVlLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElNb2RhbCB7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBjb250ZW50OiBzdHJpbmc7XHJcbiAgYWN0aW9uMTogKCkgPT4gYW55O1xyXG4gIGFjdGlvbjI6ICgpID0+IGFueTtcclxuICBhY3Rpb24xTGFiZWw6IHN0cmluZztcclxuICBhY3Rpb24yTGFiZWw6IHN0cmluZztcclxufVxyXG4iXX0=