import { Component, EventEmitter, Input, Output } from '@angular/core';
export class CheckboxComponent {
    constructor() {
        this.span = 8;
        this.onChangeEvent = new EventEmitter();
    }
    ngOnInit() {
    }
    onChange(e) {
        this.onChangeEvent.emit(e);
    }
}
CheckboxComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-checkbox',
                template: "<div nz-col [nzSpan]=\"span\"><label nz-checkbox [nzIndeterminate]=\"indeterminate\" [ngModel]=\"check\" (ngModelChange)=\"onChange($event)\" [nzValue]=\"value\">{{value}}</label></div>",
                styles: [""]
            },] }
];
CheckboxComponent.ctorParameters = () => [];
CheckboxComponent.propDecorators = {
    indeterminate: [{ type: Input }],
    check: [{ type: Input }],
    value: [{ type: Input }],
    onChangeEvent: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tib3guY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9Db21wb25lbnRzL0F0b21zL2NoZWNrYm94L2NoZWNrYm94LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQVUsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBTy9FLE1BQU0sT0FBTyxpQkFBaUI7SUFFNUI7UUFLQSxTQUFJLEdBQUcsQ0FBQyxDQUFDO1FBTUMsa0JBQWEsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO0lBWGxDLENBQUM7SUFFakIsUUFBUTtJQUNSLENBQUM7SUFVRCxRQUFRLENBQUMsQ0FBTTtRQUNiLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzdCLENBQUM7OztZQXRCRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLGNBQWM7Z0JBQ3hCLHFNQUF3Qzs7YUFFekM7Ozs7NEJBVUUsS0FBSztvQkFDTCxLQUFLO29CQUNMLEtBQUs7NEJBRUwsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25Jbml0LCBPdXRwdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LWNoZWNrYm94JyxcclxuICB0ZW1wbGF0ZVVybDogJy4vY2hlY2tib3guY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL2NoZWNrYm94LmNvbXBvbmVudC5sZXNzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIENoZWNrYm94Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxuICBzcGFuID0gODtcclxuXHJcbiAgQElucHV0KCkgaW5kZXRlcm1pbmF0ZTogYm9vbGVhbjtcclxuICBASW5wdXQoKSBjaGVjazogYm9vbGVhbjtcclxuICBASW5wdXQoKSB2YWx1ZTogc3RyaW5nO1xyXG5cclxuICBAT3V0cHV0KCkgb25DaGFuZ2VFdmVudCA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG5cclxuICBvbkNoYW5nZShlOiBhbnkpIHtcclxuICAgIHRoaXMub25DaGFuZ2VFdmVudC5lbWl0KGUpO1xyXG4gIH1cclxuXHJcbn1cclxuIl19