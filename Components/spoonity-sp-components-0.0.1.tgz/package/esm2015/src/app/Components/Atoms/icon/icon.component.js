import { Component, Input } from '@angular/core';
export class IconComponent {
    constructor() {
        this.color = '#0D0C0B';
        this.svgIconSettings = {
            'width': '20px',
            'fill': this.color
        };
    }
    ngOnInit() { }
}
IconComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-icon',
                template: "\r\n  <span nz-tooltip [nzTooltipTitle]=\"toolTipTittle\"><svg-icon class=\"icons\" [name]=\"name\" [svgStyle]=\"svgIconSettings\"></svg-icon></span>\r\n",
                styles: ["svg-icon{vertical-align:text-bottom}"]
            },] }
];
IconComponent.ctorParameters = () => [];
IconComponent.propDecorators = {
    toolTipTittle: [{ type: Input }],
    name: [{ type: Input }],
    color: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL0NvbXBvbmVudHMvQXRvbXMvaWNvbi9pY29uLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBVSxNQUFNLGVBQWUsQ0FBQztBQU96RCxNQUFNLE9BQU8sYUFBYTtJQVd4QjtRQVBTLFVBQUssR0FBRyxTQUFTLENBQUM7UUFFM0Isb0JBQWUsR0FBRztZQUNmLE9BQU8sRUFBRyxNQUFNO1lBQ2hCLE1BQU0sRUFBRyxJQUFJLENBQUMsS0FBSztTQUNuQixDQUFBO0lBRVksQ0FBQztJQUVoQixRQUFRLEtBQUksQ0FBQzs7O1lBbEJkLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIscUtBQW9DOzthQUVyQzs7Ozs0QkFHRSxLQUFLO21CQUNMLEtBQUs7b0JBQ0wsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdzcHQtaWNvbicsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2ljb24uY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL2ljb24uY29tcG9uZW50Lmxlc3MnXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgSWNvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIEBJbnB1dCgpIHRvb2xUaXBUaXR0bGU6IHN0cmluZztcclxuICBASW5wdXQoKSBuYW1lOiBzdHJpbmc7XHJcbiAgQElucHV0KCkgY29sb3IgPSAnIzBEMEMwQic7XHJcblxyXG4gIHN2Z0ljb25TZXR0aW5ncyA9IHtcclxuICAgICAnd2lkdGgnIDogJzIwcHgnLFxyXG4gICAgICdmaWxsJyA6IHRoaXMuY29sb3JcclxuICAgIH1cclxuXHJcbiAgY29uc3RydWN0b3IoKSB7fVxyXG5cclxuICBuZ09uSW5pdCgpIHt9XHJcbn1cclxuIl19