import { Component } from '@angular/core';
export class ElevationComponent {
    constructor() { }
    ngOnInit() {
    }
}
ElevationComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-elevation',
                template: "<div class=\"elevation\">\r\n    <div class=\"elevation-container\">\r\n        <p>01 dp</p>\r\n        <div class=\"spt-elevation--1 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>02 dp</p>\r\n        <div class=\"spt-elevation--2 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>06 dp</p>\r\n        <div class=\"spt-elevation--3 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>08 dp</p>\r\n        <div class=\"spt-elevation--4 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>12 dp</p>\r\n        <div class=\"spt-elevation--5 elevation-box\"></div>\r\n    </div>\r\n    <div class=\"elevation-container\">\r\n        <p>24 dp</p>\r\n        <div class=\"spt-elevation--6 elevation-box\"></div>\r\n    </div>\r\n</div>\r\n",
                styles: [".elevation{display:flex;flex-wrap:wrap}.elevation .elevation-container{margin-top:20px}.elevation .elevation-container p{margin-bottom:5px}.elevation .elevation-container .elevation-box{width:280px;height:184px;margin:10px}"]
            },] }
];
ElevationComponent.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWxldmF0aW9uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9BdG9tcy9lbGV2YXRpb24vZWxldmF0aW9uLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFVLE1BQU0sZUFBZSxDQUFDO0FBT2xELE1BQU0sT0FBTyxrQkFBa0I7SUFFN0IsZ0JBQWdCLENBQUM7SUFFakIsUUFBUTtJQUNSLENBQUM7OztZQVZGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsZUFBZTtnQkFDekIseTVCQUF5Qzs7YUFFMUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdzcHQtZWxldmF0aW9uJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vZWxldmF0aW9uLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9lbGV2YXRpb24uY29tcG9uZW50Lmxlc3MnXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgRWxldmF0aW9uQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxufVxyXG4iXX0=