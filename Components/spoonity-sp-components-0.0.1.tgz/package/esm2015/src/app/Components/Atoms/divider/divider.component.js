import { DividerType } from './../../../utils/enums';
import { Component, Input } from '@angular/core';
export class DividerComponent {
    constructor() {
        this.type = DividerType.horizontal;
    }
    ngOnInit() {
    }
}
DividerComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-divider',
                template: "<nz-divider class=\"divider\" [nzType]=\"type\"></nz-divider>",
                styles: [".divider{height:1px;margin:0}"]
            },] }
];
DividerComponent.ctorParameters = () => [];
DividerComponent.propDecorators = {
    type: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGl2aWRlci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL0NvbXBvbmVudHMvQXRvbXMvZGl2aWRlci9kaXZpZGVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDckQsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFPekQsTUFBTSxPQUFPLGdCQUFnQjtJQUUzQjtRQUtTLFNBQUksR0FBVyxXQUFXLENBQUMsVUFBVSxDQUFDO0lBTC9CLENBQUM7SUFFakIsUUFBUTtJQUNSLENBQUM7OztZQVZGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsYUFBYTtnQkFDdkIseUVBQXVDOzthQUV4Qzs7OzttQkFRRSxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGl2aWRlclR5cGUgfSBmcm9tICcuLy4uLy4uLy4uL3V0aWxzL2VudW1zJztcclxuaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3NwdC1kaXZpZGVyJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vZGl2aWRlci5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vZGl2aWRlci5jb21wb25lbnQubGVzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBEaXZpZGVyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxuICBASW5wdXQoKSB0eXBlOiBzdHJpbmcgPSBEaXZpZGVyVHlwZS5ob3Jpem9udGFsO1xyXG5cclxufVxyXG4iXX0=