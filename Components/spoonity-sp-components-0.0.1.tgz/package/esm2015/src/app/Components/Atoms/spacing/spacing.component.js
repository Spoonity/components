import { Component } from '@angular/core';
export class SpacingComponent {
    constructor() {
        this.spacing = [
            {
                sectionName: '8px',
                sectionClassName: 'spacing--8',
                sections: [
                    { label: '8px (around)', className: 'spt-spacing--1' },
                    { label: '8px (vertical)', className: 'spt-spacing-y--1' },
                    { label: '8px (horizontal)', className: 'spt-spacing-x--1' },
                    { label: '8px (top)', className: 'spt-spacing-y-top--1' },
                    { label: '8px (bottom)', className: 'spt-spacing-y-bottom--1' },
                    { label: '8px (left)', className: 'spt-spacing-y-left--1' },
                    { label: '8px (right)', className: 'spt-spacing-y-right--1' },
                ]
            },
            {
                sectionName: '16px',
                sectionClassName: 'spacing--16',
                sections: [
                    { label: '16px (around)', className: 'spt-spacing--2' },
                    { label: '16px (top)', className: 'spt-spacing-y-top--2' },
                    { label: '8px (vertical)', className: 'spt-spacing-y--2' },
                    { label: '8px (horizontal)', className: 'spt-spacing-x--2' },
                    { label: '16px (bottom)', className: 'spt-spacing-y-bottom--2' },
                    { label: '16px (left)', className: 'spt-spacing-y-left--2' },
                    { label: '16px (right)', className: 'spt-spacing-y-right--2' },
                ]
            }
        ];
        this.spacing = this.getSpacing();
    }
    ngOnInit() {
    }
    getSpacing() {
        const spacing = [];
        const offsetArr = [1, 2, 3, 6, 8, 10, 14];
        const sections = [
            { label: '(around)', className: 'spt-spacing' },
            { label: '(vertical)', className: 'spt-spacing-y' },
            { label: '(horizontal)', className: 'spt-spacing-x' },
            { label: '(top)', className: 'spt-spacing-y-top' },
            { label: '(bottom)', className: 'spt-spacing-y-bottom' },
            { label: '(left)', className: 'spt-spacing-y-left' },
            { label: '(right)', className: 'spt-spacing-y-right' },
        ];
        offsetArr.forEach((offset, i) => {
            const size = 8 * offset;
            const currentSections = Array.from(sections, s => {
                return {
                    label: `${size}px ${s.label}`,
                    className: `${s.className}--${i + 1}`
                };
            });
            const newSection = {
                sectionClassName: `spacing--${size}`,
                sectionName: `${size}px`,
                sections: currentSections
            };
            spacing.push(newSection);
        });
        return spacing;
    }
}
SpacingComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-spacing',
                template: "<div class=\"spacing\">\r\n    <div *ngFor=\"let section of spacing\" class=\"spacing-section\">\r\n        <h3>{{ section.sectionName }}</h3>\r\n        <div class=\"spacing-container\">\r\n            <div *ngFor=\"let subsection of section.sections\" class=\"spacing-example\">\r\n                <div class=\"spacing-wrapper spt-elevation--2 {{ section.sectionClassName }} {{subsection.className}}\">\r\n                    <div class=\"spacing-box\">\r\n                        <p class=\"spacing-label\">{{ subsection.label }}</p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n",
                styles: [".spacing .spacing-section{padding-top:20px}.spacing .spacing-section .spacing-container{display:flex;align-content:center;flex-wrap:wrap}.spacing .spacing-section .spacing-container .spacing-example{text-align:center;padding:10px}.spacing .spacing-section .spacing-container .spacing-example .spacing--8{background-color:rgba(239,83,80,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--16{background-color:rgba(236,64,122,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--24{background-color:rgba(171,71,188,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--48{background-color:rgba(126,87,194,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--64{background-color:rgba(92,107,192,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--80{background-color:rgba(66,165,245,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing--112{background-color:rgba(38,198,218,.3)}.spacing .spacing-section .spacing-container .spacing-example .spacing-wrapper{width:-webkit-fit-content;width:-moz-fit-content;width:fit-content;margin:0 auto}.spacing .spacing-section .spacing-container .spacing-example .spacing-wrapper .spacing-box{width:80px;height:80px;background-color:#fff;display:flex;align-items:center;justify-content:center}.spacing .spacing-section .spacing-container .spacing-example .spacing-wrapper .spacing-box p{font-size:12px}"]
            },] }
];
SpacingComponent.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BhY2luZy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL0NvbXBvbmVudHMvQXRvbXMvc3BhY2luZy9zcGFjaW5nLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQyxPQUFPLEVBQUUsU0FBUyxFQUFVLE1BQU0sZUFBZSxDQUFDO0FBYW5ELE1BQU0sT0FBTyxnQkFBZ0I7SUErQjNCO1FBN0JBLFlBQU8sR0FBZTtZQUNwQjtnQkFDRSxXQUFXLEVBQUUsS0FBSztnQkFDbEIsZ0JBQWdCLEVBQUUsWUFBWTtnQkFDOUIsUUFBUSxFQUFFO29CQUNSLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUU7b0JBQ3RELEVBQUUsS0FBSyxFQUFFLGdCQUFnQixFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRTtvQkFDMUQsRUFBRSxLQUFLLEVBQUUsa0JBQWtCLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFO29CQUM1RCxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLHNCQUFzQixFQUFFO29CQUN6RCxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLHlCQUF5QixFQUFFO29CQUMvRCxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLHVCQUF1QixFQUFFO29CQUMzRCxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLHdCQUF3QixFQUFFO2lCQUM5RDthQUNGO1lBQ0Q7Z0JBQ0UsV0FBVyxFQUFFLE1BQU07Z0JBQ25CLGdCQUFnQixFQUFFLGFBQWE7Z0JBQy9CLFFBQVEsRUFBRTtvQkFDUixFQUFFLEtBQUssRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLGdCQUFnQixFQUFFO29CQUN2RCxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLHNCQUFzQixFQUFFO29CQUMxRCxFQUFFLEtBQUssRUFBRSxnQkFBZ0IsRUFBRSxTQUFTLEVBQUUsa0JBQWtCLEVBQUU7b0JBQzFELEVBQUUsS0FBSyxFQUFFLGtCQUFrQixFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRTtvQkFDNUQsRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFLFNBQVMsRUFBRSx5QkFBeUIsRUFBRTtvQkFDaEUsRUFBRSxLQUFLLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSx1QkFBdUIsRUFBRTtvQkFDNUQsRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSx3QkFBd0IsRUFBRTtpQkFDL0Q7YUFDRjtTQUNGLENBQUM7UUFHQSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUNuQyxDQUFDO0lBRUQsUUFBUTtJQUNSLENBQUM7SUFHRCxVQUFVO1FBQ1IsTUFBTSxPQUFPLEdBQWUsRUFBRSxDQUFDO1FBQy9CLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDMUMsTUFBTSxRQUFRLEdBQUc7WUFDZixFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRTtZQUMvQyxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLGVBQWUsRUFBQztZQUNsRCxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLGVBQWUsRUFBRTtZQUNyRCxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLG1CQUFtQixFQUFFO1lBQ2xELEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsc0JBQXNCLEVBQUU7WUFDeEQsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxvQkFBb0IsRUFBRTtZQUNwRCxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLHFCQUFxQixFQUFFO1NBQ3ZELENBQUM7UUFFRixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBYyxFQUFFLENBQVMsRUFBRSxFQUFFO1lBQzlDLE1BQU0sSUFBSSxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUM7WUFDeEIsTUFBTSxlQUFlLEdBQXlDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUM3RSxDQUFDLENBQUMsRUFBRTtnQkFDRixPQUFPO29CQUNMLEtBQUssRUFBRSxHQUFHLElBQUksTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFO29CQUM3QixTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsU0FBUyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUU7aUJBQ3RDLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztZQUVQLE1BQU0sVUFBVSxHQUFhO2dCQUMzQixnQkFBZ0IsRUFBRSxZQUFZLElBQUksRUFBRTtnQkFDcEMsV0FBVyxFQUFFLEdBQUcsSUFBSSxJQUFJO2dCQUN4QixRQUFRLEVBQUUsZUFBZTthQUMxQixDQUFDO1lBRUYsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sT0FBTyxDQUFDO0lBQ2pCLENBQUM7OztZQTdFRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLGFBQWE7Z0JBQ3ZCLGdxQkFBdUM7O2FBRXhDIiwic291cmNlc0NvbnRlbnQiOlsiIGltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5pbnRlcmZhY2UgSVNwYWNpbmcge1xyXG4gIHNlY3Rpb25OYW1lOiBzdHJpbmc7XHJcbiAgc2VjdGlvbkNsYXNzTmFtZTogc3RyaW5nO1xyXG4gIHNlY3Rpb25zOiB7bGFiZWw6IHN0cmluZywgY2xhc3NOYW1lOiBzdHJpbmd9W107XHJcbn1cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LXNwYWNpbmcnLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9zcGFjaW5nLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9zcGFjaW5nLmNvbXBvbmVudC5sZXNzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIFNwYWNpbmdDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG5cclxuICBzcGFjaW5nOiBJU3BhY2luZ1tdID0gW1xyXG4gICAge1xyXG4gICAgICBzZWN0aW9uTmFtZTogJzhweCcsXHJcbiAgICAgIHNlY3Rpb25DbGFzc05hbWU6ICdzcGFjaW5nLS04JyxcclxuICAgICAgc2VjdGlvbnM6IFtcclxuICAgICAgICB7IGxhYmVsOiAnOHB4IChhcm91bmQpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmctLTEnIH0sXHJcbiAgICAgICAgeyBsYWJlbDogJzhweCAodmVydGljYWwpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmcteS0tMScgfSxcclxuICAgICAgICB7IGxhYmVsOiAnOHB4IChob3Jpem9udGFsKScsIGNsYXNzTmFtZTogJ3NwdC1zcGFjaW5nLXgtLTEnIH0sXHJcbiAgICAgICAgeyBsYWJlbDogJzhweCAodG9wKScsIGNsYXNzTmFtZTogJ3NwdC1zcGFjaW5nLXktdG9wLS0xJyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICc4cHggKGJvdHRvbSknLCBjbGFzc05hbWU6ICdzcHQtc3BhY2luZy15LWJvdHRvbS0tMScgfSxcclxuICAgICAgICB7IGxhYmVsOiAnOHB4IChsZWZ0KScsIGNsYXNzTmFtZTogJ3NwdC1zcGFjaW5nLXktbGVmdC0tMScgfSxcclxuICAgICAgICB7IGxhYmVsOiAnOHB4IChyaWdodCknLCBjbGFzc05hbWU6ICdzcHQtc3BhY2luZy15LXJpZ2h0LS0xJyB9LFxyXG4gICAgICBdXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBzZWN0aW9uTmFtZTogJzE2cHgnLFxyXG4gICAgICBzZWN0aW9uQ2xhc3NOYW1lOiAnc3BhY2luZy0tMTYnLFxyXG4gICAgICBzZWN0aW9uczogW1xyXG4gICAgICAgIHsgbGFiZWw6ICcxNnB4IChhcm91bmQpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmctLTInIH0sXHJcbiAgICAgICAgeyBsYWJlbDogJzE2cHggKHRvcCknLCBjbGFzc05hbWU6ICdzcHQtc3BhY2luZy15LXRvcC0tMicgfSxcclxuICAgICAgICB7IGxhYmVsOiAnOHB4ICh2ZXJ0aWNhbCknLCBjbGFzc05hbWU6ICdzcHQtc3BhY2luZy15LS0yJyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICc4cHggKGhvcml6b250YWwpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmcteC0tMicgfSxcclxuICAgICAgICB7IGxhYmVsOiAnMTZweCAoYm90dG9tKScsIGNsYXNzTmFtZTogJ3NwdC1zcGFjaW5nLXktYm90dG9tLS0yJyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICcxNnB4IChsZWZ0KScsIGNsYXNzTmFtZTogJ3NwdC1zcGFjaW5nLXktbGVmdC0tMicgfSxcclxuICAgICAgICB7IGxhYmVsOiAnMTZweCAocmlnaHQpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmcteS1yaWdodC0tMicgfSxcclxuICAgICAgXVxyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgdGhpcy5zcGFjaW5nID0gdGhpcy5nZXRTcGFjaW5nKCk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICB9XHJcblxyXG5cclxuICBnZXRTcGFjaW5nKCk6IElTcGFjaW5nW10ge1xyXG4gICAgY29uc3Qgc3BhY2luZzogSVNwYWNpbmdbXSA9IFtdO1xyXG4gICAgY29uc3Qgb2Zmc2V0QXJyID0gWzEsIDIsIDMsIDYsIDgsIDEwLCAxNF07XHJcbiAgICBjb25zdCBzZWN0aW9ucyA9IFtcclxuICAgICAgeyBsYWJlbDogJyhhcm91bmQpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmcnIH0sXHJcbiAgICAgIHsgbGFiZWw6ICcodmVydGljYWwpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmcteSd9LFxyXG4gICAgICB7IGxhYmVsOiAnKGhvcml6b250YWwpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmcteCcgfSxcclxuICAgICAgeyBsYWJlbDogJyh0b3ApJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmcteS10b3AnIH0sXHJcbiAgICAgIHsgbGFiZWw6ICcoYm90dG9tKScsIGNsYXNzTmFtZTogJ3NwdC1zcGFjaW5nLXktYm90dG9tJyB9LFxyXG4gICAgICB7IGxhYmVsOiAnKGxlZnQpJywgY2xhc3NOYW1lOiAnc3B0LXNwYWNpbmcteS1sZWZ0JyB9LFxyXG4gICAgICB7IGxhYmVsOiAnKHJpZ2h0KScsIGNsYXNzTmFtZTogJ3NwdC1zcGFjaW5nLXktcmlnaHQnIH0sXHJcbiAgICBdO1xyXG5cclxuICAgIG9mZnNldEFyci5mb3JFYWNoKChvZmZzZXQ6IG51bWJlciwgaTogbnVtYmVyKSA9PiB7XHJcbiAgICAgIGNvbnN0IHNpemUgPSA4ICogb2Zmc2V0O1xyXG4gICAgICBjb25zdCBjdXJyZW50U2VjdGlvbnM6IHtsYWJlbDogc3RyaW5nOyBjbGFzc05hbWU6IHN0cmluZ31bXSA9IEFycmF5LmZyb20oc2VjdGlvbnMsXHJcbiAgICAgICAgICBzID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBsYWJlbDogYCR7c2l6ZX1weCAke3MubGFiZWx9YCxcclxuICAgICAgICAgICAgICBjbGFzc05hbWU6IGAke3MuY2xhc3NOYW1lfS0tJHtpICsgMX1gXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IG5ld1NlY3Rpb246IElTcGFjaW5nID0ge1xyXG4gICAgICAgIHNlY3Rpb25DbGFzc05hbWU6IGBzcGFjaW5nLS0ke3NpemV9YCxcclxuICAgICAgICBzZWN0aW9uTmFtZTogYCR7c2l6ZX1weGAsXHJcbiAgICAgICAgc2VjdGlvbnM6IGN1cnJlbnRTZWN0aW9uc1xyXG4gICAgICB9O1xyXG5cclxuICAgICAgc3BhY2luZy5wdXNoKG5ld1NlY3Rpb24pO1xyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHNwYWNpbmc7XHJcbiAgfVxyXG5cclxufVxyXG4iXX0=