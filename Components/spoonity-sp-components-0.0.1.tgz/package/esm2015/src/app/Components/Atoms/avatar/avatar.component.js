import { Component, Input } from '@angular/core';
export class AvatarComponent {
    constructor() { }
    ngOnInit() {
        this.styles = { 'background-color': this.backgroundColor, 'color': this.color };
    }
}
AvatarComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-avatar',
                template: "<nz-avatar [nzText]=\"text\" [nzSize]=\"size\" [ngStyle]=\"styles\"></nz-avatar>\r\n",
                styles: ["nz-avatar{margin:10px}"]
            },] }
];
AvatarComponent.ctorParameters = () => [];
AvatarComponent.propDecorators = {
    size: [{ type: Input }],
    text: [{ type: Input }],
    color: [{ type: Input }],
    backgroundColor: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXZhdGFyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9BdG9tcy9hdmF0YXIvYXZhdGFyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBVSxNQUFNLGVBQWUsQ0FBQztBQVF6RCxNQUFNLE9BQU8sZUFBZTtJQVMxQixnQkFBZ0IsQ0FBQztJQUVqQixRQUFRO1FBQ04sSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsT0FBTyxFQUFHLElBQUksQ0FBQyxLQUFLLEVBQUMsQ0FBQztJQUNqRixDQUFDOzs7WUFsQkYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxZQUFZO2dCQUN0QixnR0FBc0M7O2FBRXZDOzs7O21CQUdFLEtBQUs7bUJBQ0wsS0FBSztvQkFDTCxLQUFLOzhCQUNMLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQXZhdGFyU2l6ZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2VudW1zJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LWF2YXRhcicsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2F2YXRhci5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vYXZhdGFyLmNvbXBvbmVudC5sZXNzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIEF2YXRhckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIEBJbnB1dCgpIHNpemU6IEF2YXRhclNpemU7XHJcbiAgQElucHV0KCkgdGV4dDogc3RyaW5nO1xyXG4gIEBJbnB1dCgpIGNvbG9yOiBzdHJpbmc7XHJcbiAgQElucHV0KCkgYmFja2dyb3VuZENvbG9yOiBzdHJpbmc7XHJcblxyXG4gIHN0eWxlczogeyAnYmFja2dyb3VuZC1jb2xvcic6IHN0cmluZzsgY29sb3I6IHN0cmluZzsgfTtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICB0aGlzLnN0eWxlcyA9IHsnYmFja2dyb3VuZC1jb2xvcic6IHRoaXMuYmFja2dyb3VuZENvbG9yLCAnY29sb3InIDogdGhpcy5jb2xvcn07XHJcbiAgfVxyXG5cclxufVxyXG4iXX0=