import { Component, Input } from '@angular/core';
export class RadioButtonComponent {
    constructor() {
        this.radioButtons = [
            { radioName: 'A', disable: false },
            { radioName: 'B', disable: true },
            { radioName: 'C', disable: false },
            { radioName: 'D', disable: false },
        ];
    }
    ngOnInit() { }
}
RadioButtonComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-radio-button',
                template: "<nz-radio-group \r\n[ngModel]=\"model\"\r\n>\r\n    <label\r\n    *ngFor=\"let btn of radioButtons\" \r\n    nz-radio \r\n    [nzValue]=\"btn.radioName\"\r\n    [nzDisabled]=\"btn.disable\"\r\n    >{{btn.radioName}}</label>\r\n</nz-radio-group>",
                styles: [""]
            },] }
];
RadioButtonComponent.ctorParameters = () => [];
RadioButtonComponent.propDecorators = {
    model: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmFkaW8tYnV0dG9uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9BdG9tcy9yYWRpby1idXR0b24vcmFkaW8tYnV0dG9uLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBVSxNQUFNLGVBQWUsQ0FBQztBQVN6RCxNQUFNLE9BQU8sb0JBQW9CO0lBRS9CO1FBRUEsaUJBQVksR0FBSTtZQUNaLEVBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDO1lBQ2hDLEVBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFDO1lBQy9CLEVBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDO1lBQ2hDLEVBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFDO1NBQ25DLENBQUM7SUFQYyxDQUFDO0lBV2pCLFFBQVEsS0FBSSxDQUFDOzs7WUFsQmQsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxrQkFBa0I7Z0JBQzVCLGdRQUE0Qzs7YUFFN0M7Ozs7b0JBWUUsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3NwdC1yYWRpby1idXR0b24nLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9yYWRpby1idXR0b24uY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL3JhZGlvLWJ1dHRvbi5jb21wb25lbnQubGVzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBSYWRpb0J1dHRvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIHJhZGlvQnV0dG9ucyA9ICBbXHJcbiAgICAgIHtyYWRpb05hbWU6ICdBJywgZGlzYWJsZTogZmFsc2V9LFxyXG4gICAgICB7cmFkaW9OYW1lOiAnQicsIGRpc2FibGU6IHRydWV9LFxyXG4gICAgICB7cmFkaW9OYW1lOiAnQycsIGRpc2FibGU6IGZhbHNlfSxcclxuICAgICAge3JhZGlvTmFtZTogJ0QnLCBkaXNhYmxlOiBmYWxzZX0sXHJcbiAgXTtcclxuXHJcbiAgQElucHV0KCkgbW9kZWw6IHN0cmluZztcclxuXHJcbiAgbmdPbkluaXQoKSB7fVxyXG5cclxuXHJcbn1cclxuIl19