import { Component, HostBinding, HostListener, Input } from '@angular/core';
import { SearchService } from '../search.service';
export class SearchOptionComponent {
    constructor(_searchService) {
        this._searchService = _searchService;
        /* bind class.active */
        this.active = false;
        this.search = this._searchService.getSearch();
    }
    /* bind class.selected */
    get selected() {
        return this.search.selected === this;
    }
    /* click event listener */
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.search.select(this.value);
    }
    ngOnInit() {
    }
    /**
     * set active status
     */
    setActiveStyles() {
        this.active = true;
    }
    /**
     * set inactive status
     */
    setInactiveStyles() {
        this.active = false;
    }
}
SearchOptionComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-search-option',
                template: "<div class=\"search-option-container\">\r\n    <ng-content></ng-content>\r\n</div>\r\n",
                styles: [".options-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.option-item-active{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.option-item-active{background-color:#f3f3f3}}.search-option-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.search-option-container.active,.search-option-container:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.search-option-container.active,.search-option-container:hover{background-color:#f3f3f3}}"]
            },] }
];
SearchOptionComponent.ctorParameters = () => [
    { type: SearchService }
];
SearchOptionComponent.propDecorators = {
    value: [{ type: Input }],
    selected: [{ type: HostBinding, args: ['class.selected',] }],
    active: [{ type: HostBinding, args: ['class.active',] }],
    onClick: [{ type: HostListener, args: ['click', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VhcmNoLW9wdGlvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL0NvbXBvbmVudHMvTW9sZWN1bGVzL3NlYXJjaC9zZWFyY2gtb3B0aW9uL3NlYXJjaC1vcHRpb24uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQVMsTUFBTSxlQUFlLENBQUM7QUFFbEYsT0FBTyxFQUFDLGFBQWEsRUFBQyxNQUFNLG1CQUFtQixDQUFDO0FBT2hELE1BQU0sT0FBTyxxQkFBcUI7SUF3QmhDLFlBQ1UsY0FBNkI7UUFBN0IsbUJBQWMsR0FBZCxjQUFjLENBQWU7UUFidkMsdUJBQXVCO1FBRWhCLFdBQU0sR0FBRyxLQUFLLENBQUM7UUFhcEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ2hELENBQUM7SUF0QkQseUJBQXlCO0lBQ3pCLElBQ1csUUFBUTtRQUNqQixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLElBQUksQ0FBQztJQUN2QyxDQUFDO0lBTUQsMEJBQTBCO0lBRW5CLE9BQU8sQ0FBQyxLQUFjO1FBQzNCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN2QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFRRCxRQUFRO0lBQ1IsQ0FBQztJQUVEOztPQUVHO0lBQ0ksZUFBZTtRQUNwQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztJQUNyQixDQUFDO0lBRUQ7O09BRUc7SUFDSSxpQkFBaUI7UUFDdEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDdEIsQ0FBQzs7O1lBbERGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsbUJBQW1CO2dCQUM3QixrR0FBNkM7O2FBRTlDOzs7WUFOTyxhQUFhOzs7b0JBU2xCLEtBQUs7dUJBS0wsV0FBVyxTQUFDLGdCQUFnQjtxQkFNNUIsV0FBVyxTQUFDLGNBQWM7c0JBSTFCLFlBQVksU0FBQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0NvbXBvbmVudCwgSG9zdEJpbmRpbmcsIEhvc3RMaXN0ZW5lciwgSW5wdXQsIE9uSW5pdH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7U2VhcmNoQ29tcG9uZW50fSBmcm9tICcuLi9zZWFyY2guY29tcG9uZW50JztcclxuaW1wb3J0IHtTZWFyY2hTZXJ2aWNlfSBmcm9tICcuLi9zZWFyY2guc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3NwdC1zZWFyY2gtb3B0aW9uJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vc2VhcmNoLW9wdGlvbi5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vc2VhcmNoLW9wdGlvbi5jb21wb25lbnQubGVzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTZWFyY2hPcHRpb25Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG5cclxuICBASW5wdXQoKSB2YWx1ZTtcclxuXHJcbiAgcHJpdmF0ZSBzZWFyY2g6IFNlYXJjaENvbXBvbmVudDtcclxuXHJcbiAgLyogYmluZCBjbGFzcy5zZWxlY3RlZCAqL1xyXG4gIEBIb3N0QmluZGluZygnY2xhc3Muc2VsZWN0ZWQnKVxyXG4gIHB1YmxpYyBnZXQgc2VsZWN0ZWQoKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gdGhpcy5zZWFyY2guc2VsZWN0ZWQgPT09IHRoaXM7XHJcbiAgfVxyXG5cclxuICAvKiBiaW5kIGNsYXNzLmFjdGl2ZSAqL1xyXG4gIEBIb3N0QmluZGluZygnY2xhc3MuYWN0aXZlJylcclxuICBwdWJsaWMgYWN0aXZlID0gZmFsc2U7XHJcblxyXG4gIC8qIGNsaWNrIGV2ZW50IGxpc3RlbmVyICovXHJcbiAgQEhvc3RMaXN0ZW5lcignY2xpY2snLCBbJyRldmVudCddKVxyXG4gIHB1YmxpYyBvbkNsaWNrKGV2ZW50OiBVSUV2ZW50KSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB0aGlzLnNlYXJjaC5zZWxlY3QodGhpcy52YWx1ZSk7XHJcbiAgfVxyXG5cclxuICBjb25zdHJ1Y3RvcihcclxuICAgIHByaXZhdGUgX3NlYXJjaFNlcnZpY2U6IFNlYXJjaFNlcnZpY2VcclxuICApIHtcclxuICAgIHRoaXMuc2VhcmNoID0gdGhpcy5fc2VhcmNoU2VydmljZS5nZXRTZWFyY2goKTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCkge1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogc2V0IGFjdGl2ZSBzdGF0dXNcclxuICAgKi9cclxuICBwdWJsaWMgc2V0QWN0aXZlU3R5bGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5hY3RpdmUgPSB0cnVlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogc2V0IGluYWN0aXZlIHN0YXR1c1xyXG4gICAqL1xyXG4gIHB1YmxpYyBzZXRJbmFjdGl2ZVN0eWxlcygpOiB2b2lkIHtcclxuICAgIHRoaXMuYWN0aXZlID0gZmFsc2U7XHJcbiAgfVxyXG59XHJcbiJdfQ==