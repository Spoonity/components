import { Component, Input } from '@angular/core';
export class SideNavigationComponent {
    constructor() {
        this.items = new Array();
    }
    ngOnInit() {
    }
}
SideNavigationComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-side-navigation',
                template: "<!-- Menu Item -->\r\n<ng-container *ngIf=\"type == 'menuItem'\">\r\n  <li nz-menu-item class=\"side-navigation-component\">\r\n    <span>\r\n      <svg-icon\r\n        *ngIf=\"icon\"\r\n        nz-icon\r\n        [svgStyle]=\"{ 'height.px': 20 }\"\r\n        [name]=\"icon\"\r\n      ></svg-icon\r\n    ></span>\r\n    <span class=\"text\">{{ text }}</span>\r\n  </li>\r\n</ng-container>\r\n\r\n<!-- Sub Menu -->\r\n<ng-container *ngIf=\"type == 'subMenu'\">\r\n  <li nzOpen nz-submenu>\r\n    <span title\r\n      ><span>\r\n        <svg-icon\r\n          *ngIf=\"icon\"\r\n          nz-icon\r\n          [svgStyle]=\"{ 'height.px': 20 }\"\r\n          [name]=\"icon\"\r\n        ></svg-icon></span\r\n      ><span>{{ text }}</span></span\r\n    >\r\n    <ul>\r\n      <ng-container *ngFor=\"let item of items\">\r\n        <li nz-menu-item>\r\n          <span>\r\n            <svg-icon\r\n              *ngIf=\"item.icon\"\r\n              nz-icon\r\n              [svgStyle]=\"{ 'height.px': 20 }\"\r\n              [name]=\"item.icon\"\r\n            ></svg-icon\r\n          ></span>\r\n          <span class=\"text\">{{ item.text }}</span>\r\n        </li>\r\n      </ng-container>\r\n    </ul>\r\n  </li>\r\n</ng-container>\r\n\r\n<!-- Menu -->\r\n<ng-container *ngIf=\"type == 'menu'\">\r\n  <ul nz-menu></ul>\r\n</ng-container>\r\n",
                styles: ["li[nz-menu-item] .text{font-size:16px;line-height:3px;font-weight:700;margin-left:34px}li[nz-menu-item]:hover{background-color:#f3f3f3;border-radius:0 28px 28px 0;cursor:pointer}li[nz-menu-item].active{background-color:#fff3e0}li[nz-menu-item].active svg-icon svg path{fill:#f90}.ant-menu-submenu-active{outline-style:none!important}svg-icon{transform:translateY(2px)}"]
            },] }
];
SideNavigationComponent.ctorParameters = () => [];
SideNavigationComponent.propDecorators = {
    icon: [{ type: Input }],
    text: [{ type: Input }],
    disabled: [{ type: Input }],
    items: [{ type: Input }],
    type: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2lkZS1uYXZpZ2F0aW9uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9Nb2xlY3VsZXMvc2lkZS1uYXZpZ2F0aW9uL3NpZGUtbmF2aWdhdGlvbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFRekQsTUFBTSxPQUFPLHVCQUF1QjtJQVFsQztRQUhTLFVBQUssR0FBRyxJQUFJLEtBQUssRUFBYSxDQUFDO0lBR3hCLENBQUM7SUFFakIsUUFBUTtJQUNSLENBQUM7OztZQWhCRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLHFCQUFxQjtnQkFDL0IseTBDQUErQzs7YUFFaEQ7Ozs7bUJBR0UsS0FBSzttQkFDTCxLQUFLO3VCQUNMLEtBQUs7b0JBQ0wsS0FBSzttQkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFNpZGVOYXZpZ2F0aW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2VudW1zJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LXNpZGUtbmF2aWdhdGlvbicsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3NpZGUtbmF2aWdhdGlvbi5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vc2lkZS1uYXZpZ2F0aW9uLmNvbXBvbmVudC5sZXNzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIFNpZGVOYXZpZ2F0aW9uQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgQElucHV0KCkgaWNvbjogc3RyaW5nO1xyXG4gIEBJbnB1dCgpIHRleHQ6IHN0cmluZztcclxuICBASW5wdXQoKSBkaXNhYmxlZDogYm9vbGVhbjtcclxuICBASW5wdXQoKSBpdGVtcyA9IG5ldyBBcnJheTxNZW51SXRlbXM+KCk7XHJcbiAgQElucHV0KCkgdHlwZTogU2lkZU5hdmlnYXRpb25UeXBlO1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHsgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIE1lbnVJdGVtcyB7XHJcbiAgaWNvbjogc3RyaW5nLFxyXG4gIHRleHQ6IHN0cmluZyxcclxuICBsaW5rOiBzdHJpbmdcclxufVxyXG4iXX0=