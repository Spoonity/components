import { Component, Input } from '@angular/core';
export class BreadcrumbComponent {
    constructor() { }
    ngOnInit() {
    }
}
BreadcrumbComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-breadcrumb',
                template: "<nz-breadcrumb [nzSeparator]=\"'>'\">\r\n    <ng-container *ngFor=\"let item of items\">\r\n        <nz-breadcrumb-item>\r\n            <a *ngIf=\"item.route\" [routerLink]=\"item.route\">{{item.label}}</a>\r\n            <span *ngIf=\"!item.route\">{{item.label}}</span>\r\n        </nz-breadcrumb-item>\r\n    </ng-container>\r\n</nz-breadcrumb>",
                styles: [""]
            },] }
];
BreadcrumbComponent.ctorParameters = () => [];
BreadcrumbComponent.propDecorators = {
    items: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnJlYWRjcnVtYi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL0NvbXBvbmVudHMvTW9sZWN1bGVzL2JyZWFkY3J1bWIvYnJlYWRjcnVtYi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFPekQsTUFBTSxPQUFPLG1CQUFtQjtJQUU5QixnQkFBZ0IsQ0FBQztJQUlqQixRQUFRO0lBQ1IsQ0FBQzs7O1lBWkYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxnQkFBZ0I7Z0JBQzFCLHVXQUEwQzs7YUFFM0M7Ozs7b0JBS0UsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdzcHQtYnJlYWRjcnVtYicsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2JyZWFkY3J1bWIuY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL2JyZWFkY3J1bWIuY29tcG9uZW50Lmxlc3MnXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQnJlYWRjcnVtYkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIEBJbnB1dCgpIGl0ZW1zOiB7IGxhYmVsOiBzdHJpbmcsIHJvdXRlOiBzdHJpbmcgfVtdO1xyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICB9XHJcblxyXG5cclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJQnJlYWRDcnVtYkl0ZW0ge1xyXG4gIGxhYmVsOiBzdHJpbmc7XHJcbiAgcm91dGU6IHN0cmluZztcclxufVxyXG4iXX0=