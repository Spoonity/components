import { Component, HostBinding, HostListener, Input } from '@angular/core';
import { DropdownService } from '../dropdown.service';
export class OptionComponent {
    constructor(_dropdownService) {
        this._dropdownService = _dropdownService;
        /* bind class.active */
        this.active = false;
        this.select = this._dropdownService.getSelect();
    }
    /* bind class.selected */
    get selected() {
        return this.select.single_selectedOption === this;
    }
    /* click event listener */
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.select.selectOption(this);
    }
    ngOnInit() {
    }
    /**
     * get option label
     */
    getLabel() {
        return this.text;
    }
    /**
     * set active status
     */
    setActiveStyles() {
        this.active = true;
    }
    /**
     * set inactive status
     */
    setInactiveStyles() {
        this.active = false;
    }
    /**
     * select option item
     */
    selectItem() {
        this.select.selectOption(this);
    }
}
OptionComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-option',
                template: "<div class=\"option-container\">\r\n    <!--- multiple selection (include checkbox -->\r\n    <div *ngIf=\"select.selectMultiple\" nz-col nzSpan=\"8\">\r\n        <label nz-checkbox nzValue=\"{{value}}\" [(ngModel)]=\"checkboxModel\" (ngModelChange)=\"selectItem()\">{{text}}</label>\r\n    </div>\r\n\r\n    <!-- single selection -->\r\n    <div *ngIf=\"!select.selectMultiple\">{{text}}</div>\r\n</div>\r\n",
                styles: [".options-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.option-item-active{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.option-item-active{background-color:#f3f3f3}}:host{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}:host.active,:host.selected,:host:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){:host.active,:host.selected,:host:hover{background-color:#f3f3f3}}:host.selected{font-weight:700}:host.active,:host:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){:host.active,:host:hover{background-color:#f3f3f3}}:host.disabled{color:#93a1aa;cursor:auto}:host.disabled:focus,:host.disabled:hover{outline:none;background-color:#fff}@media screen and (-ms-high-contrast:active){:host.disabled:focus,:host.disabled:hover{background-color:#fff}}.option-container{display:flex}"]
            },] }
];
OptionComponent.ctorParameters = () => [
    { type: DropdownService }
];
OptionComponent.propDecorators = {
    value: [{ type: Input }],
    text: [{ type: Input }],
    selected: [{ type: HostBinding, args: ['class.selected',] }],
    active: [{ type: HostBinding, args: ['class.active',] }],
    onClick: [{ type: HostListener, args: ['click', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9Nb2xlY3VsZXMvZHJvcGRvd24vb3B0aW9uL29wdGlvbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFNBQVMsRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBUyxNQUFNLGVBQWUsQ0FBQztBQUNsRixPQUFPLEVBQUMsZUFBZSxFQUFDLE1BQU0scUJBQXFCLENBQUM7QUFRcEQsTUFBTSxPQUFPLGVBQWU7SUFtQzFCLFlBQ1UsZ0JBQWlDO1FBQWpDLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7UUF0QjNDLHVCQUF1QjtRQUVoQixXQUFNLEdBQUcsS0FBSyxDQUFDO1FBc0JwQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQUNsRCxDQUFDO0lBL0JELHlCQUF5QjtJQUN6QixJQUNXLFFBQVE7UUFDakIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLHFCQUFxQixLQUFLLElBQUksQ0FBQztJQUNwRCxDQUFDO0lBY0QsMEJBQTBCO0lBRW5CLE9BQU8sQ0FBQyxLQUFjO1FBQzNCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN2QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQVNELFFBQVE7SUFDUixDQUFDO0lBRUQ7O09BRUc7SUFDSSxRQUFRO1FBQ2IsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ25CLENBQUM7SUFFRDs7T0FFRztJQUNJLGVBQWU7UUFDcEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7SUFDckIsQ0FBQztJQUVEOztPQUVHO0lBQ0ksaUJBQWlCO1FBQ3RCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3RCLENBQUM7SUFFRDs7T0FFRztJQUNJLFVBQVU7UUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNqQyxDQUFDOzs7WUEzRUYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxZQUFZO2dCQUN0QixvYUFBc0M7O2FBRXZDOzs7WUFQTyxlQUFlOzs7b0JBV3BCLEtBQUs7bUJBR0wsS0FBSzt1QkFHTCxXQUFXLFNBQUMsZ0JBQWdCO3FCQU01QixXQUFXLFNBQUMsY0FBYztzQkFZMUIsWUFBWSxTQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBIb3N0QmluZGluZywgSG9zdExpc3RlbmVyLCBJbnB1dCwgT25Jbml0fSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtEcm9wZG93blNlcnZpY2V9IGZyb20gJy4uL2Ryb3Bkb3duLnNlcnZpY2UnO1xyXG5pbXBvcnQge0Ryb3Bkb3duQ29tcG9uZW50fSBmcm9tICcuLi9kcm9wZG93bi5jb21wb25lbnQnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdzcHQtb3B0aW9uJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vb3B0aW9uLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9vcHRpb24uY29tcG9uZW50Lmxlc3MnXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgT3B0aW9uQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgLyogb3B0aW9uIHZhbHVlICovXHJcbiAgQElucHV0KCkgcHVibGljIHZhbHVlOiBhbnk7XHJcblxyXG4gIC8qIG9wdGlvbiBkaXNwbGF5IHRleHQgKi9cclxuICBASW5wdXQoKSBwdWJsaWMgdGV4dDogc3RyaW5nO1xyXG5cclxuICAvKiBiaW5kIGNsYXNzLnNlbGVjdGVkICovXHJcbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5zZWxlY3RlZCcpXHJcbiAgcHVibGljIGdldCBzZWxlY3RlZCgpOiBib29sZWFuIHtcclxuICAgIHJldHVybiB0aGlzLnNlbGVjdC5zaW5nbGVfc2VsZWN0ZWRPcHRpb24gPT09IHRoaXM7XHJcbiAgfVxyXG5cclxuICAvKiBiaW5kIGNsYXNzLmFjdGl2ZSAqL1xyXG4gIEBIb3N0QmluZGluZygnY2xhc3MuYWN0aXZlJylcclxuICBwdWJsaWMgYWN0aXZlID0gZmFsc2U7XHJcblxyXG5cclxuICAvKiBjaGVja2JveCBtb2RlbCAoZm9yIG11bHRpcGxlIHNlbGVjdGlvbnMpICovXHJcbiAgcHVibGljIGNoZWNrYm94TW9kZWw6IGJvb2xlYW47XHJcblxyXG4gIC8qIHBhcmVudCBjb21wb25lbnQgcmVmZXJlbmNlICovXHJcbiAgc2VsZWN0OiBEcm9wZG93bkNvbXBvbmVudDtcclxuXHJcblxyXG4gIC8qIGNsaWNrIGV2ZW50IGxpc3RlbmVyICovXHJcbiAgQEhvc3RMaXN0ZW5lcignY2xpY2snLCBbJyRldmVudCddKVxyXG4gIHB1YmxpYyBvbkNsaWNrKGV2ZW50OiBVSUV2ZW50KSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB0aGlzLnNlbGVjdC5zZWxlY3RPcHRpb24odGhpcyk7XHJcbiAgfVxyXG5cclxuXHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwcml2YXRlIF9kcm9wZG93blNlcnZpY2U6IERyb3Bkb3duU2VydmljZVxyXG4gICkge1xyXG4gICAgdGhpcy5zZWxlY3QgPSB0aGlzLl9kcm9wZG93blNlcnZpY2UuZ2V0U2VsZWN0KCk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGdldCBvcHRpb24gbGFiZWxcclxuICAgKi9cclxuICBwdWJsaWMgZ2V0TGFiZWwoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLnRleHQ7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBzZXQgYWN0aXZlIHN0YXR1c1xyXG4gICAqL1xyXG4gIHB1YmxpYyBzZXRBY3RpdmVTdHlsZXMoKTogdm9pZCB7XHJcbiAgICB0aGlzLmFjdGl2ZSA9IHRydWU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBzZXQgaW5hY3RpdmUgc3RhdHVzXHJcbiAgICovXHJcbiAgcHVibGljIHNldEluYWN0aXZlU3R5bGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5hY3RpdmUgPSBmYWxzZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHNlbGVjdCBvcHRpb24gaXRlbVxyXG4gICAqL1xyXG4gIHB1YmxpYyBzZWxlY3RJdGVtKCkge1xyXG4gICAgdGhpcy5zZWxlY3Quc2VsZWN0T3B0aW9uKHRoaXMpO1xyXG4gIH1cclxuXHJcbn1cclxuIl19