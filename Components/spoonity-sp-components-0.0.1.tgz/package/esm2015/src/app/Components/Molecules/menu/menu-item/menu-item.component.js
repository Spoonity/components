import { Component, HostBinding, HostListener, Input } from '@angular/core';
import { MenuService } from '../menu.service';
export class MenuItemComponent {
    constructor(_menuService) {
        this._menuService = _menuService;
        /* bind class.active */
        this.active = false;
        this.menu = this._menuService.getMenu();
    }
    /* click event listener */
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.checkboxModel = !this.checkboxModel;
        this.menu.selectMenuItem(this);
    }
    ngOnInit() {
        // verify input
        if (this.menu.multiple) {
            if (this.itemId == null) {
                throw new Error('spt-menu-item: missing attribute: itemId for multiple selection');
            }
        }
    }
    /**
     * set active status
     */
    setActiveStyles() {
        this.active = true;
    }
    /**
     * set inactive status
     */
    setInactiveStyles() {
        this.active = false;
    }
    /**
     * select menu item
     */
    selectItem() {
        this.menu.selectMenuItem(this);
    }
    /**
     * if multiple items can be selected
     */
    isMultiple() {
        return this.menu.multiple;
    }
}
MenuItemComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-menu-item',
                template: "<div class=\"menu-item\" [ngClass]=\"{'multiple-menu-item': isMultiple(), 'single-menu-item': !isMultiple(), 'selected-item': isMultiple() && checkboxModel}\">\r\n\r\n    <!---- start icon ---->\r\n    <div class=\"menu-icon\" *ngIf=\"!!startIcon\">\r\n        <svg-icon *ngIf=\"!!startIcon\" nz-icon [name]=\"startIcon\" [svgStyle]=\"{ 'width.px':20, 'height.px':20 }\"></svg-icon>\r\n    </div>\r\n\r\n    <!---- left checkbox (if there is no start icon) ---->\r\n    <div *ngIf=\"isMultiple() && !startIcon\">\r\n        <label nz-checkbox nzValue=\"{{checkboxModel}}\" [(ngModel)]=\"checkboxModel\" (ngModelChange)=\"selectItem()\"></label>\r\n    </div>\r\n\r\n    <!---- label ---->\r\n    <div [ngClass]=\"{'label': !!startIcon || isMultiple()}\"><ng-content></ng-content></div>\r\n\r\n    <!---- right checkbox (if there is a start icon) ---->\r\n    <div *ngIf=\"isMultiple() && !!startIcon\" class=\"right-checkbox\">\r\n        <label nz-checkbox nzValue=\"{{checkboxModel}}\" [(ngModel)]=\"checkboxModel\" (ngModelChange)=\"selectItem()\"></label>\r\n    </div>\r\n</div>\r\n",
                styles: [".options-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.option-item-active{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.option-item-active{background-color:#f3f3f3}}.menu-item{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.menu-item.selected,.menu-item:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.menu-item.selected,.menu-item:hover{background-color:#f3f3f3}}.menu-item.selected{font-weight:700}.menu-item.active,.menu-item:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.menu-item.active,.menu-item:hover{background-color:#f3f3f3}}.menu-item:active{background-color:#e2e2e2;outline:none}@media screen and (-ms-high-contrast:active){.menu-item:active{background-color:#e2e2e2}}.menu-item.multiple-menu-item:active{background-color:#ffe1b4!important}.menu-item.selected-item{background-color:#fff3e0}.menu-item.disabled{color:#93a1aa;cursor:auto}.menu-item.disabled:focus,.menu-item.disabled:hover{outline:none;background-color:#fff}@media screen and (-ms-high-contrast:active){.menu-item.disabled:focus,.menu-item.disabled:hover{background-color:#fff}}.menu-item .menu-icon svg path{fill:#706f6e}.menu-item .label{margin-left:10px}.menu-icon,.menu-item{display:flex;align-items:center}.right-checkbox{margin-left:auto}"]
            },] }
];
MenuItemComponent.ctorParameters = () => [
    { type: MenuService }
];
MenuItemComponent.propDecorators = {
    itemId: [{ type: Input }],
    startIcon: [{ type: Input }],
    preventClose: [{ type: Input }],
    checkboxModel: [{ type: Input }],
    active: [{ type: HostBinding, args: ['class.active',] }],
    onClick: [{ type: HostListener, args: ['click', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVudS1pdGVtLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9Nb2xlY3VsZXMvbWVudS9tZW51LWl0ZW0vbWVudS1pdGVtLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUMsU0FBUyxFQUFnQixXQUFXLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBaUIsTUFBTSxlQUFlLENBQUM7QUFFeEcsT0FBTyxFQUFDLFdBQVcsRUFBQyxNQUFNLGlCQUFpQixDQUFDO0FBUTVDLE1BQU0sT0FBTyxpQkFBaUI7SUE2QjVCLFlBQ1UsWUFBeUI7UUFBekIsaUJBQVksR0FBWixZQUFZLENBQWE7UUFqQm5DLHVCQUF1QjtRQUVoQixXQUFNLEdBQUcsS0FBSyxDQUFDO1FBaUJwQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDMUMsQ0FBQztJQWJELDBCQUEwQjtJQUVuQixPQUFPLENBQUMsS0FBYztRQUMzQixLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFRRCxRQUFRO1FBQ04sZUFBZTtRQUNmLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDdEIsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksRUFBRTtnQkFDdkIsTUFBTSxJQUFJLEtBQUssQ0FBQyxpRUFBaUUsQ0FBQyxDQUFDO2FBQ3BGO1NBQ0Y7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxlQUFlO1FBQ3BCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7T0FFRztJQUNJLGlCQUFpQjtRQUN0QixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBRUQ7O09BRUc7SUFDSSxVQUFVO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksVUFBVTtRQUNmLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDNUIsQ0FBQzs7O1lBM0VGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsZUFBZTtnQkFDekIsMmtDQUF5Qzs7YUFFMUM7OztZQVBPLFdBQVc7OztxQkFVaEIsS0FBSzt3QkFHTCxLQUFLOzJCQUdMLEtBQUs7NEJBR0wsS0FBSztxQkFHTCxXQUFXLFNBQUMsY0FBYztzQkFPMUIsWUFBWSxTQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBFdmVudEVtaXR0ZXIsIEhvc3RCaW5kaW5nLCBIb3N0TGlzdGVuZXIsIElucHV0LCBPbkluaXQsIE91dHB1dH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7TWVudUNvbXBvbmVudH0gZnJvbSAnLi4vbWVudS5jb21wb25lbnQnO1xyXG5pbXBvcnQge01lbnVTZXJ2aWNlfSBmcm9tICcuLi9tZW51LnNlcnZpY2UnO1xyXG5pbXBvcnQge2Vycm9yfSBmcm9tICd1dGlsJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LW1lbnUtaXRlbScsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL21lbnUtaXRlbS5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vbWVudS1pdGVtLmNvbXBvbmVudC5sZXNzJ11cclxufSlcclxuZXhwb3J0IGNsYXNzIE1lbnVJdGVtQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAvKiBpdGVtIGlkICovXHJcbiAgQElucHV0KCkgcHVibGljIGl0ZW1JZDogc3RyaW5nO1xyXG5cclxuICAvKiBzdGFydCBpY29uICovXHJcbiAgQElucHV0KCkgcHVibGljIHN0YXJ0SWNvbjogc3RyaW5nO1xyXG5cclxuICAvKiBwcmV2ZW50IGNsb3NpbmcgdGhlIG1lbnUgd2hlbiB0aGlzIGl0ZW0gaXMgY2xpY2tlZCAqL1xyXG4gIEBJbnB1dCgpIHB1YmxpYyBwcmV2ZW50Q2xvc2U6IGJvb2xlYW47XHJcblxyXG4gIC8qIGNoZWNrYm94IG1vZGVsIChmb3IgbXVsdGlwbGUgc2VsZWN0aW9ucykgKi9cclxuICBASW5wdXQoKSBwdWJsaWMgY2hlY2tib3hNb2RlbDogYm9vbGVhbjtcclxuXHJcbiAgLyogYmluZCBjbGFzcy5hY3RpdmUgKi9cclxuICBASG9zdEJpbmRpbmcoJ2NsYXNzLmFjdGl2ZScpXHJcbiAgcHVibGljIGFjdGl2ZSA9IGZhbHNlO1xyXG5cclxuICAvKiBwYXJlbnQgY29tcG9uZW50IHJlZmVyZW5jZSAqL1xyXG4gIHByaXZhdGUgbWVudTogTWVudUNvbXBvbmVudDtcclxuXHJcbiAgLyogY2xpY2sgZXZlbnQgbGlzdGVuZXIgKi9cclxuICBASG9zdExpc3RlbmVyKCdjbGljaycsIFsnJGV2ZW50J10pXHJcbiAgcHVibGljIG9uQ2xpY2soZXZlbnQ6IFVJRXZlbnQpIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIHRoaXMuY2hlY2tib3hNb2RlbCA9ICF0aGlzLmNoZWNrYm94TW9kZWw7XHJcbiAgICB0aGlzLm1lbnUuc2VsZWN0TWVudUl0ZW0odGhpcyk7XHJcbiAgfVxyXG5cclxuICBjb25zdHJ1Y3RvcihcclxuICAgIHByaXZhdGUgX21lbnVTZXJ2aWNlOiBNZW51U2VydmljZVxyXG4gICkge1xyXG4gICAgdGhpcy5tZW51ID0gdGhpcy5fbWVudVNlcnZpY2UuZ2V0TWVudSgpO1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICAvLyB2ZXJpZnkgaW5wdXRcclxuICAgIGlmICh0aGlzLm1lbnUubXVsdGlwbGUpIHtcclxuICAgICAgaWYgKHRoaXMuaXRlbUlkID09IG51bGwpIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3NwdC1tZW51LWl0ZW06IG1pc3NpbmcgYXR0cmlidXRlOiBpdGVtSWQgZm9yIG11bHRpcGxlIHNlbGVjdGlvbicpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBzZXQgYWN0aXZlIHN0YXR1c1xyXG4gICAqL1xyXG4gIHB1YmxpYyBzZXRBY3RpdmVTdHlsZXMoKTogdm9pZCB7XHJcbiAgICB0aGlzLmFjdGl2ZSA9IHRydWU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBzZXQgaW5hY3RpdmUgc3RhdHVzXHJcbiAgICovXHJcbiAgcHVibGljIHNldEluYWN0aXZlU3R5bGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5hY3RpdmUgPSBmYWxzZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHNlbGVjdCBtZW51IGl0ZW1cclxuICAgKi9cclxuICBwdWJsaWMgc2VsZWN0SXRlbSgpIHtcclxuICAgIHRoaXMubWVudS5zZWxlY3RNZW51SXRlbSh0aGlzKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGlmIG11bHRpcGxlIGl0ZW1zIGNhbiBiZSBzZWxlY3RlZFxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc011bHRpcGxlKCk6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIHRoaXMubWVudS5tdWx0aXBsZTtcclxuICB9XHJcbn1cclxuIl19