import { Component, ContentChildren, EventEmitter, forwardRef, Input, Output, ViewChild } from '@angular/core';
import { FormFieldManager } from '../../shared/form-field.manager';
import { OverlayTemplateComponent } from '../../shared/overlay-template/overlay-template.component';
import { SearchService } from './search.service';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { SearchOptionComponent } from './search-option/search-option.component';
export class SearchComponent extends FormFieldManager {
    constructor(_searchService) {
        super();
        this._searchService = _searchService;
        /* selected items (chips) */
        this.selectedItems = [];
        /* filter action */
        this.filter = new EventEmitter();
        /* item selected action */
        this.itemSelected = new EventEmitter();
        /* item removed action */
        this.itemRemoved = new EventEmitter();
        this._searchService.register(this);
    }
    ngAfterViewInit() {
    }
    /**
     * override: on change action
     */
    changeAction($event) {
        this.onChange($event);
        this.checkDirty();
        if (this.value.length > 0) {
            if (!this.search.showing) {
                this.showDropdown();
            }
            this.filterAction();
        }
        else {
            this.hideDropdown();
        }
    }
    /**
     * show options action
     */
    showDropdown() {
        this.search.show();
    }
    /**
     * hide dropdown action
     */
    hideDropdown() {
        this.search.hide();
    }
    /**
     * keydown event
     */
    onKeyDown(event) {
        if (event.key === 'Escape' || event.key === 'Esc') {
            if (this.search.showing) {
                this.hideDropdown();
            }
        }
    }
    /**
     * on select item
     */
    select(selection) {
        this.itemSelected.emit(selection);
        this.hideDropdown();
    }
    /**
     * on filter action
     */
    filterAction() {
        this.filter.emit();
    }
    /**
     * on close item
     */
    onClose(selection) {
        this.itemRemoved.emit(selection);
    }
}
SearchComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-search',
                template: "<div #searchReference class=\"spt-input-container search-container\" [ngClass]=\"{'disabled-container': isDisabled}\">\r\n    <div class=\"search-wrapper {{size}} \" [ngClass]=\"{'item-focus': focus}\">\r\n        <!-- search icon -->\r\n        <div class=\"search-icon left-icon\">\r\n            <svg-icon name=\"search\" [svgStyle]=\"{ 'width.px':24 }\"></svg-icon>\r\n        </div>\r\n\r\n        <!-- selected items (chips) -->\r\n        <div class=\"selected-items spt-spacing-x--1\" *ngIf=\"selectedItems.length\">\r\n            <div class=\"selected-item\" *ngFor=\"let s of selectedItems\">\r\n                <spt-chip [text]=\"s.text\"\r\n                         [icon]=\"s.icon\" mode=\"closeable\"\r\n                         (onCloseEvent)=\"onClose(s)\"></spt-chip>\r\n            </div>\r\n        </div>\r\n        <input #input *ngIf=\"maximumSelection ? selectedItems.length <= maximumSelection : true\"\r\n               (focus)=\"focus=true\" (blur)=\"focus=false\"\r\n               [ngClass]=\"{'dirty': isDirty, 'error': !!error, 'disabled-state': isDisabled}\"\r\n               [(ngModel)]=\"value\"\r\n               (ngModelChange)=\"changeAction($event)\"\r\n               (keydown)=\"onKeyDown($event)\"\r\n               placeholder=\"{{placeholder}}\" autocomplete=\"off\">\r\n    </div>\r\n\r\n    <spt-overlay-template [reference]=\"searchReference\" #searchComp>\r\n        <div class=\"search-options-container spt-elevation--5\">\r\n            <ng-content select=\"spt-search-option\"></ng-content>\r\n        </div>\r\n    </spt-overlay-template>\r\n\r\n</div>\r\n\r\n\r\n",
                providers: [
                    SearchService,
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => SearchComponent),
                        multi: true
                    }
                ],
                styles: [".spt-input-container input::-moz-placeholder{visibility:visible!important}.spt-input-container input::placeholder{visibility:visible!important}.search-options-container{width:100%;max-height:200px;overflow:auto}", ".form-field{color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.form-field.large{padding:12px 10px}.form-field.large+label{top:12px}.form-field.medium{padding:8px 10px}.form-field.medium+label{top:8px}.form-field.small{padding:6px 10px}.form-field.small+label{top:6px}.form-field.error,.form-field.has-right-icon{padding-right:45px}.form-field.error{border:1px solid #ef5350!important}.form-field.error~label{color:#ef5350!important}.form-field.error:focus,.form-field.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.form-field.has-left-icon{padding-left:45px}.form-field.has-left-icon+label{left:45px}.form-field:hover{border:1px solid #000!important}.form-field.item-focus,.form-field:focus{border:1px solid #f90!important;caret-color:#f90}.form-field.item-focus+label,.form-field:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.text-field-container input::-moz-placeholder{visibility:hidden;opacity:0;-moz-transition:visibility .1s ease-out,opacity .1s ease-out;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input::placeholder{visibility:hidden;opacity:0;transition:visibility .1s ease-out,opacity .1s ease-out;padding:0 4px}.text-field-container input:focus::-moz-placeholder{visibility:visible;opacity:1}.text-field-container input:focus::placeholder{visibility:visible;opacity:1}.spt-input-container{margin:0;position:relative}.spt-input-container input{box-shadow:none;outline:none;min-height:24px;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.spt-input-container input.large{padding:12px 10px}.spt-input-container input.large+label{top:12px}.spt-input-container input.medium{padding:8px 10px}.spt-input-container input.medium+label{top:8px}.spt-input-container input.small{padding:6px 10px}.spt-input-container input.small+label{top:6px}.spt-input-container input.error,.spt-input-container input.has-right-icon{padding-right:45px}.spt-input-container input.error{border:1px solid #ef5350!important}.spt-input-container input.error~label{color:#ef5350!important}.spt-input-container input.error:focus,.spt-input-container input.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.spt-input-container input.has-left-icon{padding-left:45px}.spt-input-container input.has-left-icon+label{left:45px}.spt-input-container input:hover{border:1px solid #000!important}.spt-input-container input.item-focus,.spt-input-container input:focus{border:1px solid #f90!important;caret-color:#f90}.spt-input-container input.item-focus+label,.spt-input-container input:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input[disabled]{background-color:#fff!important;color:#b1b1b1!important;border:1px solid #b1b1b1!important;cursor:not-allowed}.spt-input-container input[disabled]~label{color:#b1b1b1!important}.spt-input-container input[disabled]:hover{border:1px solid #b1b1b1!important}.spt-input-container input.dirty+label{color:#909090}.spt-input-container input.dirty:hover+label{color:#000}.spt-input-container input.dirty:focus+label{color:#f90}.spt-input-container input.dirty+label{font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.spt-input-container input+label{position:absolute;left:12px;font-size:14px;color:#909090;background-color:hsla(0,0%,100%,0);pointer-events:none;transition:all .2s ease,background-color .2s ease-in}.spt-input-container .text-field-icon{position:absolute;height:24px;top:50%;transform:translateY(-50%)}.spt-input-container .error-icon,.spt-input-container .right-icon{right:12px}.spt-input-container .left-icon{left:12px}.spt-input-container .left-icon svg path,.spt-input-container .right-icon svg path{fill:#706f6e}.spt-input-container .error-icon svg path{fill:#ef5350}.spt-input-container label.text-field-bottom-label{font-size:12px;margin-top:10px;position:absolute;bottom:-20px}.spt-input-container label.error-label,.spt-input-container label.hint-label{left:12px}.spt-input-container label.length-label{right:12px}.spt-input-container label.error-label{color:#ef5350}.spt-input-container label.hint-label,.spt-input-container label.length-label{color:#4f4e4d}.spt-input-container.disabled-container .text-field-bottom-label{color:#b1b1b1!important}.spt-input-container.disabled-container .text-field-icon svg path{fill:#b1b1b1}.search-wrapper{display:flex;align-items:center;color:#0d0c0b;font-size:14px;height:inherit;width:100%;border-radius:4px;border:1px solid #909090!important}.search-wrapper.large{padding:12px 10px}.search-wrapper.large+label{top:12px}.search-wrapper.medium{padding:8px 10px}.search-wrapper.medium+label{top:8px}.search-wrapper.small{padding:6px 10px}.search-wrapper.small+label{top:6px}.search-wrapper.error,.search-wrapper.has-right-icon{padding-right:45px}.search-wrapper.error{border:1px solid #ef5350!important}.search-wrapper.error~label{color:#ef5350!important}.search-wrapper.error:focus,.search-wrapper.error:hover{border:1px solid #ef5350!important;caret-color:#ef5350}.search-wrapper.has-left-icon{padding-left:45px}.search-wrapper.has-left-icon+label{left:45px}.search-wrapper:hover{border:1px solid #000!important}.search-wrapper.item-focus,.search-wrapper:focus{border:1px solid #f90!important;caret-color:#f90}.search-wrapper.item-focus+label,.search-wrapper:focus+label{color:#f90;font-size:11px;top:-8px;left:8px;padding:0 4px;background-color:#fff}.search-wrapper input,.search-wrapper input:focus,.search-wrapper input:hover{border:none!important}.search-wrapper .search-icon{height:24px}.search-wrapper.large .search-icon,.search-wrapper.medium .search-icon{margin-left:10px;margin-right:10px}.search-wrapper.small{padding:4px 10px}.search-wrapper.small .search-icon{margin-left:10px;margin-right:10px}.search-wrapper .selected-items{display:flex;flex-wrap:wrap}.search-wrapper .selected-items .selected-item{margin:1px}"]
            },] }
];
SearchComponent.ctorParameters = () => [
    { type: SearchService }
];
SearchComponent.propDecorators = {
    placeholder: [{ type: Input }],
    selectedItems: [{ type: Input }],
    maximumSelection: [{ type: Input }],
    filter: [{ type: Output }],
    itemSelected: [{ type: Output }],
    itemRemoved: [{ type: Output }],
    search: [{ type: ViewChild, args: [OverlayTemplateComponent,] }],
    options: [{ type: ContentChildren, args: [SearchOptionComponent,] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VhcmNoLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9Nb2xlY3VsZXMvc2VhcmNoL3NlYXJjaC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLFNBQVMsRUFBRSxlQUFlLEVBQzFCLFlBQVksRUFDWixVQUFVLEVBQ1YsS0FBSyxFQUNMLE1BQU0sRUFFTixTQUFTLEVBQ1YsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFDLGdCQUFnQixFQUFDLE1BQU0saUNBQWlDLENBQUM7QUFDakUsT0FBTyxFQUFDLHdCQUF3QixFQUFDLE1BQU0sMERBQTBELENBQUM7QUFDbEcsT0FBTyxFQUFDLGFBQWEsRUFBQyxNQUFNLGtCQUFrQixDQUFDO0FBQy9DLE9BQU8sRUFBQyxpQkFBaUIsRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQ2pELE9BQU8sRUFBQyxxQkFBcUIsRUFBQyxNQUFNLHlDQUF5QyxDQUFDO0FBZ0I5RSxNQUFNLE9BQU8sZUFBZ0IsU0FBUSxnQkFBZ0I7SUFvQ25ELFlBQ1UsY0FBNkI7UUFFckMsS0FBSyxFQUFFLENBQUM7UUFGQSxtQkFBYyxHQUFkLGNBQWMsQ0FBZTtRQWhDdkMsNEJBQTRCO1FBQ25CLGtCQUFhLEdBQStDLEVBQUUsQ0FBQztRQUt4RSxtQkFBbUI7UUFDVCxXQUFNLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFFekQsMEJBQTBCO1FBQ2hCLGlCQUFZLEdBQXNCLElBQUksWUFBWSxFQUFPLENBQUM7UUFFcEUseUJBQXlCO1FBQ2YsZ0JBQVcsR0FBc0IsSUFBSSxZQUFZLEVBQU8sQ0FBQztRQXNCakUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVELGVBQWU7SUFDZixDQUFDO0lBRUQ7O09BRUc7SUFDSCxZQUFZLENBQUMsTUFBTTtRQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUVsQixJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ3hCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUNyQjtZQUNELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUNyQjthQUFNO1lBQ0wsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ3JCO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ksWUFBWTtRQUNqQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7T0FFRztJQUNJLFlBQVk7UUFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQ7O09BRUc7SUFDSSxTQUFTLENBQUMsS0FBb0I7UUFDbkMsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLEtBQUssRUFBRTtZQUNqRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO2dCQUN2QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDckI7U0FDRjtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNJLE1BQU0sQ0FBQyxTQUFjO1FBQzFCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQ7O09BRUc7SUFDSSxZQUFZO1FBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVEOztPQUVHO0lBQ0ksT0FBTyxDQUFDLFNBQWM7UUFDM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDbkMsQ0FBQzs7O1lBekhGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsWUFBWTtnQkFDdEIsNmxEQUFzQztnQkFFdEMsU0FBUyxFQUFFO29CQUNULGFBQWE7b0JBQ2I7d0JBQ0UsT0FBTyxFQUFFLGlCQUFpQjt3QkFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxlQUFlLENBQUM7d0JBQzlDLEtBQUssRUFBRSxJQUFJO3FCQUNaO2lCQUNGOzthQUNGOzs7WUFqQk8sYUFBYTs7OzBCQXFCbEIsS0FBSzs0QkFHTCxLQUFLOytCQUdMLEtBQUs7cUJBR0wsTUFBTTsyQkFHTixNQUFNOzBCQUdOLE1BQU07cUJBR04sU0FBUyxTQUFDLHdCQUF3QjtzQkFJbEMsZUFBZSxTQUFDLHFCQUFxQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgQWZ0ZXJWaWV3SW5pdCxcclxuICBDb21wb25lbnQsIENvbnRlbnRDaGlsZHJlbixcclxuICBFdmVudEVtaXR0ZXIsXHJcbiAgZm9yd2FyZFJlZixcclxuICBJbnB1dCxcclxuICBPdXRwdXQsXHJcbiAgUXVlcnlMaXN0LFxyXG4gIFZpZXdDaGlsZFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0Zvcm1GaWVsZE1hbmFnZXJ9IGZyb20gJy4uLy4uL3NoYXJlZC9mb3JtLWZpZWxkLm1hbmFnZXInO1xyXG5pbXBvcnQge092ZXJsYXlUZW1wbGF0ZUNvbXBvbmVudH0gZnJvbSAnLi4vLi4vc2hhcmVkL292ZXJsYXktdGVtcGxhdGUvb3ZlcmxheS10ZW1wbGF0ZS5jb21wb25lbnQnO1xyXG5pbXBvcnQge1NlYXJjaFNlcnZpY2V9IGZyb20gJy4vc2VhcmNoLnNlcnZpY2UnO1xyXG5pbXBvcnQge05HX1ZBTFVFX0FDQ0VTU09SfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7U2VhcmNoT3B0aW9uQ29tcG9uZW50fSBmcm9tICcuL3NlYXJjaC1vcHRpb24vc2VhcmNoLW9wdGlvbi5jb21wb25lbnQnO1xyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnc3B0LXNlYXJjaCcsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3NlYXJjaC5jb21wb25lbnQuaHRtbCcsXHJcbiAgc3R5bGVVcmxzOiBbJy4vc2VhcmNoLmNvbXBvbmVudC5sZXNzJywgJy4uLy4uL3NoYXJlZC9mb3JtLWZpZWxkLm1hbmFnZXIubGVzcyddLFxyXG4gIHByb3ZpZGVyczogW1xyXG4gICAgU2VhcmNoU2VydmljZSxcclxuICAgIHtcclxuICAgICAgcHJvdmlkZTogTkdfVkFMVUVfQUNDRVNTT1IsXHJcbiAgICAgIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IFNlYXJjaENvbXBvbmVudCksXHJcbiAgICAgIG11bHRpOiB0cnVlXHJcbiAgICB9XHJcbiAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgU2VhcmNoQ29tcG9uZW50IGV4dGVuZHMgRm9ybUZpZWxkTWFuYWdlciBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xyXG5cclxuICAvKiBQbGFjZWhvbGRlciB0ZXh0ICovXHJcbiAgQElucHV0KCkgcGxhY2Vob2xkZXI7XHJcblxyXG4gIC8qIHNlbGVjdGVkIGl0ZW1zIChjaGlwcykgKi9cclxuICBASW5wdXQoKSBzZWxlY3RlZEl0ZW1zOiB7aWQ6IHN0cmluZzsgaWNvbjogc3RyaW5nOyB0ZXh0OiBzdHJpbmd9W10gPSBbXTtcclxuXHJcbiAgLyogb3B0aW9uYWwgbWF4aW11bSBzZWxlY3RlZCBpdGVtcyAqL1xyXG4gIEBJbnB1dCgpIG1heGltdW1TZWxlY3Rpb24/OiBudW1iZXI7XHJcblxyXG4gIC8qIGZpbHRlciBhY3Rpb24gKi9cclxuICBAT3V0cHV0KCkgZmlsdGVyOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgLyogaXRlbSBzZWxlY3RlZCBhY3Rpb24gKi9cclxuICBAT3V0cHV0KCkgaXRlbVNlbGVjdGVkOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG5cclxuICAvKiBpdGVtIHJlbW92ZWQgYWN0aW9uICovXHJcbiAgQE91dHB1dCgpIGl0ZW1SZW1vdmVkOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG5cclxuICAvKiBvdmVybGF5IHRlbXBsYXRlIGNvbXBvbmVudCAqL1xyXG4gIEBWaWV3Q2hpbGQoT3ZlcmxheVRlbXBsYXRlQ29tcG9uZW50KVxyXG4gIHB1YmxpYyBzZWFyY2g6IE92ZXJsYXlUZW1wbGF0ZUNvbXBvbmVudDtcclxuXHJcbiAgLyogY2hpbGRyZW4gY29tcG9uZW50IGZvciBvcHRpb25zICovXHJcbiAgQENvbnRlbnRDaGlsZHJlbihTZWFyY2hPcHRpb25Db21wb25lbnQpXHJcbiAgcHVibGljIG9wdGlvbnM6IFF1ZXJ5TGlzdDxTZWFyY2hPcHRpb25Db21wb25lbnQ+O1xyXG5cclxuXHJcbiAgLyogc2VsZWN0ZWQgb3B0aW9uICovXHJcbiAgcHVibGljIHNlbGVjdGVkOiBTZWFyY2hPcHRpb25Db21wb25lbnQ7XHJcblxyXG4gIC8qIGZvY3VzIHN0YXRlICovXHJcbiAgZm9jdXM6IGJvb2xlYW47XHJcblxyXG5cclxuICBjb25zdHJ1Y3RvcihcclxuICAgIHByaXZhdGUgX3NlYXJjaFNlcnZpY2U6IFNlYXJjaFNlcnZpY2VcclxuICApIHtcclxuICAgIHN1cGVyKCk7XHJcbiAgICB0aGlzLl9zZWFyY2hTZXJ2aWNlLnJlZ2lzdGVyKHRoaXMpO1xyXG4gIH1cclxuXHJcbiAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogb3ZlcnJpZGU6IG9uIGNoYW5nZSBhY3Rpb25cclxuICAgKi9cclxuICBjaGFuZ2VBY3Rpb24oJGV2ZW50KTogdm9pZCB7XHJcbiAgICB0aGlzLm9uQ2hhbmdlKCRldmVudCk7XHJcbiAgICB0aGlzLmNoZWNrRGlydHkoKTtcclxuXHJcbiAgICBpZiAodGhpcy52YWx1ZS5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGlmICghdGhpcy5zZWFyY2guc2hvd2luZykge1xyXG4gICAgICAgIHRoaXMuc2hvd0Ryb3Bkb3duKCk7XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5maWx0ZXJBY3Rpb24oKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuaGlkZURyb3Bkb3duKCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBzaG93IG9wdGlvbnMgYWN0aW9uXHJcbiAgICovXHJcbiAgcHVibGljIHNob3dEcm9wZG93bigpOiB2b2lkIHtcclxuICAgIHRoaXMuc2VhcmNoLnNob3coKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGhpZGUgZHJvcGRvd24gYWN0aW9uXHJcbiAgICovXHJcbiAgcHVibGljIGhpZGVEcm9wZG93bigpOiB2b2lkIHtcclxuICAgIHRoaXMuc2VhcmNoLmhpZGUoKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGtleWRvd24gZXZlbnRcclxuICAgKi9cclxuICBwdWJsaWMgb25LZXlEb3duKGV2ZW50OiBLZXlib2FyZEV2ZW50KTogdm9pZCB7XHJcbiAgICBpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJyB8fCBldmVudC5rZXkgPT09ICdFc2MnKSB7XHJcbiAgICAgIGlmICh0aGlzLnNlYXJjaC5zaG93aW5nKSB7XHJcbiAgICAgICAgdGhpcy5oaWRlRHJvcGRvd24oKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogb24gc2VsZWN0IGl0ZW1cclxuICAgKi9cclxuICBwdWJsaWMgc2VsZWN0KHNlbGVjdGlvbjogYW55KTogdm9pZCB7XHJcbiAgICB0aGlzLml0ZW1TZWxlY3RlZC5lbWl0KHNlbGVjdGlvbik7XHJcbiAgICB0aGlzLmhpZGVEcm9wZG93bigpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogb24gZmlsdGVyIGFjdGlvblxyXG4gICAqL1xyXG4gIHB1YmxpYyBmaWx0ZXJBY3Rpb24oKTogdm9pZCB7XHJcbiAgICB0aGlzLmZpbHRlci5lbWl0KCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBvbiBjbG9zZSBpdGVtXHJcbiAgICovXHJcbiAgcHVibGljIG9uQ2xvc2Uoc2VsZWN0aW9uOiBhbnkpOiB2b2lkIHtcclxuICAgIHRoaXMuaXRlbVJlbW92ZWQuZW1pdChzZWxlY3Rpb24pO1xyXG4gIH1cclxufVxyXG4iXX0=