import { Component, EventEmitter, Input, Output } from '@angular/core';
export class StepsComponent {
    constructor() {
        this.type = 'navigation';
        this.direction = 'horizontal';
        this.onIndexChangeEvent = new EventEmitter();
    }
    ngOnInit() {
    }
    onIndexChange(event) {
        this.onIndexChangeEvent.emit(event);
    }
}
StepsComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-steps',
                template: "<nz-steps [nzCurrent]=\"current\" [nzType]=\"type\" (nzIndexChange)=\"onIndexChange($event)\" [nzDirection]=\"direction\">\r\n    <ng-container *ngFor=\"let step of steps\">\r\n        <nz-step [nzTitle]=\"step.title\" [nzDescription]=\"step.description\"></nz-step>\r\n    </ng-container>\r\n</nz-steps>\r\n",
                styles: ["nz-step .ant-steps-item-finish .ant-steps-item-icon{background-color:#fff;border-color:#4caf50!important}"]
            },] }
];
StepsComponent.ctorParameters = () => [];
StepsComponent.propDecorators = {
    current: [{ type: Input }],
    steps: [{ type: Input }],
    type: [{ type: Input }],
    direction: [{ type: Input }],
    onIndexChangeEvent: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RlcHMuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9Db21wb25lbnRzL01vbGVjdWxlcy9zdGVwcy9zdGVwcy5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFVLE1BQU0sRUFBRSxNQUFNLGVBQWUsQ0FBQztBQU8vRSxNQUFNLE9BQU8sY0FBYztJQUV6QjtRQUlTLFNBQUksR0FBWSxZQUFZLENBQUM7UUFDN0IsY0FBUyxHQUFZLFlBQVksQ0FBQztRQUNqQyx1QkFBa0IsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO0lBTjFDLENBQUM7SUFRZixRQUFRO0lBQ1IsQ0FBQztJQUVELGFBQWEsQ0FBQyxLQUFhO1FBQ3pCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdEMsQ0FBQzs7O1lBcEJKLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsV0FBVztnQkFDckIsZ1VBQXFDOzthQUV0Qzs7OztzQkFLRSxLQUFLO29CQUNMLEtBQUs7bUJBQ0wsS0FBSzt3QkFDTCxLQUFLO2lDQUNMLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3NwdC1zdGVwcycsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3N0ZXBzLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9zdGVwcy5jb21wb25lbnQubGVzcyddXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTdGVwc0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gIEBJbnB1dCgpIGN1cnJlbnQ6IG51bWJlcjtcclxuICBASW5wdXQoKSBzdGVwczogQXJyYXk8SVN0ZXBzPjtcclxuICBASW5wdXQoKSB0eXBlIDogc3RyaW5nID0gJ25hdmlnYXRpb24nO1xyXG4gIEBJbnB1dCgpIGRpcmVjdGlvbiA6IHN0cmluZyA9ICdob3Jpem9udGFsJztcclxuICBAT3V0cHV0KCkgb25JbmRleENoYW5nZUV2ZW50ID0gbmV3IEV2ZW50RW1pdHRlcjxudW1iZXI+KCk7XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICB9XHJcblxyXG4gICAgb25JbmRleENoYW5nZShldmVudDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgIHRoaXMub25JbmRleENoYW5nZUV2ZW50LmVtaXQoZXZlbnQpO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJU3RlcHMge1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgZGVzY3JpcHRpb246IHN0cmluZztcclxufVxyXG4iXX0=