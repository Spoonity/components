import { Directive, HostListener, Input } from '@angular/core';
export class MenuTriggerDirective {
    /* click event listener */
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.spMenuTrigger.toggleMenu();
    }
}
MenuTriggerDirective.decorators = [
    { type: Directive, args: [{
                selector: '[spMenuTrigger]'
            },] }
];
MenuTriggerDirective.propDecorators = {
    spMenuTrigger: [{ type: Input }],
    onClick: [{ type: HostListener, args: ['click', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVudS10cmlnZ2VyLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvQ29tcG9uZW50cy9Nb2xlY3VsZXMvbWVudS9tZW51LXRyaWdnZXIuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBQyxNQUFNLGVBQWUsQ0FBQztBQU03RCxNQUFNLE9BQU8sb0JBQW9CO0lBSy9CLDBCQUEwQjtJQUVuQixPQUFPLENBQUMsS0FBYztRQUMzQixLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDbEMsQ0FBQzs7O1lBZEYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxpQkFBaUI7YUFDNUI7Ozs0QkFJRSxLQUFLO3NCQUdMLFlBQVksU0FBQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0RpcmVjdGl2ZSwgSG9zdExpc3RlbmVyLCBJbnB1dH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7TWVudUNvbXBvbmVudH0gZnJvbSAnLi9tZW51LmNvbXBvbmVudCc7XHJcblxyXG5ARGlyZWN0aXZlKHtcclxuICBzZWxlY3RvcjogJ1tzcE1lbnVUcmlnZ2VyXSdcclxufSlcclxuZXhwb3J0IGNsYXNzIE1lbnVUcmlnZ2VyRGlyZWN0aXZlIHtcclxuXHJcbiAgLyogbWVudSBjb21wb25lbnQgdG8gbGF1bmNoICovXHJcbiAgQElucHV0KCkgc3BNZW51VHJpZ2dlcjogTWVudUNvbXBvbmVudDtcclxuXHJcbiAgLyogY2xpY2sgZXZlbnQgbGlzdGVuZXIgKi9cclxuICBASG9zdExpc3RlbmVyKCdjbGljaycsIFsnJGV2ZW50J10pXHJcbiAgcHVibGljIG9uQ2xpY2soZXZlbnQ6IFVJRXZlbnQpIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIHRoaXMuc3BNZW51VHJpZ2dlci50b2dnbGVNZW51KCk7XHJcbiAgfVxyXG59XHJcbiJdfQ==