import { Component, TemplateRef, ViewChild } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
export class SnackbarComponent {
    constructor(notification) {
        this.notification = notification;
    }
    ngOnInit() {
    }
    createSnackbar(snackbar) {
        this.notification.template(this.template, {
            nzStyle: {
                background: '#0D0C0B',
                color: 'white'
            },
            nzData: snackbar,
            nzPlacement: 'bottomLeft'
        });
    }
    onAction(callback) {
        callback();
    }
}
SnackbarComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-snackbar',
                template: "<ng-template #template let-snackbar=\"data\">\r\n    <div class=\"ant-notification-notice-content\">\r\n        <div>\r\n            <div class=\"ant-notification-notice-message\">\r\n                {{ snackbar.message }}\r\n            </div>\r\n            <div class=\"ant-notification-notice-description\">\r\n                {{ snackbar.description }}\r\n            </div>\r\n            <span class=\"ant-notification-notice-btn\">\r\n        <span *ngIf=\"snackbar.actionMessage\" (click)=\"onAction(snackbar.actionEvent)\">\r\n          {{ snackbar.actionMessage }}\r\n        </span>\r\n            </span>\r\n        </div>\r\n    </div>\r\n</ng-template>\r\n",
                styles: [".ant-notification-notice-content{background-color:#0d0c0b;color:#fff}.ant-notification-notice-btn,.ant-notification-notice-message{color:#fff}.ant-notification-notice-btn{float:left;margin-top:8px;cursor:pointer}"]
            },] }
];
SnackbarComponent.ctorParameters = () => [
    { type: NzNotificationService }
];
SnackbarComponent.propDecorators = {
    template: [{ type: ViewChild, args: [TemplateRef,] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic25hY2tiYXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9Db21wb25lbnRzL01vbGVjdWxlcy9zbmFja2Jhci9zbmFja2Jhci5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBUyxXQUFXLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pFLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBUW5FLE1BQU0sT0FBTyxpQkFBaUI7SUFJNUIsWUFBb0IsWUFBbUM7UUFBbkMsaUJBQVksR0FBWixZQUFZLENBQXVCO0lBQ3ZELENBQUM7SUFFRCxRQUFRO0lBQ1IsQ0FBQztJQUVELGNBQWMsQ0FBQyxRQUFtQjtRQUNoQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUyxFQUN2QztZQUNFLE9BQU8sRUFDUDtnQkFDRSxVQUFVLEVBQUUsU0FBUztnQkFDckIsS0FBSyxFQUFFLE9BQU87YUFDZjtZQUNELE1BQU0sRUFBRSxRQUFRO1lBQ2hCLFdBQVcsRUFBRSxZQUFZO1NBQzFCLENBQ0YsQ0FBQztJQUNKLENBQUM7SUFJRCxRQUFRLENBQUMsUUFBbUI7UUFDMUIsUUFBUSxFQUFFLENBQUM7SUFDYixDQUFDOzs7WUFsQ0YsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxjQUFjO2dCQUN4QiwycUJBQXdDOzthQUV6Qzs7O1lBTlEscUJBQXFCOzs7dUJBVTNCLFNBQVMsU0FBQyxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsVGVtcGxhdGVSZWYsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBOek5vdGlmaWNhdGlvblNlcnZpY2UgfSBmcm9tICduZy16b3Jyby1hbnRkL25vdGlmaWNhdGlvbic7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ3NwdC1zbmFja2JhcicsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3NuYWNrYmFyLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9zbmFja2Jhci5jb21wb25lbnQubGVzcyddXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgU25hY2tiYXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG5cclxuICBAVmlld0NoaWxkKFRlbXBsYXRlUmVmKSB0ZW1wbGF0ZT86IFRlbXBsYXRlUmVmPHt9PjtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBub3RpZmljYXRpb246IE56Tm90aWZpY2F0aW9uU2VydmljZSkge1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxuICBjcmVhdGVTbmFja2JhcihzbmFja2JhcjogSVNuYWNrYmFyKTogdm9pZCB7XHJcbiAgICB0aGlzLm5vdGlmaWNhdGlvbi50ZW1wbGF0ZSh0aGlzLnRlbXBsYXRlISxcclxuICAgICAge1xyXG4gICAgICAgIG56U3R5bGU6XHJcbiAgICAgICAge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogJyMwRDBDMEInLFxyXG4gICAgICAgICAgY29sb3I6ICd3aGl0ZSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIG56RGF0YTogc25hY2tiYXIsXHJcbiAgICAgICAgbnpQbGFjZW1lbnQ6ICdib3R0b21MZWZ0J1xyXG4gICAgICB9XHJcbiAgICApO1xyXG4gIH1cclxuXHJcblxyXG5cclxuICBvbkFjdGlvbihjYWxsYmFjazogKCkgPT4gYW55KSB7XHJcbiAgICBjYWxsYmFjaygpO1xyXG4gIH1cclxuXHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVNuYWNrYmFyIHtcclxuICBtZXNzYWdlOiBzdHJpbmc7XHJcbiAgZGVzY3JpcHRpb246IHN0cmluZztcclxuICBhY3Rpb25NZXNzYWdlOiBzdHJpbmc7XHJcbiAgYWN0aW9uRXZlbnQ6ICgpID0+IGFueTtcclxufVxyXG4iXX0=