import { Component, ContentChildren, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { OverlayTemplateComponent } from '../../shared/overlay-template/overlay-template.component';
import { MenuItemComponent } from './menu-item/menu-item.component';
import { MenuService } from './menu.service';
export class MenuComponent {
    constructor(_menuService) {
        this._menuService = _menuService;
        /* close menu when item is clicked */
        this.closeOnItemClick = true;
        /* toggle select all */
        this.toggleSelectAll = new EventEmitter();
        this.searchModelChange = new EventEmitter();
        /* selected items list (two-way binding) */
        this.selectedItems = [];
        this.selectedItemsChange = new EventEmitter();
        /* is the menu showing */
        this._menuShowing = false;
        this._menuService.register(this);
    }
    ngOnInit() {
    }
    /**
     * toggle show state of the menu items
     */
    toggleMenu() {
        this._menuShowing = !this.isShowing();
        if (this._menuShowing) {
            this.showMenu();
        }
        else {
            this.hideMenu();
        }
    }
    /**
     * show menu action
     */
    showMenu() {
        this.menu.show();
        if (this.search) {
            try {
                this.searchEl.nativeElement.focus();
            }
            catch (e) { }
        }
    }
    /**
     * hide menu action
     */
    hideMenu() {
        this.menu.hide();
        this.searchModel = '';
        this.searchModelChange.emit(this.searchModel);
    }
    /**
     * visibility state of the overlay template
     */
    isShowing() {
        return this.menu ? this.menu.showing : false;
    }
    /**
     * change model action
     */
    change() {
        this.searchModelChange.emit(this.searchModel);
    }
    /**
     * select menu item
     */
    selectMenuItem(item) {
        if (!this.selectedItems) {
            this.selectedItems = [];
        }
        this.selectedItem = item;
        if (!this.multiple) {
            if (this.closeOnItemClick) {
                this.hideMenu();
            }
        }
        else {
            if (item.checkboxModel) {
                if (!this.selectedItems.includes(item.itemId)) {
                    this.selectedItems.push(item.itemId);
                }
            }
            else {
                this.selectedItems = Array.from(this.selectedItems.filter((s) => s !== item.itemId));
                if (this.selectAllOption) {
                    this.selectAll = false;
                }
            }
            this.selectedItemsChange.emit(this.selectedItems);
        }
    }
    /**
     * keydown event (escape is pressed)
     */
    onKeyDown(event) {
        if (event.key === 'Escape' || event.key === 'Esc') {
            if (this.menu.showing) {
                this.hideMenu();
            }
        }
    }
    /**
     * toggle select all
     */
    toggleSelectAllAction(fromCheckbox) {
        if (!fromCheckbox) {
            this.selectAll = !this.selectAll;
        }
        this.toggleSelectAll.emit(this.selectAll);
    }
}
MenuComponent.decorators = [
    { type: Component, args: [{
                selector: 'spt-menu',
                template: "<div #menuReference class=\"menu-wrapper\" [ngClass]=\"{'show-menu': isShowing()}\">\r\n    <spt-overlay-template [reference]=\"menuReference\" #menuComp>\r\n        <div class=\"menu-container spt-elevation--5\">\r\n\r\n            <!---- search ---->\r\n            <div *ngIf=\"search\" class=\"search-container spt-spacing--1\">\r\n                <input #searchEl\r\n                       placeholder=\"Search\"\r\n                       [(ngModel)]=\"searchModel\"\r\n                       (ngModelChange)=\"change()\"\r\n                       (keydown)=\"onKeyDown($event)\"/>\r\n            </div>\r\n\r\n            <!---- select all ---->\r\n            <div *ngIf=\"multiple && selectAllOption\" class=\"menu-item spt-spacing--1 multiple-menu-item\" (click)=\"toggleSelectAllAction()\">\r\n                <div>\r\n                    <label nz-checkbox [(ngModel)]=\"selectAll\" (ngModelChange)=\"toggleSelectAllAction(true)\"></label>\r\n                </div>\r\n                <div class=\"label\">Select All</div>\r\n            </div>\r\n\r\n            <!-- options list -->\r\n            <ng-content select=\"spt-menu-item\"></ng-content>\r\n        </div>\r\n    </spt-overlay-template>\r\n</div>\r\n\r\n",
                providers: [MenuService],
                styles: [".options-container{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.option-item-active{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.option-item-active{background-color:#f3f3f3}}.menu-item{display:block;padding:0 .875rem;height:2.5rem;line-height:2.5rem;color:#4f4e4d;background-color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-user-select:none;-moz-user-select:none;user-select:none;cursor:pointer}.menu-item.selected,.menu-item:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.menu-item.selected,.menu-item:hover{background-color:#f3f3f3}}.menu-item.selected{font-weight:700}.menu-item.active,.menu-item:hover{background-color:#f3f3f3;outline:none}@media screen and (-ms-high-contrast:active){.menu-item.active,.menu-item:hover{background-color:#f3f3f3}}.menu-item:active{background-color:#e2e2e2;outline:none}@media screen and (-ms-high-contrast:active){.menu-item:active{background-color:#e2e2e2}}.menu-item.multiple-menu-item:active{background-color:#ffe1b4!important}.menu-item.selected-item{background-color:#fff3e0}.menu-item.disabled{color:#93a1aa;cursor:auto}.menu-item.disabled:focus,.menu-item.disabled:hover{outline:none;background-color:#fff}@media screen and (-ms-high-contrast:active){.menu-item.disabled:focus,.menu-item.disabled:hover{background-color:#fff}}.menu-item .menu-icon svg path{fill:#706f6e}.menu-item .label{margin-left:10px}.menu-icon,.menu-item{display:flex;align-items:center}.right-checkbox{margin-left:auto}.menu-wrapper{width:280px;visibility:hidden}.menu-container{width:100%;overflow:hidden}.search-container{background-color:#fff}.search-container input{padding:6px 10px;width:100%;color:#0d0c0b;border-radius:4px;border:1px solid #909090!important;outline:none}.search-container input:hover{border:1px solid #000!important}.search-container input.item-focus,.search-container input:focus{border:1px solid #f90!important;caret-color:#f90}.show-menu{visibility:visible}.select-all-container{display:flex;background-color:#fff}"]
            },] }
];
MenuComponent.ctorParameters = () => [
    { type: MenuService }
];
MenuComponent.propDecorators = {
    multiple: [{ type: Input }],
    closeOnItemClick: [{ type: Input }],
    search: [{ type: Input }],
    selectAllOption: [{ type: Input }],
    toggleSelectAll: [{ type: Output }],
    searchModel: [{ type: Input }],
    searchModelChange: [{ type: Output }],
    selectedItems: [{ type: Input }],
    selectedItemsChange: [{ type: Output }],
    searchEl: [{ type: ViewChild, args: ['searchEl',] }],
    menu: [{ type: ViewChild, args: [OverlayTemplateComponent,] }],
    menuItems: [{ type: ContentChildren, args: [MenuItemComponent,] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVudS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL0NvbXBvbmVudHMvTW9sZWN1bGVzL21lbnUvbWVudS5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNMLFNBQVMsRUFDVCxlQUFlLEVBRWYsWUFBWSxFQUNaLEtBQUssRUFFTCxNQUFNLEVBRU4sU0FBUyxFQUNWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBQyx3QkFBd0IsRUFBQyxNQUFNLDBEQUEwRCxDQUFDO0FBQ2xHLE9BQU8sRUFBQyxpQkFBaUIsRUFBQyxNQUFNLGlDQUFpQyxDQUFDO0FBQ2xFLE9BQU8sRUFBQyxXQUFXLEVBQUMsTUFBTSxnQkFBZ0IsQ0FBQztBQVEzQyxNQUFNLE9BQU8sYUFBYTtJQThDeEIsWUFDVSxZQUF5QjtRQUF6QixpQkFBWSxHQUFaLFlBQVksQ0FBYTtRQTNDbkMscUNBQXFDO1FBQzVCLHFCQUFnQixHQUFHLElBQUksQ0FBQztRQVFqQyx1QkFBdUI7UUFDYixvQkFBZSxHQUFzQixJQUFJLFlBQVksRUFBTyxDQUFDO1FBSTdELHNCQUFpQixHQUFzQixJQUFJLFlBQVksRUFBTyxDQUFDO1FBRXpFLDJDQUEyQztRQUNsQyxrQkFBYSxHQUFhLEVBQUUsQ0FBQztRQUM1Qix3QkFBbUIsR0FBc0IsSUFBSSxZQUFZLEVBQU8sQ0FBQztRQXFCM0UseUJBQXlCO1FBQ2pCLGlCQUFZLEdBQUcsS0FBSyxDQUFDO1FBSzNCLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCxRQUFRO0lBQ1IsQ0FBQztJQUVEOztPQUVHO0lBQ0ksVUFBVTtRQUNmLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDdEMsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3JCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNqQjthQUFNO1lBQ0wsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ2pCO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ksUUFBUTtRQUNiLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDakIsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2YsSUFBSTtnQkFDRixJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUNyQztZQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUU7U0FDZjtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNJLFFBQVE7UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFRDs7T0FFRztJQUNILFNBQVM7UUFDUCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7SUFDL0MsQ0FBQztJQUVEOztPQUVHO0lBQ0gsTUFBTTtRQUNKLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFRDs7T0FFRztJQUNJLGNBQWMsQ0FBQyxJQUF1QjtRQUMzQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUN2QixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztTQUN6QjtRQUVELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2xCLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUN6QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDakI7U0FDRjthQUFNO1lBQ0wsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO2dCQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUM3QyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ3RDO2FBQ0Y7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQzdGLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtvQkFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7aUJBQ3hCO2FBQ0Y7WUFDRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUNuRDtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNJLFNBQVMsQ0FBQyxLQUFvQjtRQUNuQyxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssS0FBSyxFQUFFO1lBQ2pELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ3JCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUNqQjtTQUNGO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0kscUJBQXFCLENBQUMsWUFBc0I7UUFDakQsSUFBSSxDQUFDLFlBQVksRUFBRTtZQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztTQUNsQztRQUNELElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUM1QyxDQUFDOzs7WUEzSkYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxVQUFVO2dCQUNwQix5dENBQW9DO2dCQUVwQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLENBQUM7O2FBQ3pCOzs7WUFQTyxXQUFXOzs7dUJBVWhCLEtBQUs7K0JBR0wsS0FBSztxQkFHTCxLQUFLOzhCQUdMLEtBQUs7OEJBR0wsTUFBTTswQkFHTixLQUFLO2dDQUNMLE1BQU07NEJBR04sS0FBSztrQ0FDTCxNQUFNO3VCQUdOLFNBQVMsU0FBQyxVQUFVO21CQUlwQixTQUFTLFNBQUMsd0JBQXdCO3dCQUlsQyxlQUFlLFNBQUMsaUJBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBDb21wb25lbnQsXHJcbiAgQ29udGVudENoaWxkcmVuLFxyXG4gIEVsZW1lbnRSZWYsXHJcbiAgRXZlbnRFbWl0dGVyLFxyXG4gIElucHV0LFxyXG4gIE9uSW5pdCxcclxuICBPdXRwdXQsXHJcbiAgUXVlcnlMaXN0LFxyXG4gIFZpZXdDaGlsZFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge092ZXJsYXlUZW1wbGF0ZUNvbXBvbmVudH0gZnJvbSAnLi4vLi4vc2hhcmVkL292ZXJsYXktdGVtcGxhdGUvb3ZlcmxheS10ZW1wbGF0ZS5jb21wb25lbnQnO1xyXG5pbXBvcnQge01lbnVJdGVtQ29tcG9uZW50fSBmcm9tICcuL21lbnUtaXRlbS9tZW51LWl0ZW0uY29tcG9uZW50JztcclxuaW1wb3J0IHtNZW51U2VydmljZX0gZnJvbSAnLi9tZW51LnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdzcHQtbWVudScsXHJcbiAgdGVtcGxhdGVVcmw6ICcuL21lbnUuY29tcG9uZW50Lmh0bWwnLFxyXG4gIHN0eWxlVXJsczogWycuL21lbnUuY29tcG9uZW50Lmxlc3MnXSxcclxuICBwcm92aWRlcnM6IFtNZW51U2VydmljZV1cclxufSlcclxuZXhwb3J0IGNsYXNzIE1lbnVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIC8qIGlmIG11bHRpcGxlIHNlbGVjdGlvbiAqKi9cclxuICBASW5wdXQoKSBtdWx0aXBsZTogYm9vbGVhbjtcclxuXHJcbiAgLyogY2xvc2UgbWVudSB3aGVuIGl0ZW0gaXMgY2xpY2tlZCAqL1xyXG4gIEBJbnB1dCgpIGNsb3NlT25JdGVtQ2xpY2sgPSB0cnVlO1xyXG5cclxuICAvKiBpbmNsdWRlIHNlYXJjaCBvbiB0aGUgaXRlbXMgKi9cclxuICBASW5wdXQoKSBzZWFyY2g6IGJvb2xlYW47XHJcblxyXG4gIC8qIGlmIGEgc2VsZWN0IGFsbCBpdGVtIGlzIGluY2x1ZGVkICoqL1xyXG4gIEBJbnB1dCgpIHNlbGVjdEFsbE9wdGlvbjogYm9vbGVhbjtcclxuXHJcbiAgLyogdG9nZ2xlIHNlbGVjdCBhbGwgKi9cclxuICBAT3V0cHV0KCkgdG9nZ2xlU2VsZWN0QWxsOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG5cclxuICAvKiBzZWFyY2hNb2RlbCAodHdvLXdheSBiaW5kaW5nKSAqL1xyXG4gIEBJbnB1dCgpIHNlYXJjaE1vZGVsOiBzdHJpbmc7XHJcbiAgQE91dHB1dCgpIHNlYXJjaE1vZGVsQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG5cclxuICAvKiBzZWxlY3RlZCBpdGVtcyBsaXN0ICh0d28td2F5IGJpbmRpbmcpICovXHJcbiAgQElucHV0KCkgc2VsZWN0ZWRJdGVtczogc3RyaW5nW10gPSBbXTtcclxuICBAT3V0cHV0KCkgc2VsZWN0ZWRJdGVtc0NoYW5nZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcclxuXHJcbiAgLyogc2VhcmNoIGlucHV0IGVsZW1lbnQgKi9cclxuICBAVmlld0NoaWxkKCdzZWFyY2hFbCcpXHJcbiAgcHVibGljIHNlYXJjaEVsOiBFbGVtZW50UmVmO1xyXG5cclxuICAvKiBvdmVybGF5IHRlbXBsYXRlIGNvbXBvbmVudCAqL1xyXG4gIEBWaWV3Q2hpbGQoT3ZlcmxheVRlbXBsYXRlQ29tcG9uZW50KVxyXG4gIHB1YmxpYyBtZW51OiBPdmVybGF5VGVtcGxhdGVDb21wb25lbnQ7XHJcblxyXG4gIC8qIG1lbnUgaXRlbXMgY29tcG9uZW50ICovXHJcbiAgQENvbnRlbnRDaGlsZHJlbihNZW51SXRlbUNvbXBvbmVudClcclxuICBwdWJsaWMgbWVudUl0ZW1zOiBRdWVyeUxpc3Q8TWVudUl0ZW1Db21wb25lbnQ+O1xyXG5cclxuXHJcbiAgLyogc2VsZWN0IGFsbCBjaGVja2JveCBtb2RlbCAqL1xyXG4gIHB1YmxpYyBzZWxlY3RBbGw6IGJvb2xlYW47XHJcblxyXG4gIC8qIHNlbGVjdGVkIE1lbnUgaXRlbSAqL1xyXG4gIHB1YmxpYyBzZWxlY3RlZEl0ZW06IE1lbnVJdGVtQ29tcG9uZW50O1xyXG5cclxuICAvKiBpcyB0aGUgbWVudSBzaG93aW5nICovXHJcbiAgcHJpdmF0ZSBfbWVudVNob3dpbmcgPSBmYWxzZTtcclxuXHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwcml2YXRlIF9tZW51U2VydmljZTogTWVudVNlcnZpY2VcclxuICApIHtcclxuICAgIHRoaXMuX21lbnVTZXJ2aWNlLnJlZ2lzdGVyKHRoaXMpO1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0b2dnbGUgc2hvdyBzdGF0ZSBvZiB0aGUgbWVudSBpdGVtc1xyXG4gICAqL1xyXG4gIHB1YmxpYyB0b2dnbGVNZW51KCk6IHZvaWQge1xyXG4gICAgdGhpcy5fbWVudVNob3dpbmcgPSAhdGhpcy5pc1Nob3dpbmcoKTtcclxuICAgIGlmICh0aGlzLl9tZW51U2hvd2luZykge1xyXG4gICAgICB0aGlzLnNob3dNZW51KCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLmhpZGVNZW51KCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBzaG93IG1lbnUgYWN0aW9uXHJcbiAgICovXHJcbiAgcHVibGljIHNob3dNZW51KCk6IHZvaWQge1xyXG4gICAgdGhpcy5tZW51LnNob3coKTtcclxuICAgIGlmICh0aGlzLnNlYXJjaCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHRoaXMuc2VhcmNoRWwubmF0aXZlRWxlbWVudC5mb2N1cygpO1xyXG4gICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogaGlkZSBtZW51IGFjdGlvblxyXG4gICAqL1xyXG4gIHB1YmxpYyBoaWRlTWVudSgpOiB2b2lkIHtcclxuICAgIHRoaXMubWVudS5oaWRlKCk7XHJcbiAgICB0aGlzLnNlYXJjaE1vZGVsID0gJyc7XHJcbiAgICB0aGlzLnNlYXJjaE1vZGVsQ2hhbmdlLmVtaXQodGhpcy5zZWFyY2hNb2RlbCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB2aXNpYmlsaXR5IHN0YXRlIG9mIHRoZSBvdmVybGF5IHRlbXBsYXRlXHJcbiAgICovXHJcbiAgaXNTaG93aW5nKCk6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIHRoaXMubWVudSA/IHRoaXMubWVudS5zaG93aW5nIDogZmFsc2U7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBjaGFuZ2UgbW9kZWwgYWN0aW9uXHJcbiAgICovXHJcbiAgY2hhbmdlKCk6IHZvaWQge1xyXG4gICAgdGhpcy5zZWFyY2hNb2RlbENoYW5nZS5lbWl0KHRoaXMuc2VhcmNoTW9kZWwpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogc2VsZWN0IG1lbnUgaXRlbVxyXG4gICAqL1xyXG4gIHB1YmxpYyBzZWxlY3RNZW51SXRlbShpdGVtOiBNZW51SXRlbUNvbXBvbmVudCk6IHZvaWQge1xyXG4gICAgaWYgKCF0aGlzLnNlbGVjdGVkSXRlbXMpIHtcclxuICAgICAgdGhpcy5zZWxlY3RlZEl0ZW1zID0gW107XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZWxlY3RlZEl0ZW0gPSBpdGVtO1xyXG4gICAgaWYgKCF0aGlzLm11bHRpcGxlKSB7XHJcbiAgICAgIGlmICh0aGlzLmNsb3NlT25JdGVtQ2xpY2spIHtcclxuICAgICAgICB0aGlzLmhpZGVNZW51KCk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlmIChpdGVtLmNoZWNrYm94TW9kZWwpIHtcclxuICAgICAgICBpZiAoIXRoaXMuc2VsZWN0ZWRJdGVtcy5pbmNsdWRlcyhpdGVtLml0ZW1JZCkpIHtcclxuICAgICAgICAgIHRoaXMuc2VsZWN0ZWRJdGVtcy5wdXNoKGl0ZW0uaXRlbUlkKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5zZWxlY3RlZEl0ZW1zID0gQXJyYXkuZnJvbSh0aGlzLnNlbGVjdGVkSXRlbXMuZmlsdGVyKChzOiBzdHJpbmcpID0+IHMgIT09IGl0ZW0uaXRlbUlkKSk7XHJcbiAgICAgICAgaWYgKHRoaXMuc2VsZWN0QWxsT3B0aW9uKSB7XHJcbiAgICAgICAgICB0aGlzLnNlbGVjdEFsbCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICB0aGlzLnNlbGVjdGVkSXRlbXNDaGFuZ2UuZW1pdCh0aGlzLnNlbGVjdGVkSXRlbXMpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICoga2V5ZG93biBldmVudCAoZXNjYXBlIGlzIHByZXNzZWQpXHJcbiAgICovXHJcbiAgcHVibGljIG9uS2V5RG93bihldmVudDogS2V5Ym9hcmRFdmVudCk6IHZvaWQge1xyXG4gICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VzY2FwZScgfHwgZXZlbnQua2V5ID09PSAnRXNjJykge1xyXG4gICAgICBpZiAodGhpcy5tZW51LnNob3dpbmcpIHtcclxuICAgICAgICB0aGlzLmhpZGVNZW51KCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRvZ2dsZSBzZWxlY3QgYWxsXHJcbiAgICovXHJcbiAgcHVibGljIHRvZ2dsZVNlbGVjdEFsbEFjdGlvbihmcm9tQ2hlY2tib3g/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICBpZiAoIWZyb21DaGVja2JveCkge1xyXG4gICAgICB0aGlzLnNlbGVjdEFsbCA9ICF0aGlzLnNlbGVjdEFsbDtcclxuICAgIH1cclxuICAgIHRoaXMudG9nZ2xlU2VsZWN0QWxsLmVtaXQodGhpcy5zZWxlY3RBbGwpO1xyXG4gIH1cclxufVxyXG4iXX0=