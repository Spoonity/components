import { Input, Directive } from '@angular/core';
export class FormFieldManager {
    constructor() {
        /* size specification (large or medium) -- default to medium if not provided */
        this.size = 'medium';
        /* value */
        this.value = null;
        /* ControlValueAccessor: onChange function **/
        this.onChange = () => { };
        /* ControlValueAccessor: onTouched function */
        this.onTouched = () => { };
    }
    /**
     * ControlValueAccessor override: registerOnChange
     */
    registerOnChange(fn) {
        this.onChange = fn;
    }
    /**
     * ControlValueAccessor override: registerOnTouched
     */
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    /**
     * ControlValueAccessor override: writeValue
     */
    writeValue(obj) {
        if (obj !== undefined) {
            this.value = obj;
            this.checkDirty();
        }
    }
    /**
     * on change action
     */
    changeAction($event) {
        this.onChange($event);
        this.checkDirty();
    }
    setDisabledState(isDisabled) {
        this.isDisabled = isDisabled;
    }
    /**
     * check dirty
     */
    checkDirty() {
        if (typeof this.value === 'string' || this.value instanceof String) {
            this.isDirty = this.value.trim() !== '';
        }
        else {
            this.isDirty = this.value != null;
        }
    }
}
FormFieldManager.decorators = [
    { type: Directive }
];
FormFieldManager.propDecorators = {
    size: [{ type: Input }],
    label: [{ type: Input }],
    error: [{ type: Input }],
    startIcon: [{ type: Input }],
    endIcon: [{ type: Input }],
    hint: [{ type: Input }],
    placeholder: [{ type: Input }],
    isDisabled: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1maWVsZC5tYW5hZ2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwcC9Db21wb25lbnRzL3NoYXJlZC9mb3JtLWZpZWxkLm1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFJakQsTUFBTSxPQUFnQixnQkFBZ0I7SUFEdEM7UUFFRSwrRUFBK0U7UUFDdEUsU0FBSSxHQUF1QixRQUFRLENBQUM7UUF1QjdDLFdBQVc7UUFDWCxVQUFLLEdBQUcsSUFBSSxDQUFDO1FBS2IsOENBQThDO1FBQzlDLGFBQVEsR0FBUSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFMUIsOENBQThDO1FBQzlDLGNBQVMsR0FBUSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFnRDdCLENBQUM7SUE5Q0M7O09BRUc7SUFDSCxnQkFBZ0IsQ0FBQyxFQUFPO1FBQ3RCLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7T0FFRztJQUNILGlCQUFpQixDQUFDLEVBQU87UUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsVUFBVSxDQUFDLEdBQVE7UUFDakIsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQ3JCLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO1lBQ2pCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztTQUNuQjtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVksQ0FBQyxNQUFNO1FBQ2pCLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxVQUFtQjtRQUNsQyxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztJQUMvQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxVQUFVO1FBQ1IsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxLQUFLLFlBQVksTUFBTSxFQUFFO1lBQ2xFLElBQUksQ0FBQyxPQUFPLEdBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUM7U0FDMUM7YUFBTTtZQUNMLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUM7U0FDbkM7SUFDSCxDQUFDOzs7WUFuRkYsU0FBUzs7O21CQUdQLEtBQUs7b0JBR0wsS0FBSztvQkFHTCxLQUFLO3dCQUdMLEtBQUs7c0JBR0wsS0FBSzttQkFHTCxLQUFLOzBCQUdMLEtBQUs7eUJBR0wsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElucHV0LCBEaXJlY3RpdmUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtDb250cm9sVmFsdWVBY2Nlc3Nvcn0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5cclxuQERpcmVjdGl2ZSgpXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBGb3JtRmllbGRNYW5hZ2VyIGltcGxlbWVudHMgQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xyXG4gIC8qIHNpemUgc3BlY2lmaWNhdGlvbiAobGFyZ2Ugb3IgbWVkaXVtKSAtLSBkZWZhdWx0IHRvIG1lZGl1bSBpZiBub3QgcHJvdmlkZWQgKi9cclxuICBASW5wdXQoKSBzaXplOiAnbWVkaXVtJyB8ICdsYXJnZScgPSAnbWVkaXVtJztcclxuXHJcbiAgLyogdGV4dCBmaWVsZCBsYWJlbCAqL1xyXG4gIEBJbnB1dCgpIGxhYmVsOiBzdHJpbmc7XHJcblxyXG4gIC8qIGVycm9yIG1lc3NhZ2UgKi9cclxuICBASW5wdXQoKSBlcnJvcj86IHN0cmluZztcclxuXHJcbiAgLyogb3B0aW9uYWw6IGxlZnQgaWNvbiAqL1xyXG4gIEBJbnB1dCgpIHN0YXJ0SWNvbj86IHN0cmluZztcclxuXHJcbiAgLyogb3B0aW9uYWw6IHJpZ2h0IGljb24gKi9cclxuICBASW5wdXQoKSBlbmRJY29uPzogc3RyaW5nO1xyXG5cclxuICAvKiBvcHRpb25hbDogaGludCBtZXNzYWdlICovXHJcbiAgQElucHV0KCkgaGludD86IHN0cmluZztcclxuXHJcbiAgLyogb3B0aW9uYWw6IHBsYWNlaG9sZGVyICovXHJcbiAgQElucHV0KCkgcGxhY2Vob2xkZXI/OiBzdHJpbmc7XHJcblxyXG4gIC8qIGlzIGRpc2FibGVkICovXHJcbiAgQElucHV0KCkgaXNEaXNhYmxlZDtcclxuXHJcbiAgLyogdmFsdWUgKi9cclxuICB2YWx1ZSA9IG51bGw7XHJcblxyXG4gIC8qIGRpcnR5IHN0YXRlICovXHJcbiAgaXNEaXJ0eTogYm9vbGVhbjtcclxuXHJcbiAgLyogQ29udHJvbFZhbHVlQWNjZXNzb3I6IG9uQ2hhbmdlIGZ1bmN0aW9uICoqL1xyXG4gIG9uQ2hhbmdlOiBhbnkgPSAoKSA9PiB7IH07XHJcblxyXG4gIC8qIENvbnRyb2xWYWx1ZUFjY2Vzc29yOiBvblRvdWNoZWQgZnVuY3Rpb24gKi9cclxuICBvblRvdWNoZWQ6IGFueSA9ICgpID0+IHsgfTtcclxuXHJcbiAgLyoqXHJcbiAgICogQ29udHJvbFZhbHVlQWNjZXNzb3Igb3ZlcnJpZGU6IHJlZ2lzdGVyT25DaGFuZ2VcclxuICAgKi9cclxuICByZWdpc3Rlck9uQ2hhbmdlKGZuOiBhbnkpOiB2b2lkIHtcclxuICAgIHRoaXMub25DaGFuZ2UgPSBmbjtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbnRyb2xWYWx1ZUFjY2Vzc29yIG92ZXJyaWRlOiByZWdpc3Rlck9uVG91Y2hlZFxyXG4gICAqL1xyXG4gIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiBhbnkpOiB2b2lkIHtcclxuICAgIHRoaXMub25Ub3VjaGVkID0gZm47XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDb250cm9sVmFsdWVBY2Nlc3NvciBvdmVycmlkZTogd3JpdGVWYWx1ZVxyXG4gICAqL1xyXG4gIHdyaXRlVmFsdWUob2JqOiBhbnkpOiB2b2lkIHtcclxuICAgIGlmIChvYmogIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICB0aGlzLnZhbHVlID0gb2JqO1xyXG4gICAgICB0aGlzLmNoZWNrRGlydHkoKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIG9uIGNoYW5nZSBhY3Rpb25cclxuICAgKi9cclxuICBjaGFuZ2VBY3Rpb24oJGV2ZW50KSB7XHJcbiAgICB0aGlzLm9uQ2hhbmdlKCRldmVudCk7XHJcbiAgICB0aGlzLmNoZWNrRGlydHkoKTtcclxuICB9XHJcblxyXG4gIHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgdGhpcy5pc0Rpc2FibGVkID0gaXNEaXNhYmxlZDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGNoZWNrIGRpcnR5XHJcbiAgICovXHJcbiAgY2hlY2tEaXJ0eSgpIHtcclxuICAgIGlmICh0eXBlb2YgdGhpcy52YWx1ZSA9PT0gJ3N0cmluZycgfHwgdGhpcy52YWx1ZSBpbnN0YW5jZW9mIFN0cmluZykge1xyXG4gICAgICB0aGlzLmlzRGlydHkgPSAgdGhpcy52YWx1ZS50cmltKCkgIT09ICcnO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5pc0RpcnR5ID0gdGhpcy52YWx1ZSAhPSBudWxsO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuIl19