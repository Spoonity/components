export var ButtonType;
(function (ButtonType) {
    ButtonType["primary"] = "primary";
    ButtonType["secondary"] = "default";
    ButtonType["tertiary"] = "link";
})(ButtonType || (ButtonType = {}));
export var ButtonSize;
(function (ButtonSize) {
    ButtonSize["large"] = "large";
    ButtonSize["medium"] = "default";
    ButtonSize["small"] = "small";
})(ButtonSize || (ButtonSize = {}));
export var SideNavigationType;
(function (SideNavigationType) {
    SideNavigationType["menu"] = "menu";
    SideNavigationType["subMenu"] = "subMenu";
    SideNavigationType["menuGroup"] = "menuGroup";
    SideNavigationType["menuItem"] = "menuItem";
})(SideNavigationType || (SideNavigationType = {}));
export var TagType;
(function (TagType) {
    TagType["closeable"] = "closeable";
    TagType["default"] = "default";
    TagType["checkable"] = "checkable";
})(TagType || (TagType = {}));
export var AvatarSize;
(function (AvatarSize) {
    AvatarSize[AvatarSize["large"] = 48] = "large";
    AvatarSize[AvatarSize["medium"] = 40] = "medium";
    AvatarSize[AvatarSize["small"] = 32] = "small";
})(AvatarSize || (AvatarSize = {}));
export var DividerType;
(function (DividerType) {
    DividerType["vertical"] = "vertical";
    DividerType["horizontal"] = "horizontal";
})(DividerType || (DividerType = {}));
export var ProgressType;
(function (ProgressType) {
    ProgressType["line"] = "line";
    ProgressType["circle"] = "circle";
})(ProgressType || (ProgressType = {}));
export var ICardType;
(function (ICardType) {
    ICardType["sms"] = "sms";
    ICardType["customer"] = "customer";
    ICardType["gift"] = "giftManagement";
})(ICardType || (ICardType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW51bXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvYXBwL3V0aWxzL2VudW1zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sQ0FBTixJQUFZLFVBSVg7QUFKRCxXQUFZLFVBQVU7SUFDcEIsaUNBQW1CLENBQUE7SUFDbkIsbUNBQXFCLENBQUE7SUFDckIsK0JBQWlCLENBQUE7QUFDbkIsQ0FBQyxFQUpXLFVBQVUsS0FBVixVQUFVLFFBSXJCO0FBRUQsTUFBTSxDQUFOLElBQVksVUFJWDtBQUpELFdBQVksVUFBVTtJQUNwQiw2QkFBZSxDQUFBO0lBQ2YsZ0NBQWtCLENBQUE7SUFDbEIsNkJBQWUsQ0FBQTtBQUNqQixDQUFDLEVBSlcsVUFBVSxLQUFWLFVBQVUsUUFJckI7QUFFRCxNQUFNLENBQU4sSUFBWSxrQkFLWDtBQUxELFdBQVksa0JBQWtCO0lBQzVCLG1DQUFhLENBQUE7SUFDYix5Q0FBbUIsQ0FBQTtJQUNuQiw2Q0FBdUIsQ0FBQTtJQUN2QiwyQ0FBcUIsQ0FBQTtBQUN2QixDQUFDLEVBTFcsa0JBQWtCLEtBQWxCLGtCQUFrQixRQUs3QjtBQUVELE1BQU0sQ0FBTixJQUFZLE9BSVg7QUFKRCxXQUFZLE9BQU87SUFDakIsa0NBQXVCLENBQUE7SUFDdkIsOEJBQW1CLENBQUE7SUFDbkIsa0NBQXVCLENBQUE7QUFDekIsQ0FBQyxFQUpXLE9BQU8sS0FBUCxPQUFPLFFBSWxCO0FBRUQsTUFBTSxDQUFOLElBQVksVUFJWDtBQUpELFdBQVksVUFBVTtJQUNwQiw4Q0FBVSxDQUFBO0lBQ1YsZ0RBQVcsQ0FBQTtJQUNYLDhDQUFVLENBQUE7QUFDWixDQUFDLEVBSlcsVUFBVSxLQUFWLFVBQVUsUUFJckI7QUFDRCxNQUFNLENBQU4sSUFBWSxXQUdYO0FBSEQsV0FBWSxXQUFXO0lBQ3JCLG9DQUFxQixDQUFBO0lBQ3JCLHdDQUF5QixDQUFBO0FBQzNCLENBQUMsRUFIVyxXQUFXLEtBQVgsV0FBVyxRQUd0QjtBQUVELE1BQU0sQ0FBTixJQUFZLFlBR1g7QUFIRCxXQUFZLFlBQVk7SUFDdEIsNkJBQWEsQ0FBQTtJQUNiLGlDQUFpQixDQUFBO0FBQ25CLENBQUMsRUFIVyxZQUFZLEtBQVosWUFBWSxRQUd2QjtBQUVELE1BQU0sQ0FBTixJQUFZLFNBSVg7QUFKRCxXQUFZLFNBQVM7SUFDbkIsd0JBQVcsQ0FBQTtJQUNYLGtDQUFxQixDQUFBO0lBQ3JCLG9DQUF1QixDQUFBO0FBQ3pCLENBQUMsRUFKVyxTQUFTLEtBQVQsU0FBUyxRQUlwQiIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBlbnVtIEJ1dHRvblR5cGUge1xyXG4gIHByaW1hcnkgPSAncHJpbWFyeScsXHJcbiAgc2Vjb25kYXJ5ID0gJ2RlZmF1bHQnLFxyXG4gIHRlcnRpYXJ5ID0gJ2xpbmsnXHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIEJ1dHRvblNpemUge1xyXG4gIGxhcmdlID0gJ2xhcmdlJyxcclxuICBtZWRpdW0gPSAnZGVmYXVsdCcsXHJcbiAgc21hbGwgPSAnc21hbGwnXHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIFNpZGVOYXZpZ2F0aW9uVHlwZSB7XHJcbiAgbWVudSA9ICdtZW51JyxcclxuICBzdWJNZW51ID0gJ3N1Yk1lbnUnLFxyXG4gIG1lbnVHcm91cCA9ICdtZW51R3JvdXAnLFxyXG4gIG1lbnVJdGVtID0gJ21lbnVJdGVtJ1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBUYWdUeXBlIHtcclxuICBjbG9zZWFibGUgPSAnY2xvc2VhYmxlJyxcclxuICBkZWZhdWx0ID0gJ2RlZmF1bHQnLFxyXG4gIGNoZWNrYWJsZSA9ICdjaGVja2FibGUnXHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIEF2YXRhclNpemUge1xyXG4gIGxhcmdlID0gNDgsXHJcbiAgbWVkaXVtID0gNDAsXHJcbiAgc21hbGwgPSAzMlxyXG59XHJcbmV4cG9ydCBlbnVtIERpdmlkZXJUeXBlIHtcclxuICB2ZXJ0aWNhbCA9ICd2ZXJ0aWNhbCcsXHJcbiAgaG9yaXpvbnRhbCA9ICdob3Jpem9udGFsJ1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBQcm9ncmVzc1R5cGUge1xyXG4gIGxpbmUgPSAnbGluZScsXHJcbiAgY2lyY2xlID0gJ2NpcmNsZSdcclxufVxyXG5cclxuZXhwb3J0IGVudW0gSUNhcmRUeXBlIHtcclxuICBzbXMgPSAnc21zJyxcclxuICBjdXN0b21lciA9ICdjdXN0b21lcicsXHJcbiAgZ2lmdCA9ICdnaWZ0TWFuYWdlbWVudCdcclxufSJdfQ==